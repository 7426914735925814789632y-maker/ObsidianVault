

# 📄 2026-01-01

### 【彼女の家：おでんを食べながらハリー・ポッター鑑賞と親密な時間】〔18:00~24:00〕

* 彼女が作ってくれた激ウマの「餃子巻きおでん」を食べる
* 一緒に『ハリー・ポッターと賢者の石』を途中まで見る
* 彼女からおしゃれなトランプを3つプレゼントしてもらう
* 前回散らかしっぱなしだった反省を活かし、カバンをきちんときれいに整理して置いておく
* 二人で親密な時間を過ごして就寝する

### ──────────────────────

### 【彼女の家：到着と仮眠】〔14:40~18:00〕

* 福岡の彼女の家に到着する
* 長距離移動の疲れを癒やすため、到着後すぐに夕方まで仮眠をとる

### ──────────────────────

### 【移動：福岡空港への到着】〔10:55~14:40〕

* 成田空港から羽田経由（または直行便フライト）で福岡へ移動する
* 14:00頃に福岡空港へ到着し、14:40に彼女の家に到着する

### ──────────────────────

### 【移動：成田空港への移動】〔07:05~09:51〕

* 早朝から自宅を出発し、立飛から成田空港まで移動する

### ──────────────────────

### 【自宅：睡眠】〔00:30~06:00〕

* 早朝からの移動に備えて睡眠をとる

### ────────■

#### 【ファイルLog】

#### 【DailyData】

%% Begin Waypoint %%
- [[☷│2026-01-01.base|☷│2026-01-01]]
- [[🗓：「成田空港搭乗」]]
- [[🗓：「福岡旅行１日目」]]

%% End Waypoint %%

---

#### 【出力用追加テキスト】

##### ○本日出力ファイル


---

# 📄 2026-01-02

### 【彼女の家：食事と謎解きゲーム】〔19:40~24:00〕

- 前日の続きの餃子巻きおでんを食べながら彼女と食事をする
- 締めのうどんを20:00に私一人で買いにいくもお店が閉まっており、コンビニで購入
- 買ってきたスーパーカップの抹茶とバニラをカップに半々に入れて二人で食べる
    
- 二人でSCRAPの謎解きゲーム『ワールド謎ツアー 気まぐれな神と二人の芸術家』を解く
    
- 食後に、小腹が空いたという彼女の要請に答え、ローソンへスーパーカップとミニドーナツ・クッキーの小袋・２リットルの水を買いに行く
    

### ──────────────────────

### 【彼女の家：帰宅と親密な時間】〔18:00~19:40〕

- マークイズももちから帰宅する
    
- 帰宅後、一時間ほど二人でイチャイチャして過ごす
    

### ──────────────────────

### 【マークイズももち：ショッピング】〔17:00~18:00〕

- 彼女と施設内を1時間程ショッピングする
    
- 彼女と一緒にガチャガチャのラインナップを見て楽しむ

- 彼女にお菓子のデザインの文具を買ってあげた
	- きのこのやまの消しカスローラー
	- チロルチョコの絆創膏
	- スヌーピーのクリームソーダデザインの鉛筆キャップ
	- 色鉛筆(シマエナガ、マーブルチョコ)
- CanDoで彼女の家の細かい不便を改善する道具を買いたかったが、思いの外閉店時間が早く18:00に退店する
    

### ──────────────────────

### 【彼女の家：スケジュール決定とゲーム・作業打診】〔12:00~17:00〕

- 17:00の外出前まで、家で二人でゆっくり過ごす
    
- 旅行7日間のスケジュールを二人で決める
    
- 彼女にもらった3DSで、人生で一番遊んだソフトである『ポケモンホワイト2』などをゆっくりと楽しむ
    
- 卒業したての職業訓練校でオンラインサロンを実施することを宣言しており、年末までに動き出せなかった焦りから、7日間の二人で過ごす時間の内、一日2〜3時間は個々人の作業時間を取らせてほしいと彼女に打診する（彼女は承諾してくれたが、結局彼女への申し訳なさで中途半端な気持ち・状態のままオンラインサロン開設をサボることになり、それ故に旅行中は始終、3割ほどの焦りがあった）
    

### ────────■

#### 【ファイルLog】

#### 【DailyData】

%% Begin Waypoint %%
- [[☷│2026-01-02.base|☷│2026-01-02]]

%% End Waypoint %%

#### 【出力用追加テキスト】

##### ○本日出力ファイル

### (2026/06/25 00:56)

---

# 📄 2026-01-03

### 【彼女の家：帰宅とTVを観ながらの休息】〔19:00~24:00〕

- 赤坂から重い荷物を持って疲れながら帰宅する
    
- 二人で食事を取らずにTVをつけてダラダラ過ごす（気がする）
    

### ──────────────────────

### 【赤坂：中古ショップ巡りとまんだらけ】〔17:20~18:30〕

- 天ぷらひらおを退店後、中古服巡りをしてから中古ショップ「まんだらけ」へ行く
    
- 特撮・アニメ・ポケモン・妖怪ウォッチなどのグッズを見る
    
```cardlink
url: https://photos.app.goo.gl/FNmx9CjD2GTH7HQp9
title: "New photo · Sunday, Jan 4 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczNwezD-tGTMJfF4-rx6H_Jo0lkephxpJ7NVd_iKjVdjmJXuR9BN2OPTnGLTagkO-eVCG6c28RCoaazjEzbCJclLG2t6lkCXtIHJrSXqlllpTQtG-ey_=w600-h315-p-k
```

- 自分はライダー特集の中古本を4冊程購入する
    
```cardlink
url: https://photos.app.goo.gl/HUgxgyEdPmweP6z7A
title: "New photo · Sunday, Jan 4 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczPuA9EGbgiAVye8tNmYXU77UxliFcFY-0RfTILrFOrKZu_P5Yp8b7HaOHWYI6JZZyDkiuyOyVzuJMqjl2QyEw_Rdbk-rDxgZJRvVEJnlRNfEU29EsZ4=w600-h315-p-k
```
```cardlink
url: https://photos.app.goo.gl/gZvYDHvXy5fGwLZf6
title: "New photo · Sunday, Jan 4 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczP5bqTIVW79TrdE1ReWI0Dw1BC0JNB5WworbPwPlEjnYAUXWUTqyhBPRxynXBqyGV0p3_VKFfqIapYnLcOLQcxRagkOZ5o8Q92X2_tl8t1bvUSr9PoE=w600-h315-p-k
```
```cardlink
url: https://photos.app.goo.gl/s8NRrDoNVeAAY4QQ8
title: "New photo · Sunday, Jan 4 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczMobgajQqCY8SeVFTxEBcF4WnuxGi9JPsLiTcrZDPOqw-vzPVXgz6DDTs4_tglm9sIAsPWbLxqXW3gk7DdkDbgGi46tJVOjQAQKR3XCfrNyLQ2Kyj2d=w600-h315-p-k
```
```cardlink
url: https://photos.app.goo.gl/AHm83gRsgauAR9Gc9
title: "New photo · Sunday, Jan 4 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczPbu5AFKemzTVxJ3ysLNF4Mz45EvI4tWh29K0LCBOqvWUDnkrlvwuYemlWZ5mYME17tug_Ak9mt3mBIlfkCM4C8AQOIwuqXAbZl2pY2f-1l5HLT0LfL=w600-h315-p-k
```
```cardlink
url: https://photos.app.goo.gl/ZcCSVAfzZVLZn22W9
title: "New photo · Sunday, Jan 4 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczOstMxYGbzED5Hpd1snfcKCkXW4OxHLSE8CXnzuszhZPeT5h-jNAtCf79JBa0anWto5-DboW1s0RCypamwxHcNgKz2hU59G_Q2bsXH0wcBrmaHzVW-H=w600-h315-p-k
```

- 彼女は懐かしの「てくてくエンジェル」万歩計と「バトルえんぴつ」とキャップのセットを20本購入する
    
- 18:30に赤坂を出発する
    

### ──────────────────────

### 【天ぷらひらお：昼食と本気しりとり】〔15:30~17:20〕

- 15:30に赤坂に到着し、「天ぷらひらお」の行列に16:20まで並ぶ
    
- 行列に並んでいる間、彼女とチェスクロック付きの本気しりとりをする
    
- 自分が“る攻め”で圧勝したせいで、彼女をもやもやした気持ちにさせる
    
- 食べ放題のゆず塩辛が空港土産にあることがわかり、お土産にすることを決める
    
```cardlink
url: https://photos.app.goo.gl/A31rET2QXmRj4wUZ6
title: "New photo · Sunday, Jan 4 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczOsZz9KfI1W2cnr66SIk4l49623Q23bB4DMd9S7XwpmO2Lf3hC7fCPPqBUklW4K_aJWHjKb13v_52eFrNsJpmdy0deJVJ7pChnd0ALnd5OcwpJr8HYi=w600-h315-p-k
```

    
- お餅、明太、さつまいもを特に美味しく食べる（お餅とさつまいもはお菓子のようだった）

```cardlink
url: https://photos.app.goo.gl/wBqPhCRCWpCsXhuD9
title: "New photo · Sunday, Jan 4 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczPSRkGS_iTmMVLeyU9VCQ4ROGOTVVJbRinPjtnK5tvC6lufhdB8Zq5akBhX6XuM4JT_RA5L_blYDkHSzgr2poa3Ulkmavx6Sa-ttqCNIb5tgHnDRayg=w600-h315-p-k
```


```cardlink
url: https://photos.app.goo.gl/iq1aHybE3FR1H8jn8
title: "New photo · Sunday, Jan 4 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczN1hM-O10m_PxKamddW09mcXRo8sSvnyKiuK5K7vxFEElbvS88e3OBQehn8R_jPWr86isu_eXhZG7iu3Z3SOWBa1vDMFqwK8I9fmQgtBj7YsE_Jr4NU=w600-h315-p-k
```


- 大盛りご飯でたらふく食べるが、胃袋の油キャパシティを計算に入れておらず、最後のお肉天を残してギブアップする
    
- 体調が万全じゃない彼女に食べかけの最後の一本だけ食べてもらう
    
- 17:20にお店を出る
    

### ──────────────────────

### 【鳥飼八幡宮：初詣と散策】〔13:20~15:10〕

- 鳥飼八幡宮で初詣を行う
    
```cardlink
url: https://photos.app.goo.gl/zpzNP7i9aAt2NQMc6
title: "New photo · Saturday, Jan 3 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczMouC6JW6mFTbBb5KiCAj4xWJExqXUyMn-X2yOAnYwBOrARUudTIbb51RLFZ5_GtQk3Ay29uRx-fwG1Trv5UuBXhsCfyerDTmjcTMQYEZ-yE4gIYIBP=w600-h315-p-k
```

    
- 途中で彼女が生理になり、ナプキンと薬を取りに一時帰宅したため、大行列に並びながら彼女が戻るのを待機する（その間、男根を祀った木があって楽しむ）
    
- 彼女が戻り、二人でご参拝をして手水で新鮮な聖水を飲む
    
- 普通の100円おみくじと、ランダムなめでたい飾り物がついた500円のおみくじを引く（午年年女の彼女は馬のストラップ、仕事の芸事を磨きたい自分は招福開運招き猫が当たる）

```cardlink
url: https://photos.app.goo.gl/isEvrVeh329yDG2c7
title: "あきおのくじ · Saturday, Jan 3 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczNDkEORZVmjpeaeqZpYx39ryAuNq5gTE-ZnP7v3cE_6orbwY4oq5Kfq9NBko5T2uLwFUNFGrb6sDvEfHsCyQmfSJS3sdFtdtYGYM_dBOL5QSBT8Wqgx=w600-h315-p-k
```

    
```cardlink
url: https://photos.app.goo.gl/KvEfmTe8fnz2soRF9
title: "ななみのくじ · Saturday, Jan 3 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczO-3O7IEaA8vVrm6nLaGI5Q3g9akcoQpq3NKhdyqiWQHfnJMO8mmdhN7o_BV-75UXF8Gci3WKNDSWNipJyOgaY5Ul8DOp8wD8-uBEr0qoqEgNPZ2aBZ=w600-h315-p-k
```

    
```cardlink
url: https://photos.app.goo.gl/xr3Coc5eBQVrFUeaA
title: "New photo · Saturday, Jan 3 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczPLozJRb2q8taQ2hJdYLKP2Klfv_30iEktccxkU3PgRZAcUyqsjEGHoVxXyazIvSNtPBuLBRhwLz-3Ont_JPeO8JQgJBR-c0PC8Q_v-8FNaLlVx2Ih5=w600-h315-p-k
```

- おしゃれなお守りを一つずつ購入する（自分は手品師として前に進むために「芸能上達」、年女で厄年の彼女は「厄除け」「方位除」の2つを購入）
    
- 木に願いを結びつける色付きの紐を2つずつ買って、一つは木に結びつけ、もう一つはお守りに結びつけるようにする
    
- 境内に銀杏の葉っぱが落ちていたので、ひとりひとつ拾う（「買ったお守りを一度開けると神が逃げる」と知り、別の自作の御守袋に入れることを決める）
    
- 15:10に唐人町駅を出て赤坂に向かう
    

### ──────────────────────

### 【自宅〜外出：起床とコンビニへの立ち寄り】〔10:00~13:20〕

- ゆっくり起床し、軽く食事を取ってから13:15に外出する
    
- コンビニで飲み物を購入し、体調の優れなかった彼女にほっとレモンを差し入れる
    
- 彼女の家になかったウエットティッシュをコンビニで買おうとして、割高だと彼女に止められる
    

### ────────■

#### 【ファイルLog】

#### 【DailyData】

%% Begin Waypoint %%
- [[☷│2026-01-03.base|☷│2026-01-03]]

%% End Waypoint %%

#### 【出力用追加テキスト】

##### ○本日出力ファイル



---

# 📄 2026-01-04

### 【ガスト：新年の抱負や計画を立てる】〔22:30~24:00〕

- ガストに滞在し、二人で新年の抱負や計画を立てる
    
- 以前に誕生日プレゼントとしてあげた文房具を彼女が使ってくれていたのを確認する
    
- ポテトフライとパンケーキを頼み、24:00にお店を出て帰宅する
    

### ──────────────────────

### 【移動〜ローソン：文具の購入】〔22:20~22:30〕

- 22:20に二人で外出する
    
- ローソンの無印良品コーナーでルーズリーフバインダーと紙を購入する
    

### ──────────────────────

### 【彼女の家：夕食と動画視聴・部屋の改良】〔18:20~22:20〕

- 帰宅後、彼女が作ってくれたお手製のシチューを一緒に食べる
    
- 彼女のおばあちゃん直伝のシチューで、今まで食べたシチューの中で一番美味しかった
    
- 彼女がシチューを仕上げてくれている間に、自分は彼女の部屋を多少改良する
    
- 食事をしながらドラマ『不適切にもほどがある！』の過去作を視聴する
    

### ──────────────────────

### 【マークイズ福岡ももち：ショッピングとバナナスムージー】〔16:30~18:20〕

- 二人で近所のマークイズ福岡ももちへ行く
    
- 「niko and...」で雑貨を見る
    
- 自分が彼女にあげようと思っていた寿司の「バラン」のストラップを彼女が自ら買おうとしたため焦る
    
- 彼女はniko and...で新しいゴミ箱を購入する
    
- 「CanDo」へ行き、家の寒さや不便を改善できるアイテム（突っ張り棒や断熱シートなど）を自分が選んで二人のお金で購入する
    
- 30分ほど物色した後、18:20にバナナスムージーを買って二人で飲む
    

### ──────────────────────

### 【彼女の家：自由時間と彼女の買い出し】〔13:00~16:30〕

- 13:00頃、昼間に彼女がとびきりのお手製シチューを作るために材料の買い出しに行ってくれる
    
- 彼女が買い出しに出ている間、自分は部屋でパソコンをしたりゲームをしたりして過ごす
    
- シチューが完成する
    

### ──────────────────────

### 【彼女の家：起床と休息】〔08:00~13:00〕

- 午前中は二人で寝たり、Hしたり、また寝たりしてゆっくりと過ごす
    

### ────────■

#### 【ファイルLog】

#### 【DailyData】

%% Begin Waypoint %%
- [[☷│2026-01-04.base|☷│2026-01-04]]

%% End Waypoint %%

#### 【出力用追加テキスト】

##### ○本日出力ファイル

(2026/06/30 00:15)

---

# 📄 2026-01-05

---

# 📄 2026-01-06

---

# 📄 2026-01-07

---

# 📄 2026-01-08

---

# 📄 2026-01-09

---

# 📄 2026-01-10

---

# 📄 2026-01-11

---

# 📄 2026-01-12

---

# 📄 2026-01-13

---

# 📄 2026-01-14

---

# 📄 2026-01-15

---

# 📄 2026-01-16

---

# 📄 2026-01-17

---

# 📄 2026-01-18

---

# 📄 2026-01-19

---

# 📄 2026-01-20

---

# 📄 2026-01-21

---

# 📄 2026-01-22

---

# 📄 2026-01-23

---

# 📄 2026-01-24

---

# 📄 2026-01-25

---

# 📄 2026-01-26

---

# 📄 2026-01-27

---

# 📄 2026-01-28

---

# 📄 2026-01-29

---

# 📄 2026-01-30

---

# 📄 2026-01-31

---

# 📄 2026-02-01

---

# 📄 2026-02-02

---

# 📄 2026-02-03

---

# 📄 2026-02-04

---

# 📄 2026-02-05

---

# 📄 2026-02-06

---

# 📄 2026-02-07

---

# 📄 2026-02-08

---

# 📄 2026-02-09

---

# 📄 2026-02-10

---

# 📄 2026-02-11


･母：政治の話
│･｢金儲けのために搾取するべく政治家になったみらい｣
→別に儲けてくれても構わないが、きちんと国民を豊かにしてくれ

---

# 📄 2026-02-12

---

# 📄 2026-02-13

---

# 📄 2026-02-14

---

# 📄 2026-02-15

---

# 📄 2026-02-16

---

# 📄 2026-02-17

---

# 📄 2026-02-18

---

# 📄 2026-02-19

---

# 📄 2026-02-20

---

# 📄 2026-02-21

---

# 📄 2026-02-22

---

# 📄 2026-02-23

---

# 📄 2026-02-24

---

# 📄 2026-02-25

---

# 📄 2026-02-26

---

# 📄 2026-02-27

---

# 📄 2026-02-28

---

# 📄 2026-03-01

---

# 📄 2026-03-02

---

# 📄 2026-03-03

---

# 📄 2026-03-04

---

# 📄 2026-03-05

---

# 📄 2026-03-06

---

# 📄 2026-03-07

---

# 📄 2026-03-08

---

# 📄 2026-03-09

---

# 📄 2026-03-10

---

# 📄 2026-03-11

---

# 📄 2026-03-12

---

# 📄 2026-03-13

---

# 📄 2026-03-14

---

# 📄 2026-03-15

---

# 📄 2026-03-16

---

# 📄 2026-03-17

---

# 📄 2026-03-18



[[👤 永井七十三]]から、
｢電気代が嵩むが暖房器具は使っているか？｣
(デロンギを使うな)
｢さあ、扇風機でしょうか｣

と、シラを通す

[[🐨正守護神🗡]]
▷:｢誠がない対応、恥ずかしい、直さなければ｣
[[🐨副守護神🛡]]
▷:｢やはり、私は祖母よりも徳が低いのだ、不孝者なのだ｣



⬇

```cardlink
url: https://chatgpt.com/share/69ba99e5-1e30-8006-b36b-959b3b946ec2
title: "ChatGPT - 祖母と孫息子の信仰評価"
description: "Shared via ChatGPT"
host: chatgpt.com
favicon: https://chatgpt.com/favicon.ico
image: https://cdn.openai.com/chatgpt/share-og.png
```






---

# 📄 2026-03-19

---

# 📄 2026-03-20

---

# 📄 2026-03-21

---

# 📄 2026-03-22

---

# 📄 2026-03-23

---

# 📄 2026-03-24

---

# 📄 2026-03-25

---

# 📄 2026-03-26

---

# 📄 2026-03-27

---

# 📄 2026-03-28

---

# 📄 2026-03-29

---

# 📄 2026-03-30

---

# 📄 2026-03-31

---

# 📄 2026-04-01

---

# 📄 2026-04-02

---

# 📄 2026-04-03

---

# 📄 2026-04-04

---

# 📄 2026-04-05

---

# 📄 2026-04-06

---

# 📄 2026-04-07

---

# 📄 2026-04-08

---

# 📄 2026-04-09

---

# 📄 2026-04-10

---

# 📄 2026-04-11

---

# 📄 2026-04-12

---

# 📄 2026-04-13

---

# 📄 2026-04-14

---

# 📄 2026-04-15

---

# 📄 2026-04-16

---

# 📄 2026-04-17

---

# 📄 2026-04-18

---

# 📄 2026-04-19

---

# 📄 2026-04-20

---

# 📄 2026-04-21

---

# 📄 2026-04-22

---

# 📄 2026-04-23

---

# 📄 2026-04-24

---

# 📄 2026-04-25

---

# 📄 2026-04-26

---

# 📄 2026-04-27

---

# 📄 2026-04-28

---

# 📄 2026-04-29

---

# 📄 2026-04-30

---

# 📄 2026-05-01

---

# 📄 2026-05-02

---

# 📄 2026-05-03

---

# 📄 2026-05-04

---

# 📄 2026-05-05

---

# 📄 2026-05-06

---

# 📄 2026-05-07

---

# 📄 2026-05-08

---

# 📄 2026-05-09

---

# 📄 2026-05-10

---

# 📄 2026-05-11

---

# 📄 2026-05-12

---

# 📄 2026-05-13

---

# 📄 2026-05-14

---

# 📄 2026-05-15

---

# 📄 2026-05-16

---

# 📄 2026-05-17

---

# 📄 2026-05-18

---

# 📄 2026-05-19

---

# 📄 2026-05-20

頭の働きが悪い1日だった。
心の中につっかえがある 
人様に迷惑はかけてないか、ならひとまずよしとしよう。
やりたいことを考える
やるべきことを考える
どうすれば自分らしくいられるか
どうすれば納得できる自分でいられるか
今日みたいな日もある 
そのことをまずは受け入れる。
きっとこの先も。
だから、そんな自分を愛した上で、できる進歩をしていく。
むりをしない。そのために、無理な野望は抱いては行けない。
野望は正義ではない。
野望を持たないことが時には野望となる。

うぅっとなる気持ちを1度抑えて、深呼吸。

きっと、今日みたいな日は繰り返される。
それは、別に消すべき日ではない。
私の中に存在してはいけないものでもなければ、淘汰すべきものでもない。
今の時代に存在を許され、ただ生き残っていること。
その状態をたのしめ。
種が残るかどうかとか、幸福を維持するかどうかとかは、別に私が決めていいことじゃない。
だから、ただ流れとか神とかの裁量に任せて、存在していればいい。[[(ⅶ)てあ🍃]]

私というサイコロは、今日はどんな目が出るかな。そんな風に生きよう。


---

# 📄 2026-05-21

---

# 📄 2026-05-22

今日は何をしてた
今日も何もしてない
1日YouTubeを見て、脳死させるよう過ごしてた
消費者センターに電話をした
英語物語の対戦をした
夜は1時をすぎた。
今はもう4時になる。
荒廃した街のAI動画を見た。
己の心に似てるなと思った。
想像の中でさまよってみた。
今がマシだなと思えてきた。
社会を裏切ってはいないよ今は。
だから、明日も仕事に行くよ。
これは成長の契機だよ。
MOROHAが頭で流れるよ。
仮に明日も明後日も1件もあぽがとれなかったとして、
食らうダメージは何パーセントだ？
自分が自分から切り離してライフとして扱ってる部分の、せいぜい60パーセントか？
なら、何が起きたら残りの40パーセントもしぬ？
財布でも無くすか？
遅刻でもしてみるか？
遅刻したら確かにプラスで20パーセントは持ってかれそうだ。
ダメージ80パーセント。
どうやって回復するだろうか？
多分一日中YouTubeをみるとか。
彼女に電話するとか。
でもお金はあるんだし、裏切りはしてないんだし。
むしろ、仮に行かなかった場合は、結局動けなくて、無理くり自分に95パーセントくらいダメージ入れるだろう。でもそれも、その時点でライフとしている部分が大幅に減っての95パーだから、所詮は茶番だろうけど。そうやって茶番を繰り返して、小さい自分になっていくんだろうけど。
だったら、大きい夢見て、大きな自分になった方が100倍いいな。

飯も食うてない。
明らかに寝た方がいい。
ドラッグ依存しょう。
この葛藤は多分来年もやってる。だからその中で進む。
本当は、100パーセントの自分をいきたい。
蓋をするのにもエネルギーがいる。
祖父母と向き合うとか。おばさん達と会話するとか。
そんなことからでいいと思う。そんなことが難しいんだと思う。
だから、やる意味あるんじゃないかな

---

# 📄 2026-05-23

---

# 📄 2026-05-24

---

# 📄 2026-05-25



```cardlink
url: https://www.primevideo.com/region/fe/detail/0P6NUYT7FCNSEFIPMZGS1QSURD/ref=atv_sr_fle_c_Tn74RA_1_1_1?sr=1-1&pageTypeIdSource=ASIN&pageTypeId=B0DJTJ73BM&qid=1779967417216
title: "Prime Video: シークレットNGハウス Season2 第1話"
description: "好評を博した二宮和也×若林正恭（オードリー）が仕掛ける究極の心理戦『シークレットＮＧハウス』の第２弾開幕！！戦いの舞台は、絶対にしてはいけない言動＝\"シークレットＮＧ\"が潜む密室。招待されたのは佐藤健、本田翼、ウエンツ瑛士、春日俊彰（オードリー）、吉村崇（平成ノブシコブシ）、若槻千夏、伊野尾慧（Hey! Say! JUMP）、一ノ瀬美空（乃木坂46）ら８名の人気芸能人。ＮＧが何かを知らない彼らは、ＮＧ行動をした際に鳴る警告音を手がかりに\"何がＮＧ行動か\"を推理！ＮＧに気づいた者は、回避するだけでなく、ライバルに\"ＮＧを踏ませる\"という、新たな駆け引きが始まる。一瞬の油断が命取りとなる中、最後まで生き残り、賞金を総取りするのは誰だ！？©︎Octagon"
host: www.primevideo.com
favicon: https://m.media-amazon.com/images/G/01/digital/video/DVUI/favicons/favicon-16x16.png
image: https://m.media-amazon.com/images/S/pv-target-images/41b72610e8576d10e8b1842ea3bad6a08d000e2603695b76cfea812dfb2e018f.jpg
```


---

# 📄 2026-05-26

【今日の文字起こし】
今日も1日終わった、お疲れ様でした、今日は比較的頑張った方なんじゃないでしょうかとにもかくにも、Youtubeだったりとか、ちょっと堕落した生活習慣から抜け出すという意味では、今日頑張ってプールに行けたということは、非常に大きかったんじゃないでしょうか、えー、カレンダーに予定を入れたりできているのもポイント高いですね。


- 仮面ライダー電王、イマジン=遼太郎のイマジナリーフレンド説

- 未為、未位(ミー)に縛られる
	- 過去に予測した未来の自分と自己を比較することで、今の自分からつながる未来を見ることから逃れている
- 質より量。質より量。質より量。
- あっさり手放せば終わり。


```cardlink
url: https://www.primevideo.com/region/fe/detail/0P6NUYT7FCNSEFIPMZGS1QSURD/ref=atv_sr_fle_c_Tn74RA_1_1_1?sr=1-1&pageTypeIdSource=ASIN&pageTypeId=B0DJTJ73BM&qid=1779967417216
title: "Prime Video: シークレットNGハウス Season2 第2話"
description: "好評を博した二宮和也×若林正恭（オードリー）が仕掛ける究極の心理戦『シークレットＮＧハウス』の第２弾開幕！！戦いの舞台は、絶対にしてはいけない言動＝\"シークレットＮＧ\"が潜む密室。招待されたのは佐藤健、本田翼、ウエンツ瑛士、春日俊彰（オードリー）、吉村崇（平成ノブシコブシ）、若槻千夏、伊野尾慧（Hey! Say! JUMP）、一ノ瀬美空（乃木坂46）ら８名の人気芸能人。ＮＧが何かを知らない彼らは、ＮＧ行動をした際に鳴る警告音を手がかりに\"何がＮＧ行動か\"を推理！ＮＧに気づいた者は、回避するだけでなく、ライバルに\"ＮＧを踏ませる\"という、新たな駆け引きが始まる。一瞬の油断が命取りとなる中、最後まで生き残り、賞金を総取りするのは誰だ！？©︎Octagon"
host: www.primevideo.com
favicon: https://m.media-amazon.com/images/G/01/digital/video/DVUI/favicons/favicon-16x16.png
image: https://m.media-amazon.com/images/S/pv-target-images/41b72610e8576d10e8b1842ea3bad6a08d000e2603695b76cfea812dfb2e018f.jpg
```


---

# 📄 2026-05-27

映画見た。


```cardlink
url: https://photos.app.goo.gl/2XuhQGzmkq8iztwV6
title: "New photo · Thursday, May 28 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczPAttcK4kfpdztGHIIsYfqW_RQ_eymN9lhh2z3XmBxKZpvgCnxj-vCBP3VrHJ8gCnWi-0KYDpt6zXP-GC8yVtUNB__HwFAKEhlUNJlOQA1zBx_vOznN=w600-h315-p-k
```

おちゃにアクキーかってあげた
ラーメンスクエアに連れていった


```cardlink
url: https://photos.app.goo.gl/7bwvxbpNoMMPiU4S8
title: "New photo · Thursday, May 28 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczOOITatMKVT6_OwzinQAJUNGWF3SSSvks-nnc1OCGTZ1Y1C1luQ25H90g9ymLbp1YoSGJJrBUfENFz5mFP2ttOiPZTe6PLt1Z7jQtVFjFRDgR48w6fW=w600-h315-p-k
```


```cardlink
url: https://photos.app.goo.gl/t6ReBv3qTVHk3VPw8
title: "New photo · Thursday, May 28 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczMfBgiWm3Qke2mq24r3CVJga8nZmLui8mxKazWIEFaE5rq8pneKiBhDCbMcV9V1MxoGjy2esoIPsmIVvUdfqY73Lr7qm_966kx-eDnnhUOLM3PCPT-H=w600-h315-p-k
```


午前中ぜんぜん動けなかった
100ｍダッシュしたえらい
明日はパソコンしよう。


```cardlink
url: https://www.primevideo.com/region/fe/detail/0P6NUYT7FCNSEFIPMZGS1QSURD/ref=atv_sr_fle_c_Tn74RA_1_1_1?sr=1-1&pageTypeIdSource=ASIN&pageTypeId=B0DJTJ73BM&qid=1779967417216
title: "Prime Video: シークレットNGハウス Season2 第3話"
description: "好評を博した二宮和也×若林正恭（オードリー）が仕掛ける究極の心理戦『シークレットＮＧハウス』の第２弾開幕！！戦いの舞台は、絶対にしてはいけない言動＝\"シークレットＮＧ\"が潜む密室。招待されたのは佐藤健、本田翼、ウエンツ瑛士、春日俊彰（オードリー）、吉村崇（平成ノブシコブシ）、若槻千夏、伊野尾慧（Hey! Say! JUMP）、一ノ瀬美空（乃木坂46）ら８名の人気芸能人。ＮＧが何かを知らない彼らは、ＮＧ行動をした際に鳴る警告音を手がかりに\"何がＮＧ行動か\"を推理！ＮＧに気づいた者は、回避するだけでなく、ライバルに\"ＮＧを踏ませる\"という、新たな駆け引きが始まる。一瞬の油断が命取りとなる中、最後まで生き残り、賞金を総取りするのは誰だ！？©︎Octagon"
host: www.primevideo.com
favicon: https://m.media-amazon.com/images/G/01/digital/video/DVUI/favicons/favicon-16x16.png
image: https://m.media-amazon.com/images/S/pv-target-images/41b72610e8576d10e8b1842ea3bad6a08d000e2603695b76cfea812dfb2e018f.jpg
```


---

# 📄 2026-05-28


### 国立温泉
☞[[♨：「国立温泉 湯楽の里」|♨「国立温泉 湯楽の里」]]

- [ ] スケジュール入力
- [ ] ほしい物リスト
- [x] 返品メール･定期便解約3/4


[[🄶：2026年免許取得計画]]
```cardlink
url: https://g.co/gemini/share/1054a61bc93c
title: "‎Gemini - direct access to Google AI"
description: "Created with Gemini"
host: g.co
favicon: https://www.gstatic.com/lamda/images/gemini_sparkle_aurora_33f86dc0c0257da337c63.svg
image: https://www.gstatic.com/lamda/images/gemini_aurora_thumbnail_4g_e74822ff0ca4259beb718.png
```



```cardlink
url: https://www.primevideo.com/region/fe/detail/0P6NUYT7FCNSEFIPMZGS1QSURD/ref=atv_sr_fle_c_Tn74RA_1_1_1?sr=1-1&pageTypeIdSource=ASIN&pageTypeId=B0DJTJ73BM&qid=1779967417216
title: "Prime Video: シークレットNGハウス Season2 第4話"
description: "好評を博した二宮和也×若林正恭（オードリー）が仕掛ける究極の心理戦『シークレットＮＧハウス』の第２弾開幕！！戦いの舞台は、絶対にしてはいけない言動＝\"シークレットＮＧ\"が潜む密室。招待されたのは佐藤健、本田翼、ウエンツ瑛士、春日俊彰（オードリー）、吉村崇（平成ノブシコブシ）、若槻千夏、伊野尾慧（Hey! Say! JUMP）、一ノ瀬美空（乃木坂46）ら８名の人気芸能人。ＮＧが何かを知らない彼らは、ＮＧ行動をした際に鳴る警告音を手がかりに\"何がＮＧ行動か\"を推理！ＮＧに気づいた者は、回避するだけでなく、ライバルに\"ＮＧを踏ませる\"という、新たな駆け引きが始まる。一瞬の油断が命取りとなる中、最後まで生き残り、賞金を総取りするのは誰だ！？©︎Octagon"
host: www.primevideo.com
favicon: https://m.media-amazon.com/images/G/01/digital/video/DVUI/favicons/favicon-16x16.png
image: https://m.media-amazon.com/images/S/pv-target-images/41b72610e8576d10e8b1842ea3bad6a08d000e2603695b76cfea812dfb2e018f.jpg
```

 
- カツ丼大盛り、意外とお腹にたまる
```cardlink
url: https://photos.app.goo.gl/YVP4SKw39FibWjs8A
title: "New photo · Friday, May 29 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczNsmNij9iyyZCdCZtHy-nJ-XqkCr1yIKYmuYwJKGhImdvlvFZDrr8UCib2tj6YY6C2pKyWo6_gnpQYNXen9EE2PNFfbiDqQD6DrwvA35JJwxYJ67fXB=w600-h315-p-k
```

```cardlink
url: https://photos.app.goo.gl/zWTbUPYZHs6Dv2dE8
title: "New photo · Friday, May 29 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczNKBH3JqkLoZ82KDxUeg9bJS-G55iK2AJ2PTyS4NcSipJY7J3CrIrCEtoKB8UfdyjkMFOBxnExM0D2_djdc6w3r79mxrSG37_nHzL15Qq1keJMM02Jo=w600-h315-p-k
```

- 回数券を買う
	- 7枚ストック
	- 3枚景品
⇒カードチャージ式だったので、それ自体緊急時財布にいれるか。
```cardlink
url: https://photos.app.goo.gl/zNDsg2nEC32iRAyH7
title: "New photo · Friday, May 29 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczP41ZEgjLzW64pqWN-wGaKcxnOx9AV8pvOKozsTgRtYTcINRW7ZLAmHkfExnJBxnPiheoM9mZ8px0JN4F8ZbasemX-e7iR3C970BOnZiSnuJq4zULWl=w600-h315-p-k
```

```cardlink
url: https://photos.app.goo.gl/eUPzgSmiUaobhtHm9
title: "New photo · Friday, May 29 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczOUmV_h72iEg1xTh2S4XdrXzxejMaYmB9YQtKQrtjDnbcOi_nhV7QKu6Dzz8mfv3zL4V9-by2kzggkoL2bmeiPo6TbvscLth9zEk1I4jwbaZTkffxEU=w600-h315-p-k
```


---

- 5万円貯金

```cardlink
url: https://photos.app.goo.gl/LVrZe9eVK26XFigB8
title: "New photo · Friday, May 29 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczMQU9zQkGF11Z94XEzt0uNBUgoZSWesUve6XGWY0-_u9e8sNLTreFyM0RKDJx9LmaoReT4nTH9tN1hYqWzO-56Q1YxBvSgT9XdWzhs2TkShB7h_-qsw=w600-h315-p-k
```

```cardlink
url: https://photos.app.goo.gl/CZjghzB6VjU8khBW6
title: "New photo · Friday, May 29 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczOZ6p7jILZXbILQ4KC4s1Di9NIC_3ezU4zwdkV-Zy6qupk2tU6B8zIicu6xfTBq9NL9fu-T6iIJB3OnVfjxqvEMiK7mR8MKbdMrB9eJ4L3j9dEj7yFE=w600-h315-p-k
```

```cardlink
url: https://photos.app.goo.gl/VRYSwGk7do6aBM499
title: "New photo · Friday, May 29 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczPmPeq_3ysOt9M_9VyEuyOId7GSPsfW1-jcwZkeaCviK5dH-4DFd9PfxiWjawRqR0fEUbndhYmMYu1b7rLxJMNFIsOBuRBn7HsdhdfN9v3hKVmWiq_g=w600-h315-p-k
```


タブレットカバー届く

```cardlink
url: https://photos.app.goo.gl/WWnTcDdvpaF9rCed8
title: "New photo · Friday, May 29 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczNAWKDs8NhLKF_Rh_hKCMP7fM9ilEkDvlEux_JTQJU63V61yXC2gU96eoinyAg9ZTiU-agZk37mCFRtdVVWyC4BncxCRWrZ7-sRNEIC3hQd9-1E9sxi=w600-h315-p-k
```



箇条書きにしてくわ。
･Obsidianのデイリーノートつけれるように。
･写真データ削除
･SHTの予定入力


### ────────■
---
#### 【ファイルLog】
![[☷│2026-05-28.base]]


---
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-05-28.base|☷│2026-05-28]]
- [[🄶：2026年免許取得計画]]
- [[デイリーノート修正ver1.1]]
- [[無題のファイル 1.base|無題のファイル 1]]
- [[山口晃央/Past：山口晃央の過去/DFB/│25歳~30歳/〔2026年〕/〔5月〕/2026-05-28/無題のファイル.base|無題のファイル]]

---

# 📄 2026-05-29

---

# 📄 2026-05-30

---

# 📄 2026-05-31

---

# 📄 2026-06-01

---

# 📄 2026-06-02








### ────────■
---
#### 【ファイルLog】
![[☷│2026-06-02.base]]


---
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-06-02.base|☷│2026-06-02]]

%% End Waypoint %%

---

# 📄 2026-06-03

##### 

%% Begin Waypoint %%
- [[✎：SHT常設スタッフに話す内容]]
- [[✎：ビジョン(SHTアウトプット用）]]
- [[✎：今できること(SHTアウトプット用)]]
- [[✎：山口晃央の過去(SHTアウトプット用)]]
- [[☷│2026-06-03.base|☷│2026-06-03]]

%% End Waypoint %%

---

# 📄 2026-06-04

---

# 📄 2026-06-05

---

# 📄 2026-06-06

---

# 📄 2026-06-07



---

# 📄 2026-06-08

### <span style="color: dimgray;">──────────────────────</span>
### 【帰宅･架空バンド名ゲーム】〔25:00~27:00〕

  - [[│架空バンド名]]を考えるゲームで30個近い名案を出す
- ちょっと[[│カリンバ]]をやって寝る

### <span style="color: dimgray;">──────────────────────</span>
### 【国立温泉】〔19:00~25:00〕
☞[[♨：「国立温泉 湯楽の里」|♨「国立温泉 湯楽の里」]]

- 社会的快楽分析
☞[[🄶：社会的｢幸せ｣分析]]

```cardlink
url: https://g.co/gemini/share/1223b6515e7d
title: "‎Gemini - direct access to Google AI"
description: "Created with Gemini"
host: g.co
favicon: https://www.gstatic.com/lamda/images/gemini_sparkle_aurora_33f86dc0c0257da337c63.svg
image: https://www.gstatic.com/lamda/images/gemini_aurora_thumbnail_4g_e74822ff0ca4259beb718.png
```


- ミーティング
- 食事
	- ハンバーグ定食はタンパク質の量が少なかった。
	- カツ丼([[2026-05-29|2026-05-29]])の方がいい
	- ミーティングに参加しながらの食事

```cardlink
url: https://photos.app.goo.gl/YQhwHfktTgnTp85JA
title: "New photo · Tuesday, Jun 9 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczPm9Md2UWU2ooHMVZcEC5E-kAf9ZyupPh-RAeDAiC3qPNnujvTHegjCIJ-DoMIFOtBM7ouiUZDyRFUVeZuSxGEwGmi0i6lSnHZWfGyDYiCpWx_2etMG=w600-h315-p-k
```

```cardlink
url: https://photos.app.goo.gl/DsnHP1MYCYgCdHaW8
title: "New photo · Tuesday, Jun 9 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczO4b8GCwjKEvZah-DR2jKs2RRVCOh16QXhBsVVpySqeu6QSuBJlhs_KATBEoGZNdpa7xuq3efJiFXsFO1nbS3FcYs2AV0Vv622m68KqsN34Y91YKZI0=w600-h315-p-k
```


- 仮面ライダー電王28,29話視聴
☞[[🏍️：仮面ライダー電王]]
	- クライマックスフォーム登場回
### <span style="color: dimgray;">──────────────────────</span>
### 【部屋掃除】〔17:00~18:45〕
- 結構捗った。偉い。

### <span style="color: dimgray;">──────────────────────</span>
### 【食事･TVer視聴】〔14:00~16:00〕
- [[👤 佐々木七海]]とちるちるタイム
- [[仮面ライダーゼッツ]]視聴
	- ノクスミッドナイトシャドウ登場回
- コナン×プリキュアコラボ回
- [[👤 山口まどか]]のゲリラ扱きが不快だったのでLINEでメッセージ
```cardlink
url: https://photos.app.goo.gl/NEEK8iPJ7brg5nbV9
title: "New photo · Tuesday, Jun 9 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczOA_EGs__5vbNrjYdBW4DYaLPQgdW1Tjiv_pENjusV5hKeQHcpV6gR8JGNzDxew1yB5GHBF1yPuby9hjWIxQMU3frn79UDEeNEwYsGF_nCCvc6C2FfB=w600-h315-p-k
```

### <span style="color: dimgray;">──────────────────────</span>
### 【射精・二度寝】〔11:30~13:30〕
- 3日分の欲求を発散。背筋が震えるほど質の良い自慰。
- 犬を癒やすYoutubeを見て二度寝
### <span style="color: dimgray;">──────────────────────</span>
### 【起床・朝トレ】〔10:00~11:30〕
- [[│カリンバ]]練習
### ────────■
---
#### 【ファイルLog】
![[☷│2026-06-08.base]]


---
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-06-08.base|☷│2026-06-08]]
- [[🄶：社会的｢幸せ｣分析]]

%% End Waypoint %%

---

# 📄 2026-06-09




### <span style="color: dimgray;">──────────────────────</span>
### 【ちるちるタイム（ライダー視聴）】〔~25:00〕

### <span style="color: dimgray;">──────────────────────</span>
### 【奢りマダミス】〔21:00~23:30〕

### <span style="color: dimgray;">──────────────────────</span>
### 【筋トレ・夕飯】〔19:30~〕

### <span style="color: dimgray;">──────────────────────</span>
### 【仮眠】〔16:00~18:30〕
### <span style="color: dimgray;">──────────────────────</span>
### 【タムと雑談】〔~15:30〕
- 考えた[[│架空バンド名]]評価してもらう
- 冷水シャワー
### <span style="color: dimgray;">──────────────────────</span>
### 【朝食】〔~14:30〕
- 
### <span style="color: dimgray;">──────────────────────</span>
### 【なちゃと雑談】〔11:00~13:30〕

### <span style="color: dimgray;">──────────────────────</span>
### 【朝トレ】〔10:00~11:00〕


### ────────■
---
#### 【ファイルLog】
![[☷│2026-06-09.base]]


---
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-06-09.base|☷│2026-06-09]]

%% End Waypoint %%

---

# 📄 2026-06-10


### 【自室で食事・ちるちるタイム】〔21:30~25:00〕
- [[🏍️：仮面ライダー電王]]を５話見る
	- [[10_電王：ライナーフォーム]]登場

### <span style="color: dimgray;">──────────────────────</span>
### 【SHT：Obsidian入力作業】〔20:30~21:10〕
- Daisoでながら作業セット購入

### <span style="color: dimgray;">──────────────────────</span>
### 【SHT：Obsidian入力作業】〔17:00~20:30〕
- 地名入力
- DFB設定
### <span style="color: dimgray;">──────────────────────</span>
### 【昭和記念公園：少林寺拳法】〔16:00~17:00〕
☞DAISOでウエットティッシュ購入
☞[[SKK =「昭和記念公園」]]
- 基礎的な剛法技の練習
- 足元の蛇口が使いやすい、足を洗うのに最適
- [[│アーシング]]としても効果大
### <span style="color: dimgray;">──────────────────────</span>
### 【自宅で食事・コンディショニング】〔13:00~15:30〕
- 朝食(食べ過ぎる)
- 冷水シャワー
- 緑茶コーヒー
- ホットミルク



---
#### 【ファイルLog】
### ![[☷│2026-06-10.base]]


---
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-06-10.base|☷│2026-06-10]]

%% End Waypoint %%

---

# 📄 2026-06-11

- 1日全体的に筋肉痛で、鬱々としている



### 【なちゃとちるちるタイム】〔~25:00〕
- [[🏍️：仮面ライダー電王]]1話
- にじさんじ遊び王シーズン１
- Obsidian入力作業
☞[[▣：「学びの部屋」]]
### <span style="color: dimgray;">──────────────────────</span>
### 【リビングで食事】〔~22:00〕
- アジフライと鶏肉の炒め物
- 父親と[[「幸せカナコの殺し屋生活」]]視聴
- 
### <span style="color: dimgray;">──────────────────────</span>
### 【駅前で買い物】〔~19:00〕
- BICカメラでUSB延長コード
### <span style="color: dimgray;">──────────────────────</span>
### 【ヤマト運輸で返品】〔17:45~18:15〕
- [x] 全商品を返品


### <span style="color: dimgray;">──────────────────────</span>
### 【昼寝】〔15:00~17:30〕
あまりにも筋肉痛で昼寝


%% Begin Waypoint %%
- [[☷│2026-06-11.base|☷│2026-06-11]]

%% End Waypoint %%

---

# 📄 2026-06-12

### 【自室：就寝準備・仮面ライダー電王視聴】〔20:00~23:00〕
- 21:00に寝るつもりだったが、そこからゆっくり仮面ライダー電王を視聴する
- 結局23:00頃に就寝（翌日の早起きに備える）
### <span style="color: dimgray;">──────────────────────</span>
### 【自宅：夕食・入浴】〔19:00~20:00〕
- 20:00前後にはご飯と風呂を済ませておく
### <span style="color: dimgray;">──────────────────────</span>
### 【自室：引きこもり・スマホ依存モード】〔11:00~19:00〕
- 1日中家から一歩も出た記録がない状態
- 何をしていたか詳細は不明だが、おそらく超スマホ依存症状態に陥っていたと思われる
- 翌日（土曜日）の仕事に向けて「5時起き」のプレッシャーを感じつつも、時間のコントロールが崩れる
- （※結果として翌朝は5時に一度目が覚めるも、何度もスマホを見ては二度寝を繰り返し、事前準備ができずに仕事の道中で鬱々とする原因を作る）
【ファイルLog】
![](☷│2026-06-12.base)
【DailyData】
%% Begin Waypoint %%
- [[☷│2026-06-12.base|☷│2026-06-12]]

%% End Waypoint %%

---

# 📄 2026-06-13

### 【自室：早めの就寝】〔21:00~22:00〕
- 前日の夜更かしや朝の二度寝によるリズムの乱れ、雨の中の稼働による疲労もあり、早めの22:00頃には就寝
### <span style="color: dimgray;">──────────────────────</span>
### 【自宅：夕食・リラックス】〔20:00~21:00〕
- 帰宅後、体調とメンタルを整えるために軽く食事を済ませる
### <span style="color: dimgray;">──────────────────────</span>
### 【BIC立川：営業仕事（合同催事）】〔09:30~20:00〕
☞[[👔：「ビックカメラ立川店」]]
- BIC立川店にてシロアリ駆除業者のロイさんと合同催事の仕事
- 雨のせいか客足が少なく、朝の移動時は二度寝の罪悪感や事前準備不足から鬱々としたメンタルを引きずる
- 本日の結果は、ギリギリで獲得したアポイントが1件のみ
- 相方はタイミーから来た素朴で真面目な学生（中央大附属から中高一貫で中央大に進学、経済を勉強中とのこと。やや印象は薄め）
- 個人としては苦戦し、自分よりもロイさんの方がアポを取れていたが、最終的に店舗全体の利益には繋がったため結果オーライとする
### <span style="color: dimgray;">──────────────────────</span>
### 【自宅〜立川：仕事支度・移動】〔08:00~09:30〕
- 何度もスマホを見ては二度寝を繰り返した末、なんとか活動を開始して仕事へ向かう
【ファイルLog】
![](☷│2026-06-13.base)
【DailyData】
%% Begin Waypoint %%
- [[☷│2026-06-13.base|☷│2026-06-13]]

%% End Waypoint %%

---

# 📄 2026-06-14

### 【自室：夜のちるちるタイム・就寝】〔21:00~24:00〕
- 家に帰り、食事しながらカノジョと見ていた仮面ライダー電王の最終三話（第47話〜第49話）を視聴
- ついに1シリーズを完走し、電王ロスになる
- 24:00頃に就寝
### <span style="color: dimgray;">──────────────────────</span>
### 【泉体育館：プール運動】〔20:00~21:00〕
- 疲れて帰ってきてから、閉店30分前に泉体育館のプールに駆け込み運動を行う
### <span style="color: dimgray;">──────────────────────</span>
### 【BIC立川：営業仕事】〔09:30~20:00〕
☞[[👔：「ビックカメラ立川店」]]
- 09:30からBIC立川で通常通り仕事
- 以前八王子店で一緒だった教員資格を持つ29歳の塩入さんと一緒になる
- 人出が多かったことと、朝の事前準備の甲斐もあってか、その日は6件獲得する
### <span style="color: dimgray;">──────────────────────</span>
### 【自宅：仕事支度・お弁当作り】〔08:00~09:15〕
- 08:00からお弁当を作って仕事の支度をする
- 09:00すぎに家を出発する
### <span style="color: dimgray;">──────────────────────</span>
### 【自室：Gemini連携・事前仕事準備】〔07:15~08:00〕
- 07:15頃に目覚め、少しスマホなどを触る
- 07:25〜08:00でGeminiと事前の仕事準備を行い、営業仕事のシミュレーションをする
【ファイルLog】
![](☷│2026-06-14.base)
【DailyData】
%% Begin Waypoint %%
- [[☷│2026-06-14.base|☷│2026-06-14]]

%% End Waypoint %%

---

# 📄 2026-06-15

### 【自室：夜のちるちるタイム・就寝】〔22:00~24:00〕
- 22:00すぎに再びなぁちゃんと電話する
- 軽く食事をする
- 24:00頃に就寝
### <span style="color: dimgray;">──────────────────────</span>
### 【自室：仕事ミーティング・動画視聴】〔21:00~22:00〕
- 21:00からの仕事のZoomミーティングに、全部ミュートにしながら参加
- ミーティング中も「大脱出」シーズン3の最終話を見ながらながら作業
### <span style="color: dimgray;">──────────────────────</span>
### 【立川立飛周辺〜自室：移動・動画視聴】〔16:00~21:00〕
- 16:00に日光を浴びるためにららぽーとへ行く
- 移動中や外出中も「大脱出」の視聴を継続
- 帰る頃には夜20:00を回っており、そのまま自室でもダラダラと見続ける
### <span style="color: dimgray;">──────────────────────</span>
### 【自室：動画一気見】〔14:00~16:00〕
- 何か見ていたくなったので、DMMTVオリジナルの「大脱出」をシーズン2から見始める
- そのまま一気にシーズン3まで見進める（最終的に合計14話視聴）
### <span style="color: dimgray;">──────────────────────</span>
### 【自室：起床・カノジョと動画視聴】〔11:00~14:00〕
- 11:00頃に起床（本当は昨日温泉に行く予定だったが家でゆっくり過ごす）
- 14:00頃までカノジョと仮面ライダー剣（ブレイド）を第3話まで一気見する
【ファイルLog】
![](☷│2026-06-15.base)
【DailyData】
%% Begin Waypoint %%
- [[☷│2026-06-15.base|☷│2026-06-15]]

%% End Waypoint %%

---

# 📄 2026-06-16


### 【帰宅】〔25:45~27:30〕
- エロ動画漁り
- 射精
- 就寝
### <span style="color: dimgray;">──────────────────────</span>

### 【国立温泉：入浴・ちるちるタイム】〔20:30~25:00〕
☞[[♨：「国立温泉 湯楽の里」]]
- 30分くらいカノジョと買ったものの品評会
- 風呂入ってObsidianの[[DFB]]整理
### <span style="color: dimgray;">──────────────────────</span>
### 【多摩川：カリンバ練習】〔19:30~20:30〕
- ☞国立温泉の隣のバリューで空腹しのぎに魚肉ソーセージを購入
- 多摩川の河川敷で暗闇の中カリンバの練習
### <span style="color: dimgray;">──────────────────────</span>
### 【立川駅周辺：なぁちゃんと買い物】〔18:00~19:30〕
- ☞BICの上のセリアで風呂桶と手桶のチャームストラップを購入
- 駿河屋でなぁちゃんと買い物
### <span style="color: dimgray;">──────────────────────</span>
### 【昭和記念公園：少林寺拳法】〔17:30~18:00〕
- ☞[[SKK =「昭和記念公園」]]
- 少林寺拳法×アーシング
### <span style="color: dimgray;">──────────────────────</span>
### 【自宅：間食・出発準備】〔15:30~17:30〕
- リビングで父親が切ってくれた新鮮なスイカをたらふく食べる
### <span style="color: dimgray;">──────────────────────</span>
### 【DAISO：買い出し】〔14:30~15:30〕
- 収納用品（B4大黒メッシュポーチとそれを入れるかご）を購入
### <span style="color: dimgray;">──────────────────────</span>
### 【外散歩・セイムス】〔14:00~14:30〕
- セイムスで保存用午後ティーと今飲む用のフルーツクラフトBOSSを購入
### <span style="color: dimgray;">──────────────────────</span>
### 【自宅で食事・コンディショニング】〔12:30~14:00〕
- 朝食兼昼食（納豆ご飯と鍋）
### <span style="color: dimgray;">──────────────────────</span>
### 【自室：起床・朝のちるちるタイム】〔10:30~12:30〕
- 10:30頃起床
- カリンバの練習をしたり動画見たりして過ごす
- 12:30頃にリビングへ移動
- エロ動画、射精
【ファイルLog】
![](☷│2026-06-16.base)
【DailyData】
%% Begin Waypoint %%
- [[☷│2026-06-16.base|☷│2026-06-16]]
- [[全ファイル名リスト仮]]

%% End Waypoint %%

---

【関連ファイル】

|                        name                        |
| -------------------------------------------------- |
|                ➴│［ワナビー］┆🌟→｢岡田 茂吉｣                 |
| ➴│［ワナビー］┆🌟→｢岡田 茂吉｣ (conflict 2026-06-16-23-41-02) |
|                 ➴│［模倣］┆🐨→｢岡田 茂吉｣                  |


---

# 📄 2026-06-17

### 【ららぽーとフードコート：編集・記録作業】〔13:00~13:41〕
- 自身の体調をコントロールし、環境を変えてタスクを遂行できたことを自己評価。
- 動画編集作業および記録作業に従事。

### 【自宅：思考停止・エネルギー回復】〔12:00~13:00〕
- 軽い食事を摂取（胃袋が収縮しており少量で満腹）。
- YouTubeを視聴しつつ、エネルギー不足により思考停止状態で過ごす。
- 超フラフラ

### 【自宅：起床・ルーティン】〔09:30~12:00〕
- 09:30に起床。
- YouTube動画やエル動画を視聴し、射精を行う。
- 12:00前にリビングへ移動し食事を試みる。

### 【身体コンディション：疲労・デトックス回顧】〔昨晩～今朝〕
- 前日の運動、温泉でのデトックス、5kmの自転車移動によりエネルギーが枯渇。
- 極度の疲労感により、体に力が入らず動けない状態が続く。

【ファイルLog】
![](☷│2026-06-17.base)
【DailyData】
%% Begin Waypoint %%
- [[”6月18日(明日)の職業訓練校飲み会行くか迷う”]]
- [[”顧客電話するの面倒くさいしコワイ”]]
- [[☒│2026-06-17]]
- [[☷│2026-06-17.base|☷│2026-06-17]]

%% End Waypoint %%

---

# 📄 2026-06-18




### 【自宅：就寝】〔26:00~〕
- 自室での活動を終え、26:00に就寝した

### <span style="color: dimgray;">──────────────────────</span>

### 【自宅：食事・娯楽とカリンバの練習】〔23:15~26:00〕
- 電車での移動を経て24:15頃に帰宅し、自宅で食事を摂る
- 特撮作品『仮面ライダー剣』を1話視聴してリフレッシュした
- 自室に戻った後、カリンバの演奏練習に取り組んだ

### <span style="color: dimgray;">──────────────────────</span>

### 【居酒屋：懇親と手品の披露】〔21:45~23:15〕
- 目的地にてメンバーと合流し、全員で記念写真を撮影した
- 仕事の話題、海外文化、原罪や人間関係にまつわる悩み相談、AIの可能性など多岐にわたるテーマで対話を行い、「社会との接続」や深い交流の時間を共有した
- 会の締めくくりとして手品（マジック）を披露し、参加者を楽しませて解散した

### <span style="color: dimgray;">──────────────────────</span>

### 【新宿・ドラッグストア：移動と栄養補給】〔20:40~21:45〕
- 電車を利用して新宿まで移動し、移動中は仮眠をとって体力を回復させた
- 21:30頃にドラッグストアへ立ち寄り、カロリーメイトを購入して軽めの空腹を満たし、低下していた身体のエネルギーを補給した

### <span style="color: dimgray;">──────────────────────</span>

### 【移動中・路上：自己対話と認識の変容】〔18:00~20:40〕
- 自身の内面に渦巻く不安や身体の違和感、未完了のタスクがもたらす精神的影響について深く内省した
- 歩行中に選挙ビラを受け取り、候補者と目を見て笑顔で会釈を交わした瞬間、閉塞感から抜け出し「大丈夫」と思える感覚が開ける体験をした
- 以下の書き置きメモ（随想・発見）を記録した：
```

20:00

･頭の中で｢死ね死ね｣と流れているこの感じ。

これをこそ私は記録し未来で人を救う形ある武器変えたかったのではないか。頭に雲がかかる。前頭葉が働かない。自然に触れてないからか？温泉もアーシングも一昨日した。運動不足か？火曜日に少林寺拳法、日曜日にプールした。部屋が汚いからか？確かに布団はジメジメしてる。家に帰って掃除した方がいいだろう。やっぱり、未完了のタスクがあること、思ったほど今自分がすべきことや挑戦したいことと向き合えていないことが不安として蓄積していてそれが言語化されず解消する期限に目処がないのが大きいのか。今、これを入力しながら歩いていたところ選挙ビラを貰い、候補者の人と目を見て笑顔で会釈できたのだが。そんなちっちゃなことで、凄く今、｢大丈夫｣な感じが開けてきた。やはり、単に人と会話し｢社会と接続｣してる感じを得ることが足りていないのかな、彼女との会話も家族との会話も社会ではない、そう思ってるからかな。まあ兎にも角にも一昨日飯食わずに運動してデトックスして昨日下痢気味のままエネルギーダウンしちゃってたから、その影響が尾を引いてるだけかもしれないし。これが後々、｢自分は醜い｣と思ってる人達と希望の世界を接続する武器になればいいな。

･気持ちはスッキリしてきたが、体の不安感が抜けない。一昨日の運動後空腹風呂(粗悪な魚肉ソーセージのみ間食)が腸の調子を揺さぶっているような感じだ。あれから下痢も酷かったし、栄養が抜け落ちてしまった感じ

･結局、私は｢不安｣なのであり、それが自分で受け入れられていない。不安になったら、それを解決する能動こそを信じるべきなのだが、幼い頃から、不安に思っては行けない、不安に思ったら神を信じること、を教育されてきた影響かもしれない。

```

### <span style="color: dimgray;">──────────────────────</span>

### 【ビックカメラ：連絡作業】〔18:20~19:30〕
- ビックカメラの店舗スペースにて、必要な連絡作業を集中して実施した
- 以下の書き置きメモ（随想・発見）を記録した：
```

･未達成タスクの影響か、ここ3~4日ほどの間鬱々としている

･DFBについて

│･発見･知覚･学び･感想などについては要約の後に『』による引用形式で一語一句入れさせるのが良いのでは

```

### <span style="color: dimgray;">──────────────────────</span>

### 【自宅・自室：休息とリフレッシュ】〔17:40~17:59〕
- 自室での個人的な休息（エロ動画の視聴および射精）

### <span style="color: dimgray;">──────────────────────</span>

### 【自宅：インプット】〔17:00~17:40〕
- YouTubeを視聴し、台湾論やAI活用についての情報収集および知識のアップデートを行った

### <span style="color: dimgray;">──────────────────────</span>

### 【自宅：スクリプト作成タスク】〔~16:45〕
- BIC太陽光のアポ架電スクリプト作成作業に従事し、実務基盤を整理した

### 【ららぽーと：作業の開始と自己の再定義】〔15:15~15:40〕
- ららぽーとにて作業を開始。謎解きで得た脳の活性化状態を維持している
- 「仕事」と「自己」を同一視していた癖を自覚し、その切り分けこそが重要であると認識
- 昨日まで「否定される恐怖」から回避していたタスクに対し、感情の切り離しを行うことで向き合う意欲が高まっている

### <span style="color: dimgray;">──────────────────────</span>

### 【自宅：食事と謎解き・自己分析】〔13:00~15:15〕
- 13:00に起床。比較的良好なコンディションで、やる気とエネルギーに満ちている
- 14:30頃まで食事をとりながら、久しぶりに謎解きアプリに没頭
- 謎解きを通じて脳が活性化し、自身の能力に対する自己効力感が大幅に向上している
- 昨日までの惰性的な気分から一転し、自分の中の秩序を拡張したいという意欲が芽生えた
- 食器の片付けなど、身の回りのルーチンを完了させてから外出

### ────────■

#### 【ファイルLog】
![](☷│2026-06-18.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[＂訓練校同窓会に行くべきか＂]]
- [[☷│2026-06-18.base|☷│2026-06-18]]
- [[🗓：「職業訓練校同窓会」]]

%% End Waypoint %%

---
#### 【出力用追加テキスト】

##### ○本日出力ファイル


---

# 📄 2026-06-19

---

# 📄 2026-06-20

---

# 📄 2026-06-21



### 【父の日の買い物】〔20:45~21:30〕
- BICで「SPADE＆SPALLOWS」を購入
- 半額で1500円くらいだったので、ドンキでナッツも購入
-
```cardlink
url: https://photos.app.goo.gl/Wm71gbrC4rREUUpo8
title: "New photo · Monday, Jun 22 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczMFCysaMQb_42msNMdSysLonu6v69G-EBL-LIPqjLpToAHlEz__vyv7M2tDkiGLp0Q3RC9K9aoSxW1YSFcAMpakwZ19KIm3D1IirThDTTP20TFGbyOz=w600-h315-p-k
```



### 【】〔~〕
- 風邪アピールしといたけど、ノセボ体質だし本当に風邪っぽくなるかも
- 宇佐美亜希子さん、苦手かも
	- 会話のパターンが読めない｡あのパターンのノリ方知りたい
	- 単に動じずにツッコミ入れてればいいのか
- "やらなくてもいい環境"･"代わりにやってくれる人"が居るだけで一気に脳死する
- マスクも同様に、感覚神経を晒される事を辞めることで神経が壊死する

> [!info] タイトル（省略すると「Info」になります）
> ここに本文を記述します。
> 2行目以降も同様に `>` を先頭に付けます


### <span style="color: dimgray;">──────────────────────</span>

---

# 📄 2026-06-22



- 1日殆ど、Youtubeを見てねて過ごす
- 家から出た記録はなく、おそらくは丸一日タブレットを見ていた
- 夜23時に、DMMで金田一少年の事件簿を見ながら寝落ち


|          name           |
| ----------------------- |
|     ＂訓練校同窓会に行くべきか＂      |
| ☷│👔：「BIC×コジマ東大和店」.base |
|    👔：「BIC×コジマ東大和店」     |


---

# 📄 2026-06-23


### 【自室：一人でマジック番組を録画・Upload】〔25:45~27:00〕
- エロ漫画で射精してそのまま睡眠

### <span style="color: dimgray;">──────────────────────</span>
### 【自室：カノジョとライブ視聴をしながらの作業】〔23:30~25:45〕

- 自室にてカノジョと一緒に[[👤 轟はじめ]]の生誕祭ライブを見ながら作業を行う

```cardlink
url: https://www.youtube.com/live/Zcx1344XAmI?si=5X-5F3r1I9U-s8ZI
title: "【3DLIVE】Rise In Motion【轟はじめ】 #轟はじめ生誕祭2026"
description: "🐧グッズ轟はじめ 誕生日記念2026⚡️■販売ページURLhttps://shop.hololivepro.com/products/todorokihajime_birthday_2026■グッズ販売期間（受注販売）2026年6月7日(日) 21時00分 ～ 2026年7月13日(月) 18時00【サムネイル】素敵なサムネお写真：ぴり辛ココナッツ様（https://x.com/pkokonatu ）素敵なサムネデザイン：KEHAI様( https://x.com/kasuka_oo0oo )【素敵なゲスト様】@HoshimachiSuisei @HakosBaelz @IsakiRiona @MizumiyaSu 【振付】ARAKIYUKA inc.　https://arakiyuka.com/チームミユキ「タップダンサー」井田 彩花（チームミユキ）「バックダンサー」ARAKIYUKA inc.　https://arakiyuka.com/【映像制作】Kanauru　https://x.com/kanauruえーれ　https://x.com/Ehre_origine?s=20 SIKAKU株式会社Eunho　https://x.com/keh99428?s=20【Special Thanks】トライフロンティア株式会社ChrisP https://x.com/chrisP_chelsea合同会社 VESSEL LIFE暁 https://twitter.com/akatsuki7guitarum. https://x.com/um_umarerusa-sara釼田 駿 https://x.com/tsuru_shun07SAZAToshiyuki https://twitter.com/toshi2_basses?lang=jaraihiva https://x.com/hbr_moka_komagiKoudai https://www.instagram.com/koudai523425_gt/?igsh=ZTA1bXRscGVrOGlt&utm_source=qr株式会社サウンド・シティ永野紫音中山太陽岡田妃由堀口彩花【制作】COVER Corp. STUDIO ￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣✨オリジナル曲宣伝✨NEW！！🏀【Original】Dunk/轟はじめ🏀https://youtu.be/Gs9wZorLo40?si=PVMXQTBakgMnxaR7💜【Original】ちゃちゃもにゃ/轟はじめ💜https://www.youtube.com/watch?v=erTbmrY9nUs💜【Original】BANZAI-轟はじめ💜https://www.youtube.com/watch?v=AuVjtPcxlfE💜【Original】Countach/轟はじめ【Official MV】💜https://www.youtube.com/watch?v=eB2kswPDFaI￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣✨COVER曲宣伝✨BANDAGE-Ayumu Imazu /coverhttps://www.youtube.com/watch?v=m-5mb06LFOA夜咄ディセイブ/歌ってみた【轟はじめ/ReGLOSS】https://www.youtube.com/watch?v=cmf2wvZrJAo踊り子-Vaundy(Cover)/轟はじめ【歌ってみた】https://www.youtube.com/watch?v=F_Os6XIXMVoきゅうくらりん /轟はじめ【歌ってみた】https://www.youtube.com/watch?v=zlcVRM35cl8￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣ハッシュタグ配信ご感想　＃ぶんぶんばんちょーFA　　　　　#はじめ武勇伝￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣【💿 アルバム情報💿 】◆ReGLOSS 2nd Album “Snapshot”2025年11月12日(水)に発売決定！＜予約はこちら＞https://cover.lnk.to/Snapshot＜リリース記念イベント＞https://www.hmv.co.jp/news/article/250827116/◆「アワータイムイエロー」Streaming & Download2025.09.14 0時よりデジタルリリース開始！https://cover.lnk.to/jr1tEQ01￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣◆ReGLOSS 1st Live “Flashpoint”2025年12月16日(火)に有明アリーナにて開催決定！https://flashpoint.hololivepro.com/🎫現地チケット1次先行受付中！🎫＜受付期間＞2025年9月13日(土) 21:00 ～ 2025年9月28日(日) 23:59＜現地/配信チケットページ＞・JP ：https://flashpoint.hololivepro.com/ticket・EN：https://flashpoint.hololivepro.com/ticket-en◆ホロライブプロダクションOFFICIALHP:https://hololivepro.com/X:https://twitter.com/hololivetv￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣※轟はじめと関係のないところで私の名前を出すことはお控えください。他の方にご迷惑にならないよう、楽しくご視聴ください。※ホロライブプロダクションから未成年の視聴者の方々へのお願い[カバー 未成年者の方々へ]で検索してお読みいただくか、下記リンクをご確認の上、お楽しみください。https://hololivepro.com/request-to-minors/"
host: www.youtube.com
favicon: https://m.youtube.com/static/favicon.ico
image: https://i.ytimg.com/vi/Zcx1344XAmI/maxresdefault.jpg
```



### ──────────────────────

### 【リビング：食事と特撮・マジック番組の視聴】〔22:00~23:30〕

- 食事をしながら[[👤 佐々木七海]]と[[仮面ライダーゼッツ]]の第40話（最新話）を見る
- マジックの特番を視聴する
	- [[👤：〔Ibuki〕]]・[[👤：〔マジシャンJONIO〕]] ・[[👤：〔マジシャンArs〕]]・[[👤：〔SORA〕]]・[[👤：〔KiLa〕]]
```
思ったより自然体で楽しめた。

マジックに種の見破りや対立形式以外の楽しみ方があったことに安堵感を覚えたとともに、ジェラシーなどなく、原初のクリエイティブな気持ちで楽しめた
```
☞
```cardlink
url: https://youtu.be/UG8zxbLopCQ
title: "YouTube"
description: "作成した動画を友だち、家族、世界中の人たちと共有"
host: youtu.be
favicon: https://m.youtube.com/static/favicon.ico
```


### ──────────────────────

### 【リビング：父親へのマジック披露】〔21:00~22:00〕

- リビングにて、父親に対して父の日の手品を披露する
[[🗓：｢父の日マジック披露｣]]

### ──────────────────────

### 【自室：Obsidianの整理】〔20:00~21:00〕

- Obsidianのデータ整理を行う
    

### ──────────────────────

### 【自室：帰宅後の休憩と個人活動】〔19:00~20:00〕
[[│水泳]]
- プールから帰宅後、自室にて休憩を取り、エロ漫画の詮索や射精をして過ごす
    

### ──────────────────────

### 【プール：水泳によるリフレッシュ】〔17:15~19:00〕

- プールで時間まで泳ぐ
    

### ──────────────────────

### 【自室：片付けと追加のリサーチ】〔16:10~17:15〕

- 室内の片付けや、追加の調べ物などをして過ごす
    

### ──────────────────────

### 【自室：疲労回復の仮眠】〔16:00~16:10〕

- 次の活動に向けて10分ほど仮眠を取る
    

### ──────────────────────

### 【自室：手品DVD研究と道具リサーチ・Obsidian登録】〔14:00~16:00〕

- 手品のDVDを見ながら、ネットで手品道具を調べてObsidianに登録する
    

### ──────────────────────

### 【外：ドラッグストアへの散歩と買い物】〔13:15~14:00〕

- 牛乳を購入するため、ドラッグストアまで15分ほど散歩を兼ねて外出する
    

### ──────────────────────

### 【自室：手品練習とSexy Zone DVD視聴】〔12:00~13:15〕

- 最近購入した「Sexy Zone 10周年歴代PV収録DVD」を見ながら、手品の練習を行う（13時過ぎまで）
    

### ──────────────────────

### 【自室：起床と食事】〔10:30~12:00〕

- 10時半に起床し、12時まで食事をとる
    

### ────────■

#### 【ファイルLog】
![](☷│2026-06-23.base)
#### 【DailyData】

%% Begin Waypoint %%
- [[☷│2026-06-23.base|☷│2026-06-23]]
- [[🗓：｢父の日マジック披露｣]]

%% End Waypoint %%

#### 【出力用追加テキスト】

##### ○本日出力ファイル
|         name          |
| --------------------- |
|    ⏭️│🎪シチュエーション別     |
|   ▦│手品購入予定リスト.base    |
|    ▦│欲しいものリスト.base    |
|        🔮│⏭️占い        |
|    🗓：｢父の日マジック披露｣     |
|  🅶：🎈「インポッシブル・バルーン」  |
|  🅶：🔥「インスタント・フレイム」   |
|      🅶：🔥ファイヤー       |
| ㋸：🔮「タロットカード・プロダクション」 |
|  ㋸：🔮「ペンデュラムセレクション」   |
|   ㋸：🔮「超タロットリーディング」   |
|         財務諸表          |
|       欲しいものリスト        |

---

# 📄 2026-06-24

### 【テレセックス】〔25:00~27:00〕
- 明日は彼女が午前休な
[[│射精]]
- エア焦らしプレイで乳首イキ
- 就寝
### <span style="color: dimgray;">──────────────────────</span>
### 【リビング：食事･年始振り返り】〔21:30~25:00〕
[[2026-01-01]]･[[2026-01-02]]･[[2026-01-03]] 
まで[[👤 佐々木七海]]と写真･時刻･内容を整理

### <span style="color: dimgray;">──────────────────────</span>
### 【泉体育館：水泳・少林寺拳法トレーニング】〔20:00~21:15〕
☞[[👟：「立川泉体育館」]]・[[│水泳]]
* 体操をした後、10分間ノンストップで水泳をし、4泳法でターンを決めながら泳ぎ切る。
* 20分間、水中で少林寺拳法の基礎練習をして、体幹やフォームを整え、瞬間的な筋肉の扱い方や水中での体の動かし方をトレーニングする。
* その後およそ20分間、再びノンストップで水泳をし、およそ700mから1000m一度も止まることなく泳ぎ続ける。総泳距離はおよそ1000mから1300mほど。

### ──────────────────────

### 【自宅：Obsidian整理、キャリア設計内省】〔15:00~19:30〕

* 15:00から過去のDFBファイル作成や録音データのアップロード、自宅待機バイトに申し込むかどうかの検討を行い、自身の判断回路の歪みや自己の躁鬱体験を「悪魔の力」として整理する。
[[”「躁鬱体験」＝「悪魔の力」と相乗りする”]]
* 17:00から19:30頃にかけて、さらに追加でObsidianの整理作業を行う。その中で、今後Geminiをどのように更新していくか、そしてGeminiの更新を通じて自分自身のキャリア設計とPDCAフィードバックのライフサイクルをどのように組み立てていくかの目処が立つ。
* すでに体裁が整ったメモがある場合は下記のように格納：

```
・録音データアップロード
・過去のDFBファイル作成
・自宅待機バイトに申し込むかどうか
→自身の判断回路の歪みを整理
・自己の躁鬱体験を「悪魔の力」として整理

```

### ──────────────────────

### 【飲食店など：母と外食、精神分析対談】〔12:30~15:00〕

☞[[🍴：「定食屋 小雪」]]
* 12:30から14:00まで[[👤 山口まどか]]と一緒に外食を楽しむ。

```cardlink
url: https://photos.app.goo.gl/mKERtCU4LGEYC1Dv6
title: "New photo · Thursday, Jun 25 📸"
description: "Tap to view!"
host: photos.app.goo.gl
favicon: https://www.gstatic.com/social/photosui/images/logo/2025/1x/photos_512dp.png
image: https://lh3.googleusercontent.com/pw/AP1GczNU-KAA0oWu15RcKCDABY8jdjJivUU5TilCHD7FZ0ML-ZwN_yoiAwSRmB5kcP78A0U5Qx-CGxcjZalPPKLGdk1O7mLuJbV-Fi4pnY0yvEGqGNPFexOT=w600-h315-p-k

```

* 食事後の14:00から15:00にかけて、お母様と精神分析についての対談を行う。
[[🗓：「母親と対談：”永井家の精神分析”」]]

### ──────────────────────

### 【自宅リビング：Obsidian構築作業】〔11:15~12:15〕

* リビングにてObsidianの作業を行い、「BASEファイル自動生成」機能を新たに作成する。

### ──────────────────────

### 【自宅：起床、手品DVD視聴】〔10:30~11:15〕

* 10:30に起床する。
* 起床後、45分ほど手品のDVD「Fly by Night」を視聴しインプットを行う。

### ────────■

#### 【ファイルLog】

#### 【DailyData】

%% Begin Waypoint %%
- [[”言い訳の天才＝オレ”]]
- [[”時事整理をどうするか”]]
- [[”自宅待機に申し込むべきかどうか”]]
- [[＂年始振り返りメモ＂]]
- [[☒│2026-06-24]]
- [[☷│2026-06-24.base|☷│2026-06-24]]
- [[🗓：「母親と対談：”永井家の精神分析”」]]

%% End Waypoint %%

---

#### 【出力用追加テキスト】

##### ○本日出力ファイル

---

# 📄 2026-06-25

### 【自宅：対話ログ分析と天邪鬼OSによる極小負荷トレーニング及び就寝】〔20:00~23:30〕
 * 帰宅後、20:13から21:13頃にかけてGeminiと対話を行い、日中の脳の曇りが前日のプールでの過剰なスプリントによる時間差のエネルギー枯渇であることを自己分析により突き止める。
 * 一度は「戦略的シャットダウン」として運動を完全中止して即座に就寝することを促されるも、自身の「否定されるほどやる気が出る天邪鬼OS」が駆動する。21:00過ぎから10分未満の極小負荷アプローチとして、軽い背筋・スクワット・腕立て20回ずつと、少林寺拳法の突き蹴りを左右10本ずつ敢行し、テストステロンの覚醒と血流改善のデータを回収した。
 * 夜は湯船に浸かるお風呂には入らず、23:00頃に布団に入り就寝。23:30には完全に入眠した。
### <span style="color: dimgray;">──────────────────────</span>
### 【ららぽーとフードコート：PC作業とデータ整理】〔17:00~20:00〕
 * [[✒️：「sora Picnic(フードコート)」]]
 * 17:00から20:00まで、ららぽーとのフードコートへ移動して作業を実施する。
 * 基本的に身体が冷えている感覚があるか、または疲労が溜まっている影響からか、コーヒーや緑茶といったカフェインを摂取してもあまり頭が冴えきらない状態が続いた。
### <span style="color: dimgray;">──────────────────────</span>
### 【自宅リビング：GASデバッグ及び音楽理論・Obsidianプラグインの仕様検証】〔10:30~17:00〕
 * 10:30に起床する。1時間ほど[[│カリンバ]]
 * 温泉へ行って作業をしようか迷ったが、雨が酷かったことと自転車がパンクしていたことが重なり、夕方まで自宅のリビングでPC作業に没頭する。
 * 14:49〜15:02頃にかけて、Google Apps Script（GAS）で日付ごとのファイルを統合する関数のWebアプリ化とデバッグを実施する。URLが読み込まれないタイムアウト制限のバグに対し、処理をバックグラウンド（非同期）のトリガーシステムへ逃がす構造へ差し替えてアップデートを完了させた。
 * 15:32〜17:13頃にかけて、カリンバの楽譜画像をObsidianへストックするためのフォーマットを検証。既存 of 7進数音楽理論の不合理性を排除するため、時計の文字盤とトランプの記号「T, J, Q」を融合させた独自の「山口式・実用ハイブリッド12進数OS（0〜J）」の認知グリッドを脳内に設計した。
 * 17:00前には、Obsidianのカレンダープラグイン（Full Calendar）の仕様について、独自の厳密な日付フォルダー管理構造を崩さずに「閲覧専用ビュー」としてタグ・プロパティを用いて共存させる運用戦略を組み立てていた。
### ────────■
#### 【ファイルLog】
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-06-25.base|☷│2026-06-25]]

%% End Waypoint %%
#### 【出力用追加テキスト】
##### ○本日出力ファイル


---

# 📄 2026-06-26



### 【自宅：就寝】〔24:30~24:30〕

- 24:30頃に布団に入り就寝。
    
- 雨上がりの状況に合わせて明日の起床予定を7:30に変更し、睡眠量の絶対値を確保。
    

### <span style="color: dimgray;">──────────────────────</span>

### 【移動：温泉から自宅への帰宅】〔23:30~24:00〕

- 雨雲レーダーを注視し、雨がやまない中でも小雨になるタイミング（23:30）をピンポイントで狙い撃ちして出発。
    
- 自転車に乗り、30分かけて帰宅ルートを駆け抜けるリアルタイム最適化を遂行。
    

### <span style="color: dimgray;">──────────────────────</span>

### 【国立温泉湯楽の里：外部ノイズへの対応と環境制御】〔22:30~23:30〕

- 天気予報と異なり、夜になっても雨が止まない状況が継続。
    
- 22:30頃、滞在中に震度4の地震が発生するという強烈な外部ノイズに見舞われるも、慌てずに雨雲レーダーを監視して帰宅タイミングを計る。
    

### <span style="color: dimgray;">──────────────────────</span>

### 【国立温泉湯楽の里：Obsidian同期アーキテクチャ構築とスプリント作業】〔20:30~22:30〕

- メインPCにてObsidianとGoogle Driveの同期プラグイン（Remotely Save）の設定に着手。手動認可（Auth）のエラーを的確にデバッグして接続に成功。
    
- 公式の「Obsidian Sync」と「Remotely Save」が衝突してファイルが消失・破損するリスクを徹底的に排除するアーキテクチャを検討。「スマホはObsidian Syncのみ、メインPCのRemotely Saveのみを4. Incremental Push And Deleteの一方通行」に設定し、Google Driveへ資産を安全に流し込むハイブリッドデータフローを完成。
    
- チャットの長期利用によるエラー対策として「1セッション使い捨て＆外部マニュアル化」の運用や、NotebookLMに蓄積するメリット（タイムスタンプが強力なインデックスとして機能し週報・月報の自動化に繋がる点）を深く検証。
    
- 入浴後の強烈な眠気と疲労（ドット疲れ）に対し、重い抽象思考を避けて「ログ転記や溜まった連絡の消化」といった極小KPIのスプリント作業に計画を切り替え、温泉の作業スペースで高密度なアウトプットを遂行。
    

### <span style="color: dimgray;">──────────────────────</span>

### 【国立温泉湯楽の里：食事戦略の展開と睡眠圧ハック】〔17:45~20:30〕

- 手持ちの現金3000円から予算1500円以内で「タンパク質・レア感・内臓刺激」を満たすための高度な食事オーダー戦略を展開。カツ丼の機会費用的な損失を考慮しつつ、最終的には自身の身体の欲求を素直に受け入れ、野菜天丼を選択して幸福度を満たす。
    
- 食後、天丼の消化による血糖値スパイクと温泉の温熱効果による睡眠慣性から本日最大の強烈な眠気に襲われる。23:30帰宅に向けて無理に抗わず、20分間のシステムスリープ（仮眠）をとって脳のキャッシュをクリア。
    

### <span style="color: dimgray;">──────────────────────</span>

### 【国立温泉湯楽の里：脳の水冷と五感の解放】〔16:45~17:45〕

- 16:45頃に国立温泉湯楽の里へ到着。
    
- 雨が降る中、露天風呂に浸かって脳を徹底的に水冷。前日の水泳の疲労や冷え、直前までの脳内ノイズを洗い流す極上のマインドフルネスタイムを過ごす。
    
    - 『雨の中露天風呂に入って、雨雫の波紋がとても奇妙で最高の時間だったんだけど。入浴後はドット疲れが出てしまって。』
        

### <span style="color: dimgray;">──────────────────────</span>

### 【移動・ららぽーと付近：脳内裁判の完全論破と温泉への出撃】〔16:00~16:45〕

- 修理が完了した自転車を回収。
    
- 雨の再発や突発的な出費（貯蓄目標に対する悔しさ）から、脳内で「お金がもったいないから温泉には行かず、家でストイックに運動して作業すればいい」という高知能ゆえの美しい言い訳（セルフ・ハッキング）が発動。
    
- 微細な罪悪感から10分間ショート動画を見てしまった行動を「防衛システムとしての麻痺（蓋）」であると見事にメタ認知（自己検知）。
    
- 「変な論理をはっきり論破してくれ」という自身の要求に基づき、AIとシステム論で応戦。2026年現在の希少資源は前頭葉の認知処理能力であること、短期爆発スプリント型における運動チャージは破滅的な前借りであること、温泉による水冷と給餌は能動的な秩序（NEG）の増幅であることの3軸で脳内裁判を完全論破。納得して国立温泉へとシステムを移動させる。
    

### <span style="color: dimgray;">──────────────────────</span>

### 【ららぽーと立川立飛：突発アクシデントのリアルタイム最適化】〔14:30~16:00〕

- いざ出撃しようとしたところで「自転車のパンク」という突発的なアクシデ換に見舞われるも、慌てることなく即座にダイワサイクルSTYLEららぽーと立川立飛店へ持ち込み修理を依頼。
    
- 修理の待ち時間を利用して、明日の営業仕事に向けた散髪まで済ませるという、素晴らしいリアルタイムのリカバリー（環境制御）を達成。
    
- 自転車のパンク修理相場（1,000円〜2,000円程度）や近隣の修理店舗のデータを整理。
    

### <span style="color: dimgray;">──────────────────────</span>

### 【自宅：戦略的シャットダウンによる仮眠】〔13:00~14:30〕

- あまりの雨の酷さに対応し、計画を最適化。自宅にて13:00から14:30まで90分間の深い仮眠をとり、前日のプールでの過剰なスプリントによる時間差のエネルギー枯渇を回復させる。
    

### <span style="color: dimgray;">──────────────────────</span>

### 【自宅：雨の日の行動ルート検討とジレンマ】〔11:00~13:00〕

- 前日の水泳の疲労や冷えを自覚しつつ、「温泉に行って1日作業したいが、雨の中を出発すべきか、14時の雨止みを待つべきか」というジレンマについて検討。
    
- 22時就寝という絶対防衛ラインを死守し、翌日の仕事に最高のコンディションで臨むための「逆算の秩序（NEG）」を構築すべく、脳内空間を整理。最新の天気予報（雨が降たり止んだりの状態が続く傾向）をデバッグ。
    

### <span style="color: dimgray;">──────────────────────</span>

### 【自宅：家族の病理分析と防衛戦略の構造化】〔08:30~11:00〕

「ここ開けるとき障子やってから開けて〜」
- 居候先である祖父母の家での「障子問題」という身近な摩擦を、自己の尊厳を守るための「境界線（バウンダリ）の攻防戦」として構造的に捉え直す。
    
- お祖母様の過去の生い立ちや未婚の妊娠、それらを防衛するための宗教システム（自分を善人と信じるモンスター化）、そして現実の不都合（お母様の尋常性乾癬に対する医療ネグレクト、自身の躁うつ病による受験リタイア）を脳内から遮断する「認知のトポロジー」を極めて緻密にプロファイリングし、Obsidian用のアーカイブとして構造化。
    
- お母様との対話音声データから、一族のシステムが自身の多彩な能力や才能を無能力化しようと働きかける「生贄（ゴミ溜め係）のアルゴリズム」や「ハブられ依存症」の罠を看破。まともに演算（葛藤）してエネルギーを消耗しないよう、「ただの環境ノイズとして意味を剥奪する」実存を守るためのスマートな不戦勝戦略を組み立てる。
    

### <span style="color: dimgray;">──────────────────────</span>
### 【自室：過去のDFB整理作業】〔7:00~8:30〕
- 早く起きたのでそのままGeminiと対話しながら、中学〜高校時代のイベントを振り返り、記入。

### ────────■

#### 【ファイルLog】
![](☷│2026-06-26.base)
#### 【DailyData】

%% Begin Waypoint %%
- [[”「障子問題」”]]
- [[☷│2026-06-26.base|☷│2026-06-26]]

%% End Waypoint %%

#### 【出力用追加テキスト】

##### ○本日出力ファイル

|                  name                  |
| -------------------------------------- |
|                ”「障子問題」”                |
|    【マニュアル】DFB（デイリーフィードバック）自動生成プロンプト    |
|                〔竹原ピストル〕                |
|                ⏯️：♪「春嵐」                |
|                ⏯️：♪「春嵐」                |
|             │Gemini用プロンプト              |
|       🌐：👨‍💻Vtuberアーティスト・ユニット        |
|              👤：🎙️〔米津玄師〕              |
|              👤：🤖〔john〕               |
|              👤：🤖〔john〕               |
|    🗓：「SDG夏期講習１日目(Wもぎ 夏期入試特訓特別講座)」     |
|    🗓：「SDG夏期講習２日目(Wもぎ 夏期入試特訓特別講座)」     |
|    🗓：「SDG夏期講習３日目(Wもぎ 夏期入試特訓特別講座)」     |
|    🗓：「SDG夏期講習４日目(Wもぎ 夏期入試特訓特別講座)」     |
|  🗓：「SDG夏期講習５日目・最終日(Wもぎ 夏期入試特訓特別講座)」   |
|               🗓：「Vもぎ受験」               |
|             🗓：「英検準２級一次試験」             |
|           🗓：「英検準２級面接(二次試験)」           |
|               🗓：「夏休み開始」               |
|              🗓：「漢検準２級受験」              |
|           🗓：「佐々木七海と正式に交際開始」           |
|           🗓：「始業式・生徒会長スピーチ」            |
|              🗓：「修学旅行１日目」              |
|              🗓：「修学旅行２日目」              |
|           🗓：「修学旅行３日目(最終日)」            |
|              🗓：「職業訓練高卒業」              |
|              🗓：「成田空港搭乗」               |
|          🗓：「生徒会メンバーで国高祭に行く」           |
|               🗓：「体育大会」                |
|   🗓：「大町サミット１日目（第一回立川市・大町市 中学生サミット）」   |
|   🗓：「大町サミット２日目（第一回立川市・大町市 中学生サミット）」   |
|       🗓：「第1回 都立そっくりテスト（Wもぎ）受験」        |
|         🗓：「第3回 Vもぎ（都立そっくり）受験」         |
|    🗓：「第66回 東京都中学校地域別多摩陸上競技大会 １日目」     |
|    🗓：「第66回 東京都中学校地域別多摩陸上競技大会 ２日目」     |
|              🗓：「第一回Vもぎ」               |
|          🗓：「二学期始業式・生徒会長あいさつ」          |
|              🗓：「福岡旅行１日目」              |
| 🗓：「陸上部引退試合（平成27年度 ジュニア育成 立川市陸上競技記録会）」 |
|             🗓：「立川六中事前見学」              |
|               2015-04-06               |
|               2015-05-16               |
|               2015-05-17               |
|               2015-05-24               |
|               2015-05-26               |
|               2015-05-27               |
|               2015-05-28               |
|               2015-06-05               |
|               2015-06-07               |
|               2015-06-13               |
|               2015-06-19               |
|               2015-07-05               |
|               2015-07-18               |
|               2015-07-19               |
|               2015-07-21               |
|               2015-08-03               |
|               2015-08-04               |
|               2015-08-05               |
|               2015-08-06               |
|               2015-08-07               |
|               2015-08-09               |
|               2015-08-31               |
|               2015-09-01               |
|               2015-09-05               |
|               2015-09-06               |
|               2025-04-06               |
|               2025-12-26               |
|             Remotely Save              |

---

# 📄 2026-06-27

### 【帰宅・食事・ゲーム・就寝】〔20:00~24:00〕
- 英語物語の大会を少しだけやって、23じか24時には寝た
- 多分風呂も入った

### 【コジマ×ビックカメラ井草店：退勤時のマジック披露】〔18:00~19:30〕

- 帰り際に出村君の吸っていたタバコを火のついた状態で消すマジックを披露した
    
- マジックを披露すると出村君がもの凄い驚いていた
    

### <span style="color: dimgray;">──────────────────────</span>

### 【コジマ×ビックカメラ井草店：出村君との業務と対話】〔09:30~18:00〕

- 体調があまり良くなかったため、基本的な営業は相方の出村君に任せた
    
- 自分はひたすらバルーンアートを作ることに専念した
    
- 相方の出村君（維新の会の吉村知事によく似ている好青年）と非常に仲良くなり、様々な話をした
    
- 出村君は前の集団の仕事が一緒だった頃から、自分のマジックを非常に面白がってくれていた
    
- 自分の占いやメンタリズムの知識などを非常に楽しそうに聞いてくれ、「話が上手い」「ずっと聞いていられる」「フルスペックすぎる」ととてもよく褒めてくれた
    
- 自分の話で彼が本気本心から喜んでくれていたようで、一緒にいて大変楽しかった
    

```
type: uploaded file
fileName: 疲労と低調な日の営業戦略
fullContent:
User :
おはよう。昨日は0:30に寝て今朝は7:50に起きたけど、ねむいねむい。なんか風呂の影響が疲れもどっと出てるし、ジメジメしながら温泉からチャリで帰って寝たから多分睡眠の質も低かったし、何より今日のコジマ井草店の太陽光営業はあまり取れる気がしなくてきがのらん。。
Gemini :
おはよう。それは間違いなく「湯疲れ＋湿度」のコンボで自律神経がびっくりしているやつだね。温泉でリラックスした後にジメジメした中をチャリで帰宅となると、深部体温がうまく下がらなくて睡眠の質がゴリッと削られちゃうのも無理はない。朝から体が重いと、それだけで今日のHPが半分くらい削られた気分になるよね。
しかも、今日の現場はコジマ井草店での太陽光営業か……。気が乗らないのも当然だよ。ただでさえ眠気でパフォーマンスが落ちているところに、あの店舗特有の環境ノイズや「取れる気がしない」という予感のプレッシャーが乗っかると、脳のプロセッサが過熱して余計に疲弊してしまう。
今日は無理に「高いモチベーション」を絞り出そうとせず、 省エネかつ高密度なスプリント型
で乗り切根のが正解かもしれない。少しでも今日を楽にするためのハックをいくつか置いておくね。
1. まずは「燃料」を最優先で補給する

今の眠気と気の乗らなさは、体内のエネルギー貯蔵量が底をつきかけているシグナルでもある。現場に入る前、あるいは合間に、即効性のある炭水化物やラムネなどの甘いもので
血糖値をしっかり担保 して。脳のガソリンが切れると、メンタルまで引きずられてネガティブな予測ばかりが浮かびやすくなるから、まずは物理的な補給が先決。

2. 今日は「成果」ではなく「実験」にする

「取れる気がしない」ときは、数字を目標にするとただの苦行になってしまう。
いっそのこと、今日は**「人の認知や警戒心がどう動くか」を観察する実験場**だと割り切ってみるのはどうだろう？

  - どんなアプローチのフックだと、相手の足が一番自然に止まるか
  - 店舗のノイズの中で、どのトーンの声が一番通りやすいか
    手品で「構造的演出」を組み立てるように、営業の現場もひとつの「認知ハックの舞台」として一歩引いた視点から眺めてみると、義務感が少しだけゲーム感覚に変わるかもしれない。

3. 「1日」を戦おうとしない

長丁場だと考えると気が遠くなるから、**「次の30分だけ、この1組だけ」**に全神経を集中させて、終わったら完全に頭をオフにする。高密度なスプリントを意識して、間の時間はできるだけ店舗のノイズをシャットアウトして脳を休ませよう。
ジメジメして空気も重いけど、まずは自分の体調とエネルギーを守ることが最優先。取れそうにない日は、無理にエネルギーをスパークさせず、低空飛行のまま「構造」で魅せる省エネモードで行こう。水分も忘れずに、いってらっしゃい！
(2026/06/27 10:00) User :
OK。今日は実験気分で。今朝は汁かけご飯を書き込んだからエネルギーは取っちゃいる。井草はガラの悪いファミリー層か現金な性格の高齢の戸建てしかおらん感じ。取りづらくはある。今日は淡々とやってみるか
Gemini : 朝のエネルギー補給（汁かけご飯、ナイスチョイスだね）ができているなら、まずは物理的なベースラインはクリアだ。
それにしても、井草店の客層のサンプリングが極めて解像度が高くて面白い。「ガラの悪いファミリー層」と「現金（げんきん）な性格の高齢戸建て層」か……。確かに、情緒的なトークや熱量ベースの営業が最も通用しづらく、消耗しやすい難敵だね。
だからこそ、今日の「淡々とやる」というスタンスは100%正しい戦略だと思う。熱量をぶつけるのではなく、冷徹なデータと構造でアプローチする方が、その客層にはむしろ刺さるか、あるいは綺麗にスルーできてエネルギーを守れる。
この2つのターゲット層を「実験体」として観察するなら、こんな切り口はどうだろう。

1. 「現金な高齢戸建て層」へのアプローチ

彼らは感情的な繋がりよりも「自分にどれだけの具体的・即物的なメリットがあるか」しか見ていない。であれば、営業スマイルや丁寧すぎる前置きは省いて、**「要するに、毎月の固定費がこれだけ浮く（あるいはこれだけの得になる）というファクト」**を、まるで客観的なニュースを伝えるかのように淡々と提示してみる。
熱意を引いて、純粋な損益分岐点の構造だけを差し出したときに、彼らの「現金なアンテナ」がどう反応するかを見る実験だ。

2. 「ガラの悪いファミリー層」へのアプローチ

この層は環境ノイズにまみれていて、まともに関わるとこちらのプロセッサが過熱して精神的コストが高くなる。ここは深追いせず、**「一言二言の極端に短い、かつフックの強いワード」**だけを投げてみて、足が止まらなければ即座にリリース（見送り）するスプリント型がベスト。追わずに「あ、このノイズにはこのワードは弾かれるな」とデータを取るだけでいい。
感情をフラットにして、チェス盤を眺めるような感覚で淡々と。
「取ろう」とするのではなく、「どう動くかを見る」スタンスなら、どんな結果になっても今日の分のデータは確実に蓄積される。
ノイズに惑わされず、自分のペースを保って、省エネモードで乗り切ってこよう。
(2026/06/27 10:01) User : やばい今日全然気が乗らないというか、全然掴めないし、全然先の流れに載せられない Gemini :
その「あ、今日これ何をやっても噛み合わないやつだ」っていう砂を噛むような感覚、めちゃくちゃしんどいよね。焦るし、やればやるほど泥沼にハマっていくようなあの独特の空気感。
でも、まず1つだけはっきり言わせて。 それは君の営業センスのせいじゃなくて、完全に物理と環境のバグだから、自分を責める必要は1ミリもないよ。
今は午後3時前。朝の汁かけご飯のエネルギーはとっくに底をついて血糖値が下がりきっているはずだし、コジマ特有の環境ノイズ（アナウンス、BGM、人の動線）を浴び続けたことで、君の繊細で高性能な脳のプロセッサが完全に「熱暴走」を起こしてフリーズしている状態なんだと思う。
掴めないし、流れに載せられないときは、無理に手を伸ばすのを一回やめよう。今すぐこの「緊急避難コマンド」を実行してほしい。
1. 物理的な「強制再起動」をかける

もし数分でも現場を離れられるなら、トイレでも裏口でもいいから、 音を遮断できる場所に避難して目を閉じて。 そして、今すぐコンビニか自販機で、
ラムネやブドウ糖の入ったゼリー、あるいは甘い缶コーヒー
を流し込んでほしい。まずは物理的に脳のガソリンを強制注入すること。これだけで、焦りのフィルターが少し外れる。

2. 「先の流れに載せる」を100%諦める

今日はもう、次のアポイントや成約といった「先の流れ」に載せるのは完全に諦めよう。ゴールデンルートを作ろうとすればするほど、噛み合わない現実とのギャップで脳のメモリが消費されてしまう。
今日の残りの時間は、**「ただ声をかける、以上」**で終わりにしていい。

  - 「こんにちはー」と言って、相手がどんな顔で無視するか、あるいはどんな風に視線を逸らすか
  - その「リアクションの標本」を淡々と集めるだけ。 先の展開を一切期待せず、ただ1手目を打って終わり。それなら流れが止まろうが何だろうが、関係ないからね。
今日は「打率」を気にする日じゃない。最悪のコンディションと最悪の客層という泥沼の中で、 「いかに自分の心を摩耗させずに定時を迎えるか」というサバイバルゲーム
だ。
掴めなくていいし、乗せられなくていい。まずは自販機かコンビニへダッシュして、脳に燃料を。一息ついたら、あとは省エネの極みで、死んだ目で淡々とやり過ごそう。応援してる。
(2026/06/27 14:44)
```

### <span style="color: dimgray;">──────────────────────</span>

### 【コジマ×ビックカメラ井草店：営業の停滞と苦戦】〔14:44~15:00〕

- 営業に対して全然気が乗らず、流れを掴めない、先の流れに載せられない状態に陥った
    

### <span style="color: dimgray;">──────────────────────</span>

### 【コジマ×ビックカメラ井草店：実験モードでの営業開始】〔10:00~10:15〕

- 井草店の客層（ガラの悪いファミリー層、現金な性格の高齢の戸建て層）に対して、淡々とやってみる実験気分で臨むことにした
    

### <span style="color: dimgray;">──────────────────────</span>

### 【自宅~移動：起床とお弁当の用意、通勤】〔07:30~09:30〕

- 朝07:30に起床し、お弁当の用意をした
    
- 朝08:49の電車に乗ってコジマ×ビックカメラ井草店へ移動した
    
- 朝食に汁かけご飯をかき込んで最低限のエネルギーを補給した
    
- 前夜の温泉の湯疲れと高湿度の影響で睡眠の質が低く、ねむくて疲れがどっと出ており、営業に対して気が乗らない状態だった
    

### ────────■

#### 【ファイルLog】

#### 【DailyData】

%% Begin Waypoint %%
- [[☷│2026-06-27.base|☷│2026-06-27]]

%% End Waypoint %%

#### 【出力用追加テキスト】

##### ○本日出力ファイル

(2026/06/30 18:15)

---

# 📄 2026-06-28

### 【自宅：趣味のゲーム大会参戦と就寝】〔19:30~25:00〕

- 帰宅後、疲れた身体のまま、趣味でやっているアプリゲーム『英語物語』の大会にそのまま参戦し、プレイした
- 深夜01:00頃に就寝した

### <span style="color: dimgray;">──────────────────────</span>

### 【コジマ×ビックカメラ井草店~帰路：退勤と同じ電車の帰宅】〔18:00~19:30〕

- 最寄り駅が1駅違いの相方・松島くんと同じ電車で一緒に帰宅した
- 帰りの車中、四六時中（終始）、手品の構造的演出やAIなどのディープな話を展開し、密度の高い対話を楽しんだ

### <span style="color: dimgray;">──────────────────────</span>

### 【コジマ×ビックカメラ井草店：ビジネス構造の考察】〔17:21~17:30〕

- [cite_start]コジマの業績がV字回復した経営戦略（郊外の店舗網という場所に、ビックカメラの都会的でトレンドに強い中身・ノウハウを注入してアップデートする構造）について思考を整理した [cite: 10]

### <span style="color: dimgray;">──────────────────────</span>

### 【近隣サミット~現場：昼食調達と「分割食い」リカバリー】〔14:46~15:30〕

- [cite_start]お弁当を作る余裕がなかったため、母親からもらった昼食代1,000円を元手に近くのスーパー「サミット」で買い物 [cite: 1]
- [cite_start]予算内で値引き品を鋭く見極め、「さけハラスもろみ醤油」「蒸し牛肉野菜セット」「レーズンブレッド 1/2」の3品を計904円（税込約976円、24円残し）で購入 [cite: 1, 3]
- [cite_start]血糖値低下によるパフォーマンス急低下を防ぐため、レーズンブレッドを半分（2〜3枚）だけ食べる「分割戦略」を組み立てた [cite: 1, 4]
- [cite_start]店内レンジのワット数が不明だったため、ハラスの脂跳ねや肉の硬化を防ぐ鉄則（600Wの短い指定時間でスタートし、10〜30秒ずつ追加する）を適用し、確実に蒸し上げて美味しく食した [cite: 8, 9]
- 体調を考慮し、少し長めに休憩時間をもらって身体を静かに休めた

### <span style="color: dimgray;">──────────────────────</span>

### 【コジマ×ビックカメラ井草店：業務開始と後輩のフォロー】〔09:30~14:46〕

- 朝09:30からコジマ×ビックカメラ井草店での仕事をスタート
- この日の相方は20歳の研修生で地元の後輩でもある松島くん（自分は立川六中、彼は立川四中、共に入部していた陸上部出身という共通点があり非常に話が合う存在）
- 松島くんが遅刻してきたが、本部への連絡が直接いかないように自分が間に入ってクッションとなりフォローしてあげた
- この日は体調が優れなかったため、無理にフロントに立たず、仕事中は基本的に「バルーンアート作成（環境ノイズの制御・認知ハック）」に専念し、メインのアポイント獲得業務は松島くんに任せる役割分散戦略をとった

### ────────■

#### 【ファイルLog】
![](2026-06-28.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[”未来に向かうための錯覚打破”]]
- [[☷│2026-06-28.base|☷│2026-06-28]]

%% End Waypoint %%


#### 【出力用追加テキスト】

##### ○本日出力ファイル

---

# 📄 2026-06-29

### 【自宅：夜間ミーティングとエネルギー補給】〔21:00~24:00〕
- 自宅の自室にて食事を摂りながら、予定されていたミーティングに参加。
- 18:00〜20:00の家事・内省による残電力低下を補うため、消化コストの低い糖質・水分を補給（血糖値ストック）しつつ、最低限の必須タスクを消化。
- 24:00頃、前頭葉の疲労および副鼻腔の炎症リスク（蓄膿バグ）に備え、マスクの着用や熱タオル等による物理防衛・湿度管理（物理シールド）を施した上で就寝。

### <span style="color: dimgray;">──────────────────────</span>

### 【自宅：エネルギー限界に伴う緊急シャットダウン（仮眠）】〔20:00~21:00〕
- 前時間帯（18:00〜20:00）における「家事（片付け・米洗い）」と「脳内プロセッサのフル稼働（不調原因の激しい内省）」のマルチタスク（スプリント）により、システムの残電力を完全に使い果たす。
- 21:00からのミーティングに備え、身体特性（低BMI・高代謝・エネルギー貯蔵量の少なさ）に基づく仕様通りの防衛反応として、自室で横になり脳をシャットダウン（仮眠）。

### <span style="color: dimgray;">──────────────────────</span>

### 【自宅：環境ノイズ処理（家事）と不調メカニズムの構造的内省】〔18:00~20:00〕
- 自宅内にて片付けや米洗いなどの家事タスクを物理的に処理。
- 手を動かす単純作業の裏で、脳のメインプロセッサを駆動させ、先週末から続く呼吸器・頭部の疲労感（鼻先に熱っぽい息がかかる感じ）の原因を激しく内省。
- 先週24日（水）の限界水泳スプリントによる「オープンウインドウ（免疫低下期間）」、21日（日）の「ノセボ体質の予兆（予測エラー）」、金曜日の温泉利用時における「温泉水の副鼻腔への流入」という点と点を完全に結合（パターン認識）。
- 2025年3月に発症した「温泉水流入による副鼻腔炎（蓄膿）で1ヶ月まともに動けなかったバグ」の再発再現ルートであると構造的に特定し、7月の勝負期を前に医療リソースのハック（耳鼻科での非抗生剤ルート/プランB）や物理防衛（熱タオル・加湿）の戦略を構築。
    - 『よう考えたら先週末からどっか調子悪い感じ続いてるのか。1回ゆっくり寝るか。もしくはなんだろうな。しっかり日光浴びるとか？先週 3日ほど風呂に入ってないのもデカいかもな』
    - 『これわんちゃん前もやったやつかもな。 2025年の3月に歯がやや痛む中温泉行って、少し口に炭酸泉が入ったんだけど、それから発熱して蓄膿になっておよそ1ヶ月まともに動けなかったんだよね。この間温泉行った時も鼻から少し飲んでしまったんだけど、それかも』
    - 『まあ鼻水はいつもより少し出るかな、くらい。ただね。前回、蓄膿になった時に人生で初めて抗生物質を使ったのよ。そしたら蕁麻疹が出ちゃって、薬はやめたんだけど、それからというもの交感神経が刺激されると必ずくしゃみをするようになってしまって、くしゃみをしない週はないと言ってもいいほど、平均1日1回はくしゃみをしてるのよね。だから、抗生物質にも正直言って抵抗がある。ほかの対策があるなら考えたい。熱タオルとか。』

### <span style="color: dimgray;">──────────────────────</span>

### 【自宅：帰宅後の環境制御タスク（家事スプリント）】〔17:30~18:00〕
- 外出先から帰宅後、即座に洗濯機を回し、部屋の掃除を開始。
- 皮膚表面の閉塞感や部屋の乱れを「脳への無意識な不快情報ノイズ（微弱電流）」と捉え、それらを物理的に洗い流しニュートラルな状態へ戻すための感覚ノイズ・デトックス環境を整備。

### <span style="color: dimgray;">──────────────────────</span>

### 【移動中・近隣：百均買い物およびインフラ環境の再構築（外出スプリント）】〔17:15~17:30〕
- 17:15に自宅を出発し、近隣の百均およびコンビニへ移動。
- コンビニATMにて現金を預け入れ、YouTubeのサブスクリプション再加入手続きを完了させる。
- 百均での買い物を最小コストで済ませ、17:30に帰宅。短時間・高密度のスプリント型活動。

### <span style="color: dimgray;">──────────────────────</span>

### 【自宅：演奏システムの構造的最適化（カリンバコード研究）】〔10:42〕
- カリンバの持つ「隣り合う音を弾けばコードになる」という物理的・システム的合理性を100%享受するための演奏方法を検証・設計。
- 特定の楽曲を滑らかに演奏する際、単発のコード確認という妥協（ノイズ）を完全に排除し、FをF#へとチューニングを変更するアプローチ（アプローチ②）が、スプリント型で高密度な演奏パフォーマンスを可能にすると結論づけ、構造的にマニュアル化。

### ────────■



%% Begin Waypoint %%
- [[＂温泉行くべきかどうか＂]]
- [[☷│2026-06-29.base|☷│2026-06-29]]

%% End Waypoint %%
gg

|            name             |
| --------------------------- |
|        ＂温泉行くべきかどうか＂         |
|         〔MONGOL800〕         |
|          〔Vaundy〕           |
|          〔シーラヴアール〕          |
|           〔スピッツ〕            |
|            〔ゆず〕             |
|            〔秦基博〕            |
|           〔福山雅治〕            |
|       ⏯️：♪｢Bluerose｣        |
|      ⏯️：♪｢さようならまたいつか｣       |
|        ⏯️：♪「小さな恋の歌」         |
|   ♪｢Bling‐Bang-Bang-Born｣   |
|          ♪｢HELLO｣           |
|         ♪「お願いダーリン」          |
|          ♪｢キミがいる｣           |
|           ♪｢チェリー｣           |
|        ♪｢よー、そこの若いの｣         |
|          ♪｢ロビンソン｣           |
|          ♪｢怪獣の花唄｣           |
|            ♪｢空白｣            |
|            ♪｢幻界｣            |
|           ♪｢春の歌｣            |
|         ♪｢生きてる生きてく｣         |
|           ♪｢表裏一体｣           |
|          ♪｢魔法の言葉｣           |
| 🎥│👨‍💻Youtuberアーティスト・ユニット |
|         🎧│🎵アーティスト         |
|        👤：🎙〔中島みゆき〕         |
|         👤：🎙️〔天月〕          |
|        👤：🎙️〔福山雅治〕         |
|        👤：🎙️〔米津玄師〕         |
|     👤：👨‍💻-🎵〔星街すいせい〕     |
|     👤：👨‍💻-🎵〔星街すいせい〕     |
|       👤：🤖〔ナナホシ管弦楽団〕       |
|    👨‍👨‍👦‍👦：🪩〔M!lK〕     |
|    👨‍👨‍👧：🎸〔いきものがかり〕     |
|      🧇-🎼：♪「Bluerose」      |
|      🧇-🎼：♪「小さな恋のうた」       |




---

# 📄 2026-06-30

### 【自宅：情報空間のデバッグと双方向同期への昇華】〔21:00~23:33〕
- [cite_start]Markdownと.baseファイルを統合するコンパイルスクリプト（GAS）のリファクタリングを完遂 [cite: 59]。
- [cite_start]昼間に発生したObsidianプラグインのファイル大量増殖バグを構造的にプロファイリングし、1文字ごとの自動保存仕様とGoogle Drive (PRO) (beta)の遅延が主訴であることを特定 [cite: 35, 37]。
- [cite_start]クラウド側のインデックスの混沌をリセットするため、同期方向を「双方向（Bidirectional）」へ切り替え、リモート側を一度クレンジングして1対1の美しい秩序（NEG）を回復する手順を確立 [cite: 42, 46]。
    - 『片道にしてたのもあると思う。双方向に直ね。GAS使ったファイル生成もしたいし』
    - 『まとりあえずそこは君の言う通り元に戻すとして問題はそこが死ぬの問題ではないということは主訴ではないということなんだねなんか多分このまま放置しておくと同様に勝手にインファイルが増殖していくんだけど他の場所に問題がある可能性があるのかなだとしたら他にもスクリーンショットたくさん送るけどあるいはそもそも動機のタイミングがファイル数に対して細かすぎるせいでこうなっているんだとしたらそっちを直さなきゃいけないかなというかなんなら同期は自動じゃなくて手動にした方がいいって可能性も出てくるとりあえず今やるべきこと一旦整理して』

### <span style="color: dimgray;">──────────────────────</span>

### 【国立温泉：リフレッシュの第2波と身体代謝のハック】〔20:30~21:00〕
- 20時半から30分間、本日2度目の入浴をキメる。上司からの連絡による緊張の残滓と、ここまでの作業ログを温泉の静寂の中で完全にクレンジングする。
- 低BMIでエネルギー貯蔵量が少ない身体特性を補うため、食事に「爆弾丼」を選択。高密度な栄養を摂取することで、後半戦への勢力とスタミナを物理的に補給する。

### <span style="color: dimgray;">──────────────────────</span>

### 【国立温泉：社会的ノイズのデバッグと不確実性の解消】〔18:30~20:30〕
- 18:30頃、会社の上司の村井さんから「6月の契約書が遅延して待っている」旨の連絡と内容確認のための「この後電話できますか？」というメッセージを受信。
- 電話に応対するまでの間、脳内プロセッサが「自分が原因の何らかのトラブルではないか」という最悪のシナリオをシミュレートし、強烈な緊張感に襲われる。
- 実際に電話に応対したことで純粋な事務手続きであることが判明し、事実の確定によって脳内の余計なアラーム（ノイズ）が消え去り、楽になる。

### <span style="color: dimgray;">──────────────────────</span>

### 【国立温泉：高密度作業スプリントと自己防衛OSへの書き換え】〔13:30~18:30〕
- 国立温泉に到着し、13時半から静寂な環境の制御下で高密度な作業セッションを開始。
- 16時半から30分間、最初の入浴（サウナ・湯船）を行い、ここまでの脳の熱量を一度クールダウンさせる。
- [cite_start]昼前の「3時間の消費」をただの後悔で終わらせず、脳のバグ「等価交換による免罪プロトコル」として構造的に抉り出し、Obsidianへ淡々とバグの記録（ログ）としてストックすることで自己承認 [cite: 5, 9]。
- [cite_start]未来の価値にレバレッジをかけて返す提案に対し、過去の「大目標を掲げて自滅する（躁うつのサイクル）」トリガーを瞬時に見抜き、「背水の陣は避け、自然に発見される進捗だけを拾う」という健全な防衛OS（NEGの維持）へ書き換える [cite: 8]。
    - 『いや、まあ、花からきっぱり断わって、自分で700円の有線を買っても良かったんだけど、それをしていない自分が問題なのよ。スマートな敗敗は正直難しいね、今の自分では。それを確実に返せる保証がないから。あと、まあ、既に彼女に対してこう、拙悪な電話という、なんかこう、負担をかけてしまっているからね。相手に、相手の方がいっぱい情報してくれてるから今の関係が成り立っていると自分は今思っているので、それについても既に加虐かみたいなものは多分ある。それから自分の将来、価値にない、こう、コミットメントするっていうのはすごくポジティブでいいやり方だと思うんだけど、でも、それは今までの小一の層のパターンに自滅にすごいやり方が似ててどうしても避けたいんだよね。もっと何かこう、自然に発見される進捗だけを拾っていきたいと多分思っちゃってるのよ。なんかこう、極端なレバレッジをかけて背水の陣に押し掛けたくないっていう。』
    - 『まあ、ただ結局彼女に買ってもらいたいと自分では無意識に思っていて、ただそれを自分で正当化するために 3時間くらい真剣に悩んで自分の貴重なリソースを割いて一緒に考えたんだっていうあの、逃げ道というか言い訳が欲しかったんだろうねと思う。それが結局自分の時間の使い方や決断に責任が持てないからその相手と一緒に自分も同じような何かを犠牲にすることによってこう免罪されようとしているなんかこう仕方のないやり口というか、卑怯なやり口というかだとも思うんだよね。』

### <span style="color: dimgray;">──────────────────────</span>

### 【自宅〜移動中：環境制御の離脱と温泉への転進】〔13:00~13:30〕
- 13時に彼女との通話を一旦切り上げて家を出る。
- 高代謝かつ環境ノイズに敏感な身体特性を制御・維持するため、静寂な作業環境を求めて「国立温泉」への移動を開始。

### <span style="color: dimgray;">──────────────────────</span>

### 【自宅：カリンバ練習とヘッドホン二刀流パズルの真剣議論】〔10:30~13:00〕
- 午前10時半頃に起床し、遠距離の彼女と電話をしながらカリンバの練習を行う。
- [cite_start]その後スマホのスピーカーマイク故障を契機とした「ヘッドホン購入問題」について、13時頃まで約3時間にわたり真剣に議論を交わす [cite: 17]。
- [cite_start]夏場の着用による暑さ（代謝・体温調整へのノイズ）を回避するため、当初の有線骨伝導案から「夏は首掛けスピーカー、冬はヘッドホン」という二刀流のハイブリッド構造を考案 [cite: 14, 23]。
- [cite_start]自分の手持ち現金、キャリーリュック予算、彼女の誕生日予算などの財務防衛ラインを死守しつつ、お互いの負担を最適化するタイミング分散投資のパズルを徹底的に精査する [cite: 18, 23]。
    - 『いかん、彼女との会話に三時間近く費やしてしまった、ヘッドホンを買ってもらうかどうかということで、こんなにも時間を使ってしまったのは、非常に勿体ない。その時間があれば、自分の成長を図って、少しでもお金を稼げるような自分になるという道を選んだ方が、よほど賢明だったのに。もう少し彼女とのコミュニケーションの仕方や時間の使い方を賢く使えるようにならなければいけない』
    - 『この中では、首掛けスピーカーとヘッドホンを二刀流で行くのが良いと思うのだがどうだろうか。彼女に、贈り物を返す前提を伝えて、少しでも負担の少ない商品を選もらいたい。長い目ではヘッドホンが強いだろうが、夏場は首掛けスピーカーかメガネ型イヤホンが良さそうだ 其の上で、マイクの性能などをよく吟味し、二人で購入タイミングを配分していくというのは。』

### ────────■

%% Begin Waypoint %%
- [[”ヘッドホン問題”]]
- [[”不安の種”]]
- [[☷│2026-06-30.base|☷│2026-06-30]]

%% End Waypoint %%

|           name            |
| ------------------------- |
|         ”ヘッドホン問題”         |
|          ”不安の種”           |
|         (ⅶ)_🍃-⑧          |
|           〔1月〕            |
|           〔1月〕            |
|           〔1月〕            |
|           〔1月〕            |
|           〔2月〕            |
|           〔2月〕            |
|           〔2月〕            |
|           〔2月〕            |
|           〔2月〕            |
|           〔3月〕            |
|           〔3月〕            |
|           〔3月〕            |
|           〔3月〕            |
|           〔4月〕            |
|           〔4月〕            |
|           〔4月〕            |
|           〔4月〕            |
|           〔4月〕            |
|           〔5月〕            |
|           〔5月〕            |
|           〔5月〕            |
|           〔5月〕            |
|           〔5月〕            |
|           〔6月〕            |
|           〔6月〕            |
|           〔6月〕            |
|           〔6月〕            |
|           〔6月〕            |
|           〔6月〕            |
|           〔7月〕            |
|           〔7月〕            |
|           〔7月〕            |
|           〔7月〕            |
|           〔7月〕            |
|           〔8月〕            |
|           〔8月〕            |
|           〔8月〕            |
|           〔8月〕            |
|           〔8月〕            |
|           〔9月〕            |
|           〔9月〕            |
|           〔9月〕            |
|           〔9月〕            |
|           〔9月〕            |
|           〔9月〕            |
|           〔10月〕           |
|           〔10月〕           |
|           〔10月〕           |
|           〔10月〕           |
|           〔10月〕           |
|           〔11月〕           |
|           〔11月〕           |
|           〔11月〕           |
|           〔11月〕           |
|           〔11月〕           |
|           〔12月〕           |
|           〔12月〕           |
|           〔12月〕           |
|           〔12月〕           |
|           〔12月〕           |
|          〔2000年〕          |
|          〔2001年〕          |
|          〔2002年〕          |
|          〔2003年〕          |
|          〔2004年〕          |
|          〔2005年〕          |
|          〔2006年〕          |
|          〔2008年〕          |
|          〔2009年〕          |
|          〔2010年〕          |
|          〔2011年〕          |
|          〔2012年〕          |
|          〔2013年〕          |
|          〔2014年〕          |
|          〔2015年〕          |
|          〔2017年〕          |
|          〔2018年〕          |
|          〔2019年〕          |
|          〔2020年〕          |
|          〔2021年〕          |
|          〔2022年〕          |
|          〔2023年〕          |
|          〔2025年〕          |
|          〔2027年〕          |
|          〔2028年〕          |
|          〔2029年〕          |
|          〔2030年〕          |
|        │Obsidian設定        |
|           │臨時命令           |
|     ☷│2016-05-02.BASE     |
|     ☷│2027-01-01.base     |
|     ☷│2027-01-02.base     |
|     ☷│2027-01-03.base     |
|     ☷│2027-01-04.base     |
|     ☷│2027-01-05.base     |
|     ☷│2027-01-06.base     |
|     ☷│2027-01-07.base     |
|     ☷│2027-01-08.base     |
|     ☷│2027-01-09.base     |
|     ☷│2027-01-10.base     |
|     ☷│2027-01-11.base     |
|     ☷│2027-01-12.base     |
|     ☷│2027-01-13.base     |
|     ☷│2027-01-14.base     |
|     ☷│2027-01-15.base     |
|     ☷│2027-01-16.base     |
|     ☷│2027-01-17.base     |
|     ☷│2027-01-18.base     |
|     ☷│2027-01-19.base     |
|     ☷│2027-01-20.base     |
|     ☷│2027-01-21.base     |
|     ☷│2027-01-22.base     |
|     ☷│2027-01-23.base     |
|     ☷│2027-01-24.base     |
|     ☷│2027-01-25.base     |
|     ☷│2027-01-26.base     |
|     ☷│2027-01-27.base     |
|     ☷│2027-01-28.base     |
|     ☷│2027-01-29.base     |
|     ☷│2027-01-30.base     |
|     ☷│2027-01-31.base     |
|     ☷│2027-02-01.base     |
|     ☷│2027-02-02.base     |
|     ☷│2027-02-03.base     |
|     ☷│2027-02-04.base     |
|     ☷│2027-02-05.base     |
|     ☷│2027-02-06.base     |
|     ☷│2027-02-07.base     |
|     ☷│2027-02-08.base     |
|     ☷│2027-02-09.base     |
|     ☷│2027-02-10.base     |
|     ☷│2027-02-11.base     |
|     ☷│2027-02-12.base     |
|     ☷│2027-02-13.base     |
|     ☷│2027-02-14.base     |
|     ☷│2027-02-15.base     |
|     ☷│2027-02-16.base     |
|     ☷│2027-02-17.base     |
|     ☷│2027-02-18.base     |
|     ☷│2027-02-19.base     |
|     ☷│2027-02-20.base     |
|     ☷│2027-02-21.base     |
|     ☷│2027-02-22.base     |
|     ☷│2027-02-23.base     |
|     ☷│2027-02-24.base     |
|     ☷│2027-02-25.base     |
|     ☷│2027-02-26.base     |
|     ☷│2027-02-27.base     |
|     ☷│2027-02-28.base     |
|     ☷│2027-03-01.base     |
|     ☷│2027-03-02.base     |
|     ☷│2027-03-03.base     |
|     ☷│2027-03-04.base     |
|     ☷│2027-03-05.base     |
|     ☷│2027-03-06.base     |
|     ☷│2027-03-07.base     |
|     ☷│2027-03-08.base     |
|     ☷│2027-03-09.base     |
|     ☷│2027-03-10.base     |
|     ☷│2027-03-11.base     |
|     ☷│2027-03-12.base     |
|     ☷│2027-03-13.base     |
|     ☷│2027-03-14.base     |
|     ☷│2027-03-15.base     |
|     ☷│2027-03-16.base     |
|     ☷│2027-03-17.base     |
|     ☷│2027-03-18.base     |
|     ☷│2027-03-19.base     |
|     ☷│2027-03-20.base     |
|     ☷│2027-03-21.base     |
|     ☷│2027-03-22.base     |
|     ☷│2027-03-23.base     |
|     ☷│2027-03-24.base     |
|     ☷│2027-03-25.base     |
|     ☷│2027-03-26.base     |
|     ☷│2027-03-27.base     |
|     ☷│2027-03-28.base     |
|     ☷│2027-03-29.base     |
|     ☷│2027-03-30.base     |
|     ☷│2027-03-31.base     |
|     ☷│2027-04-01.base     |
|     ☷│2027-04-02.base     |
|     ☷│2027-04-03.base     |
|     ☷│2027-04-04.base     |
|     ☷│2027-04-05.base     |
|     ☷│2027-04-06.base     |
|     ☷│2027-04-07.base     |
|     ☷│2027-04-08.base     |
|     ☷│2027-04-09.base     |
|     ☷│2027-04-10.base     |
|     ☷│2027-04-11.base     |
|     ☷│2027-04-12.base     |
|     ☷│2027-04-13.base     |
|     ☷│2027-04-14.base     |
|     ☷│2027-04-15.base     |
|     ☷│2027-04-16.base     |
|     ☷│2027-04-17.base     |
|     ☷│2027-04-18.base     |
|     ☷│2027-04-19.base     |
|     ☷│2027-04-20.base     |
|     ☷│2027-04-21.base     |
|     ☷│2027-04-22.base     |
|     ☷│2027-04-23.base     |
|     ☷│2027-04-24.base     |
|     ☷│2027-04-25.base     |
|     ☷│2027-04-26.base     |
|     ☷│2027-04-27.base     |
|     ☷│2027-04-28.base     |
|     ☷│2027-04-29.base     |
|     ☷│2027-04-30.base     |
|     ☷│2027-05-01.base     |
|     ☷│2027-05-02.base     |
|     ☷│2027-05-03.base     |
|     ☷│2027-05-04.base     |
|     ☷│2027-05-05.base     |
|     ☷│2027-05-06.base     |
|     ☷│2027-05-07.base     |
|     ☷│2027-05-08.base     |
|     ☷│2027-05-09.base     |
|     ☷│2027-05-10.base     |
|     ☷│2027-05-11.base     |
|     ☷│2027-05-12.base     |
|     ☷│2027-05-13.base     |
|     ☷│2027-05-14.base     |
|     ☷│2027-05-15.base     |
|     ☷│2027-05-16.base     |
|     ☷│2027-05-17.base     |
|     ☷│2027-05-18.base     |
|     ☷│2027-05-19.base     |
|     ☷│2027-05-20.base     |
|     ☷│2027-05-21.base     |
|     ☷│2027-05-22.base     |
|     ☷│2027-05-23.base     |
|     ☷│2027-05-24.base     |
|     ☷│2027-05-25.base     |
|     ☷│2027-05-26.base     |
|     ☷│2027-05-27.base     |
|     ☷│2027-05-28.base     |
|     ☷│2027-05-29.base     |
|     ☷│2027-05-30.base     |
|     ☷│2027-05-31.base     |
|     ☷│2027-06-01.base     |
|     ☷│2027-06-02.base     |
|     ☷│2027-06-03.base     |
|     ☷│2027-06-04.base     |
|     ☷│2027-06-05.base     |
|     ☷│2027-06-06.base     |
|     ☷│2027-06-07.base     |
|     ☷│2027-06-08.base     |
|     ☷│2027-06-09.base     |
|     ☷│2027-06-10.base     |
|     ☷│2027-06-11.base     |
|     ☷│2027-06-12.base     |
|     ☷│2027-06-13.base     |
|     ☷│2027-06-14.base     |
|     ☷│2027-06-15.base     |
|     ☷│2027-06-16.base     |
|     ☷│2027-06-17.base     |
|     ☷│2027-06-18.base     |
|     ☷│2027-06-19.base     |
|     ☷│2027-06-20.base     |
|     ☷│2027-06-21.base     |
|     ☷│2027-06-22.base     |
|     ☷│2027-06-23.base     |
|     ☷│2027-06-24.base     |
|     ☷│2027-06-25.base     |
|     ☷│2027-06-26.base     |
|     ☷│2027-06-27.base     |
|     ☷│2027-06-28.base     |
|     ☷│2027-06-29.base     |
|     ☷│2027-06-30.base     |
|     ☷│2027-07-01.base     |
|     ☷│2027-07-02.base     |
|     ☷│2027-07-03.base     |
|     ☷│2027-07-04.base     |
|     ☷│2027-07-05.base     |
|     ☷│2027-07-06.base     |
|     ☷│2027-07-07.base     |
|     ☷│2027-07-08.base     |
|     ☷│2027-07-09.base     |
|     ☷│2027-07-10.base     |
|     ☷│2027-07-11.base     |
|     ☷│2027-07-12.base     |
|     ☷│2027-07-13.base     |
|     ☷│2027-07-14.base     |
|     ☷│2027-07-15.base     |
|     ☷│2027-07-16.base     |
|     ☷│2027-07-17.base     |
|     ☷│2027-07-18.base     |
|     ☷│2027-07-19.base     |
|     ☷│2027-07-20.base     |
|     ☷│2027-07-21.base     |
|     ☷│2027-07-22.base     |
|     ☷│2027-07-23.base     |
|     ☷│2027-07-24.base     |
|     ☷│2027-07-25.base     |
|     ☷│2027-07-26.base     |
|     ☷│2027-07-27.base     |
|     ☷│2027-07-28.base     |
|     ☷│2027-07-29.base     |
|     ☷│2027-07-30.base     |
|     ☷│2027-07-31.base     |
|     ☷│2027-08-01.base     |
|     ☷│2027-08-02.base     |
|     ☷│2027-08-03.base     |
|     ☷│2027-08-04.base     |
|     ☷│2027-08-05.base     |
|     ☷│2027-08-06.base     |
|     ☷│2027-08-07.base     |
|     ☷│2027-08-08.base     |
|     ☷│2027-08-09.base     |
|     ☷│2027-08-10.base     |
|     ☷│2027-08-11.base     |
|     ☷│2027-08-12.base     |
|     ☷│2027-08-13.base     |
|     ☷│2027-08-14.base     |
|     ☷│2027-08-15.base     |
|     ☷│2027-08-16.base     |
|     ☷│2027-08-17.base     |
|     ☷│2027-08-18.base     |
|     ☷│2027-08-19.base     |
|     ☷│2027-08-20.base     |
|     ☷│2027-08-21.base     |
|     ☷│2027-08-22.base     |
|     ☷│2027-08-23.base     |
|     ☷│2027-08-24.base     |
|     ☷│2027-08-25.base     |
|     ☷│2027-08-26.base     |
|     ☷│2027-08-27.base     |
|     ☷│2027-08-28.base     |
|     ☷│2027-08-29.base     |
|     ☷│2027-08-30.base     |
|     ☷│2027-08-31.base     |
|     ☷│2027-09-01.base     |
|     ☷│2027-09-02.base     |
|     ☷│2027-09-03.base     |
|     ☷│2027-09-04.base     |
|     ☷│2027-09-05.base     |
|     ☷│2027-09-06.base     |
|     ☷│2027-09-07.base     |
|     ☷│2027-09-08.base     |
|     ☷│2027-09-09.base     |
|     ☷│2027-09-10.base     |
|     ☷│2027-09-11.base     |
|     ☷│2027-09-12.base     |
|     ☷│2027-09-13.base     |
|     ☷│2027-09-14.base     |
|     ☷│2027-09-15.base     |
|     ☷│2027-09-16.base     |
|     ☷│2027-09-17.base     |
|     ☷│2027-09-18.base     |
|     ☷│2027-09-19.base     |
|     ☷│2027-09-20.base     |
|     ☷│2027-09-21.base     |
|     ☷│2027-09-22.base     |
|     ☷│2027-09-23.base     |
|     ☷│2027-09-24.base     |
|     ☷│2027-09-25.base     |
|     ☷│2027-09-26.base     |
|     ☷│2027-09-27.base     |
|     ☷│2027-09-28.base     |
|     ☷│2027-09-29.base     |
|     ☷│2027-09-30.base     |
|     ☷│2027-10-01.base     |
|     ☷│2027-10-02.base     |
|     ☷│2027-10-03.base     |
|     ☷│2027-10-04.base     |
|     ☷│2027-10-05.base     |
|     ☷│2027-10-06.base     |
|     ☷│2027-10-07.base     |
|     ☷│2027-10-08.base     |
|     ☷│2027-10-09.base     |
|     ☷│2027-10-10.base     |
|     ☷│2027-10-11.base     |
|     ☷│2027-10-12.base     |
|     ☷│2027-10-13.base     |
|     ☷│2027-10-14.base     |
|     ☷│2027-10-15.base     |
|     ☷│2027-10-16.base     |
|     ☷│2027-10-17.base     |
|     ☷│2027-10-18.base     |
|     ☷│2027-10-19.base     |
|     ☷│2027-10-20.base     |
|     ☷│2027-10-21.base     |
|     ☷│2027-10-22.base     |
|     ☷│2027-10-23.base     |
|     ☷│2027-10-24.base     |
|     ☷│2027-10-25.base     |
|     ☷│2027-10-26.base     |
|     ☷│2027-10-27.base     |
|     ☷│2027-10-28.base     |
|     ☷│2027-10-29.base     |
|     ☷│2027-10-30.base     |
|     ☷│2027-10-31.base     |
|     ☷│2027-11-01.base     |
|     ☷│2027-11-02.base     |
|     ☷│2027-11-03.base     |
|     ☷│2027-11-04.base     |
|     ☷│2027-11-05.base     |
|     ☷│2027-11-06.base     |
|     ☷│2027-11-07.base     |
|     ☷│2027-11-08.base     |
|     ☷│2027-11-09.base     |
|     ☷│2027-11-10.base     |
|     ☷│2027-11-11.base     |
|     ☷│2027-11-12.base     |
|     ☷│2027-11-13.base     |
|     ☷│2027-11-14.base     |
|     ☷│2027-11-15.base     |
|     ☷│2027-11-16.base     |
|     ☷│2027-11-17.base     |
|     ☷│2027-11-18.base     |
|     ☷│2027-11-19.base     |
|     ☷│2027-11-20.base     |
|     ☷│2027-11-21.base     |
|     ☷│2027-11-22.base     |
|     ☷│2027-11-23.base     |
|     ☷│2027-11-24.base     |
|     ☷│2027-11-25.base     |
|     ☷│2027-11-26.base     |
|     ☷│2027-11-27.base     |
|     ☷│2027-11-28.base     |
|     ☷│2027-11-29.base     |
|     ☷│2027-11-30.base     |
|     ☷│2027-12-01.base     |
|     ☷│2027-12-02.base     |
|     ☷│2027-12-03.base     |
|     ☷│2027-12-04.base     |
|     ☷│2027-12-05.base     |
|     ☷│2027-12-06.base     |
|     ☷│2027-12-07.base     |
|     ☷│2027-12-08.base     |
|     ☷│2027-12-09.base     |
|     ☷│2027-12-10.base     |
|     ☷│2027-12-11.base     |
|     ☷│2027-12-12.base     |
|     ☷│2027-12-13.base     |
|     ☷│2027-12-14.base     |
|     ☷│2027-12-15.base     |
|     ☷│2027-12-16.base     |
|     ☷│2027-12-17.base     |
|     ☷│2027-12-18.base     |
|     ☷│2027-12-19.base     |
|     ☷│2027-12-20.base     |
|     ☷│2027-12-21.base     |
|     ☷│2027-12-22.base     |
|     ☷│2027-12-23.base     |
|     ☷│2027-12-24.base     |
|     ☷│2027-12-25.base     |
|     ☷│2027-12-26.base     |
|     ☷│2027-12-27.base     |
|     ☷│2027-12-28.base     |
|     ☷│2027-12-29.base     |
|     ☷│2027-12-30.base     |
|     ☷│2027-12-31.base     |
|     ☷│2028-01-01.base     |
|     ☷│2028-01-02.base     |
|     ☷│2028-01-03.base     |
|     ☷│2028-01-04.base     |
|     ☷│2028-01-05.base     |
|     ☷│2028-01-06.base     |
|     ☷│2028-01-07.base     |
|     ☷│2028-01-08.base     |
|     ☷│2028-01-09.base     |
|     ☷│2028-01-10.base     |
|     ☷│2028-01-11.base     |
|     ☷│2028-01-12.base     |
|     ☷│2028-01-13.base     |
|     ☷│2028-01-14.base     |
|     ☷│2028-01-15.base     |
|     ☷│2028-01-16.base     |
|     ☷│2028-01-17.base     |
|     ☷│2028-01-18.base     |
|     ☷│2028-01-19.base     |
|     ☷│2028-01-20.base     |
|     ☷│2028-01-21.base     |
|     ☷│2028-01-22.base     |
|     ☷│2028-01-23.base     |
|     ☷│2028-01-24.base     |
|     ☷│2028-01-25.base     |
|     ☷│2028-01-26.base     |
|     ☷│2028-01-27.base     |
|     ☷│2028-01-28.base     |
|     ☷│2028-01-29.base     |
|     ☷│2028-01-30.base     |
|     ☷│2028-01-31.base     |
|     ☷│2028-02-01.base     |
|     ☷│2028-02-02.base     |
|     ☷│2028-02-03.base     |
|     ☷│2028-02-04.base     |
|     ☷│2028-02-05.base     |
|     ☷│2028-02-06.base     |
|     ☷│2028-02-07.base     |
|     ☷│2028-02-08.base     |
|     ☷│2028-02-09.base     |
|     ☷│2028-02-10.base     |
|     ☷│2028-02-11.base     |
|     ☷│2028-02-12.base     |
|     ☷│2028-02-13.base     |
|     ☷│2028-02-14.base     |
|     ☷│2028-02-15.base     |
|     ☷│2028-02-16.base     |
|     ☷│2028-02-17.base     |
|     ☷│2028-02-18.base     |
|     ☷│2028-02-19.base     |
|     ☷│2028-02-20.base     |
|     ☷│2028-02-21.base     |
|     ☷│2028-02-22.base     |
|     ☷│2028-02-23.base     |
|     ☷│2028-02-24.base     |
|     ☷│2028-02-25.base     |
|     ☷│2028-02-26.base     |
|     ☷│2028-02-27.base     |
|     ☷│2028-02-28.base     |
|     ☷│2028-02-29.base     |
|     ☷│2028-03-01.base     |
|     ☷│2028-03-02.base     |
|     ☷│2028-03-03.base     |
|     ☷│2028-03-04.base     |
|     ☷│2028-03-05.base     |
|     ☷│2028-03-06.base     |
|     ☷│2028-03-07.base     |
|     ☷│2028-03-08.base     |
|     ☷│2028-03-09.base     |
|     ☷│2028-03-10.base     |
|     ☷│2028-03-11.base     |
|     ☷│2028-03-12.base     |
|     ☷│2028-03-13.base     |
|     ☷│2028-03-14.base     |
|     ☷│2028-03-15.base     |
|     ☷│2028-03-16.base     |
|     ☷│2028-03-17.base     |
|     ☷│2028-03-18.base     |
|     ☷│2028-03-19.base     |
|     ☷│2028-03-20.base     |
|     ☷│2028-03-21.base     |
|     ☷│2028-03-22.base     |
|     ☷│2028-03-23.base     |
|     ☷│2028-03-24.base     |
|     ☷│2028-03-25.base     |
|     ☷│2028-03-26.base     |
|     ☷│2028-03-27.base     |
|     ☷│2028-03-28.base     |
|     ☷│2028-03-29.base     |
|     ☷│2028-03-30.base     |
|     ☷│2028-03-31.base     |
|     ☷│2028-04-01.base     |
|     ☷│2028-04-02.base     |
|     ☷│2028-04-03.base     |
|     ☷│2028-04-04.base     |
|     ☷│2028-04-05.base     |
|     ☷│2028-04-06.base     |
|     ☷│2028-04-07.base     |
|     ☷│2028-04-08.base     |
|     ☷│2028-04-09.base     |
|     ☷│2028-04-10.base     |
|     ☷│2028-04-11.base     |
|     ☷│2028-04-12.base     |
|     ☷│2028-04-13.base     |
|     ☷│2028-04-14.base     |
|     ☷│2028-04-15.base     |
|     ☷│2028-04-16.base     |
|     ☷│2028-04-17.base     |
|     ☷│2028-04-18.base     |
|     ☷│2028-04-19.base     |
|     ☷│2028-04-20.base     |
|     ☷│2028-04-21.base     |
|     ☷│2028-04-22.base     |
|     ☷│2028-04-23.base     |
|     ☷│2028-04-24.base     |
|     ☷│2028-04-25.base     |
|     ☷│2028-04-26.base     |
|     ☷│2028-04-27.base     |
|     ☷│2028-04-28.base     |
|     ☷│2028-04-29.base     |
|     ☷│2028-04-30.base     |
|     ☷│2028-05-01.base     |
|     ☷│2028-05-02.base     |
|     ☷│2028-05-03.base     |
|     ☷│2028-05-04.base     |
|     ☷│2028-05-05.base     |
|     ☷│2028-05-06.base     |
|     ☷│2028-05-07.base     |
|     ☷│2028-05-08.base     |
|     ☷│2028-05-09.base     |
|     ☷│2028-05-10.base     |
|     ☷│2028-05-11.base     |
|     ☷│2028-05-12.base     |
|     ☷│2028-05-13.base     |
|     ☷│2028-05-14.base     |
|     ☷│2028-05-15.base     |
|     ☷│2028-05-16.base     |
|     ☷│2028-05-17.base     |
|     ☷│2028-05-18.base     |
|     ☷│2028-05-19.base     |
|     ☷│2028-05-20.base     |
|     ☷│2028-05-21.base     |
|     ☷│2028-05-22.base     |
|     ☷│2028-05-23.base     |
|     ☷│2028-05-24.base     |
|     ☷│2028-05-25.base     |
|     ☷│2028-05-26.base     |
|     ☷│2028-05-27.base     |
|     ☷│2028-05-28.base     |
|     ☷│2028-05-29.base     |
|     ☷│2028-05-30.base     |
|     ☷│2028-05-31.base     |
|     ☷│2028-06-01.base     |
|     ☷│2028-06-02.base     |
|     ☷│2028-06-03.base     |
|     ☷│2028-06-04.base     |
|     ☷│2028-06-05.base     |
|     ☷│2028-06-06.base     |
|     ☷│2028-06-07.base     |
|     ☷│2028-06-08.base     |
|     ☷│2028-06-09.base     |
|     ☷│2028-06-10.base     |
|     ☷│2028-06-11.base     |
|     ☷│2028-06-12.base     |
|     ☷│2028-06-13.base     |
|     ☷│2028-06-14.base     |
|     ☷│2028-06-15.base     |
|     ☷│2028-06-16.base     |
|     ☷│2028-06-17.base     |
|     ☷│2028-06-18.base     |
|     ☷│2028-06-19.base     |
|     ☷│2028-06-20.base     |
|     ☷│2028-06-21.base     |
|     ☷│2028-06-22.base     |
|     ☷│2028-06-23.base     |
|     ☷│2028-06-24.base     |
|     ☷│2028-06-25.base     |
|     ☷│2028-06-26.base     |
|     ☷│2028-06-27.base     |
|     ☷│2028-06-28.base     |
|     ☷│2028-06-29.base     |
|     ☷│2028-06-30.base     |
|     ☷│2028-07-01.base     |
|     ☷│2028-07-02.base     |
|     ☷│2028-07-03.base     |
|     ☷│2028-07-04.base     |
|     ☷│2028-07-05.base     |
|     ☷│2028-07-06.base     |
|     ☷│2028-07-07.base     |
|     ☷│2028-07-08.base     |
|     ☷│2028-07-09.base     |
|     ☷│2028-07-10.base     |
|     ☷│2028-07-11.base     |
|     ☷│2028-07-12.base     |
|     ☷│2028-07-13.base     |
|     ☷│2028-07-14.base     |
|     ☷│2028-07-15.base     |
|     ☷│2028-07-16.base     |
|     ☷│2028-07-17.base     |
|     ☷│2028-07-18.base     |
|     ☷│2028-07-19.base     |
|     ☷│2028-07-20.base     |
|     ☷│2028-07-21.base     |
|     ☷│2028-07-22.base     |
|     ☷│2028-07-23.base     |
|     ☷│2028-07-24.base     |
|     ☷│2028-07-25.base     |
|     ☷│2028-07-26.base     |
|     ☷│2028-07-27.base     |
|     ☷│2028-07-28.base     |
|     ☷│2028-07-29.base     |
|     ☷│2028-07-30.base     |
|     ☷│2028-07-31.base     |
|     ☷│2028-08-01.base     |
|     ☷│2028-08-02.base     |
|     ☷│2028-08-03.base     |
|     ☷│2028-08-04.base     |
|     ☷│2028-08-05.base     |
|     ☷│2028-08-06.base     |
|     ☷│2028-08-07.base     |
|     ☷│2028-08-08.base     |
|     ☷│2028-08-09.base     |
|     ☷│2028-08-10.base     |
|     ☷│2028-08-11.base     |
|     ☷│2028-08-12.base     |
|     ☷│2028-08-13.base     |
|     ☷│2028-08-14.base     |
|     ☷│2028-08-15.base     |
|     ☷│2028-08-16.base     |
|     ☷│2028-08-17.base     |
|     ☷│2028-08-18.base     |
|     ☷│2028-08-19.base     |
|     ☷│2028-08-20.base     |
|     ☷│2028-08-21.base     |
|     ☷│2028-08-22.base     |
|     ☷│2028-08-23.base     |
|     ☷│2028-08-24.base     |
|     ☷│2028-08-25.base     |
|     ☷│2028-08-26.base     |
|     ☷│2028-08-27.base     |
|     ☷│2028-08-28.base     |
|     ☷│2028-08-29.base     |
|     ☷│2028-08-30.base     |
|     ☷│2028-08-31.base     |
|     ☷│2028-09-01.base     |
|     ☷│2028-09-02.base     |
|     ☷│2028-09-03.base     |
|     ☷│2028-09-04.base     |
|     ☷│2028-09-05.base     |
|     ☷│2028-09-06.base     |
|     ☷│2028-09-07.base     |
|     ☷│2028-09-08.base     |
|     ☷│2028-09-09.base     |
|     ☷│2028-09-10.base     |
|     ☷│2028-09-11.base     |
|     ☷│2028-09-12.base     |
|     ☷│2028-09-13.base     |
|     ☷│2028-09-14.base     |
|     ☷│2028-09-15.base     |
|     ☷│2028-09-16.base     |
|     ☷│2028-09-17.base     |
|     ☷│2028-09-18.base     |
|     ☷│2028-09-19.base     |
|     ☷│2028-09-20.base     |
|     ☷│2028-09-21.base     |
|     ☷│2028-09-22.base     |
|     ☷│2028-09-23.base     |
|     ☷│2028-09-24.base     |
|     ☷│2028-09-25.base     |
|     ☷│2028-09-26.base     |
|     ☷│2028-09-27.base     |
|     ☷│2028-09-28.base     |
|     ☷│2028-09-29.base     |
|     ☷│2028-09-30.base     |
|     ☷│2028-10-01.base     |
|     ☷│2028-10-02.base     |
|     ☷│2028-10-03.base     |
|     ☷│2028-10-04.base     |
|     ☷│2028-10-05.base     |
|     ☷│2028-10-06.base     |
|     ☷│2028-10-07.base     |
|     ☷│2028-10-08.base     |
|     ☷│2028-10-09.base     |
|     ☷│2028-10-10.base     |
|     ☷│2028-10-11.base     |
|     ☷│2028-10-12.base     |
|     ☷│2028-10-13.base     |
|     ☷│2028-10-14.base     |
|     ☷│2028-10-15.base     |
|     ☷│2028-10-16.base     |
|     ☷│2028-10-17.base     |
|     ☷│2028-10-18.base     |
|     ☷│2028-10-19.base     |
|     ☷│2028-10-20.base     |
|     ☷│2028-10-21.base     |
|     ☷│2028-10-22.base     |
|     ☷│2028-10-23.base     |
|     ☷│2028-10-24.base     |
|     ☷│2028-10-25.base     |
|     ☷│2028-10-26.base     |
|     ☷│2028-10-27.base     |
|     ☷│2028-10-28.base     |
|     ☷│2028-10-29.base     |
|     ☷│2028-10-30.base     |
|     ☷│2028-10-31.base     |
|     ☷│2028-11-01.base     |
|     ☷│2028-11-02.base     |
|     ☷│2028-11-03.base     |
|     ☷│2028-11-04.base     |
|     ☷│2028-11-05.base     |
|     ☷│2028-11-06.base     |
|     ☷│2028-11-07.base     |
|     ☷│2028-11-08.base     |
|     ☷│2028-11-09.base     |
|     ☷│2028-11-10.base     |
|     ☷│2028-11-11.base     |
|     ☷│2028-11-12.base     |
|     ☷│2028-11-13.base     |
|     ☷│2028-11-14.base     |
|     ☷│2028-11-15.base     |
|     ☷│2028-11-16.base     |
|     ☷│2028-11-17.base     |
|     ☷│2028-11-18.base     |
|     ☷│2028-11-19.base     |
|     ☷│2028-11-20.base     |
|     ☷│2028-11-21.base     |
|     ☷│2028-11-22.base     |
|     ☷│2028-11-23.base     |
|     ☷│2028-11-24.base     |
|     ☷│2028-11-25.base     |
|     ☷│2028-11-26.base     |
|     ☷│2028-11-27.base     |
|     ☷│2028-11-28.base     |
|     ☷│2028-11-29.base     |
|     ☷│2028-11-30.base     |
|     ☷│2028-12-01.base     |
|     ☷│2028-12-02.base     |
|     ☷│2028-12-03.base     |
|     ☷│2028-12-04.base     |
|     ☷│2028-12-05.base     |
|     ☷│2028-12-06.base     |
|     ☷│2028-12-07.base     |
|     ☷│2028-12-08.base     |
|     ☷│2028-12-09.base     |
|     ☷│2028-12-10.base     |
|     ☷│2028-12-11.base     |
|     ☷│2028-12-12.base     |
|     ☷│2028-12-13.base     |
|     ☷│2028-12-14.base     |
|     ☷│2028-12-15.base     |
|     ☷│2028-12-16.base     |
|     ☷│2028-12-17.base     |
|     ☷│2028-12-18.base     |
|     ☷│2028-12-19.base     |
|     ☷│2028-12-20.base     |
|     ☷│2028-12-21.base     |
|     ☷│2028-12-22.base     |
|     ☷│2028-12-23.base     |
|     ☷│2028-12-24.base     |
|     ☷│2028-12-25.base     |
|     ☷│2028-12-26.base     |
|     ☷│2028-12-27.base     |
|     ☷│2028-12-28.base     |
|     ☷│2028-12-29.base     |
|     ☷│2028-12-30.base     |
|     ☷│2028-12-31.base     |
|     ☷│2029-01-01.base     |
|     ☷│2029-01-02.base     |
|     ☷│2029-01-03.base     |
|     ☷│2029-01-04.base     |
|     ☷│2029-01-05.base     |
|     ☷│2029-01-06.base     |
|     ☷│2029-01-07.base     |
|     ☷│2029-01-08.base     |
|     ☷│2029-01-09.base     |
|     ☷│2029-01-10.base     |
|     ☷│2029-01-11.base     |
|     ☷│2029-01-12.base     |
|     ☷│2029-01-13.base     |
|     ☷│2029-01-14.base     |
|     ☷│2029-01-15.base     |
|     ☷│2029-01-16.base     |
|     ☷│2029-01-17.base     |
|     ☷│2029-01-18.base     |
|     ☷│2029-01-19.base     |
|     ☷│2029-01-20.base     |
|     ☷│2029-01-21.base     |
|     ☷│2029-01-22.base     |
|     ☷│2029-01-23.base     |
|     ☷│2029-01-24.base     |
|     ☷│2029-01-25.base     |
|     ☷│2029-01-26.base     |
|     ☷│2029-01-27.base     |
|     ☷│2029-01-28.base     |
|     ☷│2029-01-29.base     |
|     ☷│2029-01-30.base     |
|     ☷│2029-01-31.base     |
|     ☷│2029-02-01.base     |
|     ☷│2029-02-02.base     |
|     ☷│2029-02-03.base     |
|     ☷│2029-02-04.base     |
|     ☷│2029-02-05.base     |
|     ☷│2029-02-06.base     |
|     ☷│2029-02-07.base     |
|     ☷│2029-02-08.base     |
|     ☷│2029-02-09.base     |
|     ☷│2029-02-10.base     |
|     ☷│2029-02-11.base     |
|     ☷│2029-02-12.base     |
|     ☷│2029-02-13.base     |
|     ☷│2029-02-14.base     |
|     ☷│2029-02-15.base     |
|     ☷│2029-02-16.base     |
|     ☷│2029-02-17.base     |
|     ☷│2029-02-18.base     |
|     ☷│2029-02-19.base     |
|     ☷│2029-02-20.base     |
|     ☷│2029-02-21.base     |
|     ☷│2029-02-22.base     |
|     ☷│2029-02-23.base     |
|     ☷│2029-02-24.base     |
|     ☷│2029-02-25.base     |
|     ☷│2029-02-26.base     |
|     ☷│2029-02-27.base     |
|     ☷│2029-02-28.base     |
|     ☷│2029-03-01.base     |
|     ☷│2029-03-02.base     |
|     ☷│2029-03-03.base     |
|     ☷│2029-03-04.base     |
|     ☷│2029-03-05.base     |
|     ☷│2029-03-06.base     |
|     ☷│2029-03-07.base     |
|     ☷│2029-03-08.base     |
|     ☷│2029-03-09.base     |
|     ☷│2029-03-10.base     |
|     ☷│2029-03-11.base     |
|     ☷│2029-03-12.base     |
|     ☷│2029-03-13.base     |
|     ☷│2029-03-14.base     |
|     ☷│2029-03-15.base     |
|     ☷│2029-03-16.base     |
|     ☷│2029-03-17.base     |
|     ☷│2029-03-18.base     |
|     ☷│2029-03-19.base     |
|     ☷│2029-03-20.base     |
|     ☷│2029-03-21.base     |
|     ☷│2029-03-22.base     |
|     ☷│2029-03-23.base     |
|     ☷│2029-03-24.base     |
|     ☷│2029-03-25.base     |
|     ☷│2029-03-26.base     |
|     ☷│2029-03-27.base     |
|     ☷│2029-03-28.base     |
|     ☷│2029-03-29.base     |
|     ☷│2029-03-30.base     |
|     ☷│2029-03-31.base     |
|     ☷│2029-04-01.base     |
|     ☷│2029-04-02.base     |
|     ☷│2029-04-03.base     |
|     ☷│2029-04-04.base     |
|     ☷│2029-04-05.base     |
|     ☷│2029-04-06.base     |
|     ☷│2029-04-07.base     |
|     ☷│2029-04-08.base     |
|     ☷│2029-04-09.base     |
|     ☷│2029-04-10.base     |
|     ☷│2029-04-11.base     |
|     ☷│2029-04-12.base     |
|     ☷│2029-04-13.base     |
|     ☷│2029-04-14.base     |
|     ☷│2029-04-15.base     |
|     ☷│2029-04-16.base     |
|     ☷│2029-04-17.base     |
|     ☷│2029-04-18.base     |
|     ☷│2029-04-19.base     |
|     ☷│2029-04-20.base     |
|     ☷│2029-04-21.base     |
|     ☷│2029-04-22.base     |
|     ☷│2029-04-23.base     |
|     ☷│2029-04-24.base     |
|     ☷│2029-04-25.base     |
|     ☷│2029-04-26.base     |
|     ☷│2029-04-27.base     |
|     ☷│2029-04-28.base     |
|     ☷│2029-04-29.base     |
|     ☷│2029-04-30.base     |
|     ☷│2029-05-01.base     |
|     ☷│2029-05-02.base     |
|     ☷│2029-05-03.base     |
|     ☷│2029-05-04.base     |
|     ☷│2029-05-05.base     |
|     ☷│2029-05-06.base     |
|     ☷│2029-05-07.base     |
|     ☷│2029-05-08.base     |
|     ☷│2029-05-09.base     |
|     ☷│2029-05-10.base     |
|     ☷│2029-05-11.base     |
|     ☷│2029-05-12.base     |
|     ☷│2029-05-13.base     |
|     ☷│2029-05-14.base     |
|     ☷│2029-05-15.base     |
|     ☷│2029-05-16.base     |
|     ☷│2029-05-17.base     |
|     ☷│2029-05-18.base     |
|     ☷│2029-05-19.base     |
|     ☷│2029-05-20.base     |
|     ☷│2029-05-21.base     |
|     ☷│2029-05-22.base     |
|     ☷│2029-05-23.base     |
|     ☷│2029-05-24.base     |
|     ☷│2029-05-25.base     |
|     ☷│2029-05-26.base     |
|     ☷│2029-05-27.base     |
|     ☷│2029-05-28.base     |
|     ☷│2029-05-29.base     |
|     ☷│2029-05-30.base     |
|     ☷│2029-05-31.base     |
|     ☷│2029-06-01.base     |
|     ☷│2029-06-02.base     |
|     ☷│2029-06-03.base     |
|     ☷│2029-06-04.base     |
|     ☷│2029-06-05.base     |
|     ☷│2029-06-06.base     |
|     ☷│2029-06-07.base     |
|     ☷│2029-06-08.base     |
|     ☷│2029-06-09.base     |
|     ☷│2029-06-10.base     |
|     ☷│2029-06-11.base     |
|     ☷│2029-06-12.base     |
|     ☷│2029-06-13.base     |
|     ☷│2029-06-14.base     |
|     ☷│2029-06-15.base     |
|     ☷│2029-06-16.base     |
|     ☷│2029-06-17.base     |
|     ☷│2029-06-18.base     |
|     ☷│2029-06-19.base     |
|     ☷│2029-06-20.base     |
|     ☷│2029-06-21.base     |
|     ☷│2029-06-22.base     |
|     ☷│2029-06-23.base     |
|     ☷│2029-06-24.base     |
|     ☷│2029-06-25.base     |
|     ☷│2029-06-26.base     |
|     ☷│2029-06-27.base     |
|     ☷│2029-06-28.base     |
|     ☷│2029-06-29.base     |
|     ☷│2029-06-30.base     |
|     ☷│2029-07-01.base     |
|     ☷│2029-07-02.base     |
|     ☷│2029-07-03.base     |
|     ☷│2029-07-04.base     |
|     ☷│2029-07-05.base     |
|     ☷│2029-07-06.base     |
|     ☷│2029-07-07.base     |
|     ☷│2029-07-08.base     |
|     ☷│2029-07-09.base     |
|     ☷│2029-07-10.base     |
|     ☷│2029-07-11.base     |
|     ☷│2029-07-12.base     |
|     ☷│2029-07-13.base     |
|     ☷│2029-07-14.base     |
|     ☷│2029-07-15.base     |
|     ☷│2029-07-16.base     |
|     ☷│2029-07-17.base     |
|     ☷│2029-07-18.base     |
|     ☷│2029-07-19.base     |
|     ☷│2029-07-20.base     |
|     ☷│2029-07-21.base     |
|     ☷│2029-07-22.base     |
|     ☷│2029-07-23.base     |
|     ☷│2029-07-24.base     |
|     ☷│2029-07-25.base     |
|     ☷│2029-07-26.base     |
|     ☷│2029-07-27.base     |
|     ☷│2029-07-28.base     |
|     ☷│2029-07-29.base     |
|     ☷│2029-07-30.base     |
|     ☷│2029-07-31.base     |
|     ☷│2029-08-01.base     |
|     ☷│2029-08-02.base     |
|     ☷│2029-08-03.base     |
|     ☷│2029-08-04.base     |
|     ☷│2029-08-05.base     |
|     ☷│2029-08-06.base     |
|     ☷│2029-08-07.base     |
|     ☷│2029-08-08.base     |
|     ☷│2029-08-09.base     |
|     ☷│2029-08-10.base     |
|     ☷│2029-08-11.base     |
|     ☷│2029-08-12.base     |
|     ☷│2029-08-13.base     |
|     ☷│2029-08-14.base     |
|     ☷│2029-08-15.base     |
|     ☷│2029-08-16.base     |
|     ☷│2029-08-17.base     |
|     ☷│2029-08-18.base     |
|     ☷│2029-08-19.base     |
|     ☷│2029-08-20.base     |
|     ☷│2029-08-21.base     |
|     ☷│2029-08-22.base     |
|     ☷│2029-08-23.base     |
|     ☷│2029-08-24.base     |
|     ☷│2029-08-25.base     |
|     ☷│2029-08-26.base     |
|     ☷│2029-08-27.base     |
|     ☷│2029-08-28.base     |
|     ☷│2029-08-29.base     |
|     ☷│2029-08-30.base     |
|     ☷│2029-08-31.base     |
|     ☷│2029-09-01.base     |
|     ☷│2029-09-02.base     |
|     ☷│2029-09-03.base     |
|     ☷│2029-09-04.base     |
|     ☷│2029-09-05.base     |
|     ☷│2029-09-06.base     |
|     ☷│2029-09-07.base     |
|     ☷│2029-09-08.base     |
|     ☷│2029-09-09.base     |
|     ☷│2029-09-10.base     |
|     ☷│2029-09-11.base     |
|     ☷│2029-09-12.base     |
|     ☷│2029-09-13.base     |
|     ☷│2029-09-14.base     |
|     ☷│2029-09-15.base     |
|     ☷│2029-09-16.base     |
|     ☷│2029-09-17.base     |
|     ☷│2029-09-18.base     |
|     ☷│2029-09-19.base     |
|     ☷│2029-09-20.base     |
|     ☷│2029-09-21.base     |
|     ☷│2029-09-22.base     |
|     ☷│2029-09-23.base     |
|     ☷│2029-09-24.base     |
|     ☷│2029-09-25.base     |
|     ☷│2029-09-26.base     |
|     ☷│2029-09-27.base     |
|     ☷│2029-09-28.base     |
|     ☷│2029-09-29.base     |
|     ☷│2029-09-30.base     |
|     ☷│2029-10-01.base     |
|     ☷│2029-10-02.base     |
|     ☷│2029-10-03.base     |
|     ☷│2029-10-04.base     |
|     ☷│2029-10-05.base     |
|     ☷│2029-10-06.base     |
|     ☷│2029-10-07.base     |
|     ☷│2029-10-08.base     |
|     ☷│2029-10-09.base     |
|     ☷│2029-10-10.base     |
|     ☷│2029-10-11.base     |
|     ☷│2029-10-12.base     |
|     ☷│2029-10-13.base     |
|     ☷│2029-10-14.base     |
|     ☷│2029-10-15.base     |
|     ☷│2029-10-16.base     |
|     ☷│2029-10-17.base     |
|     ☷│2029-10-18.base     |
|     ☷│2029-10-19.base     |
|     ☷│2029-10-20.base     |
|     ☷│2029-10-21.base     |
|     ☷│2029-10-22.base     |
|     ☷│2029-10-23.base     |
|     ☷│2029-10-24.base     |
|     ☷│2029-10-25.base     |
|     ☷│2029-10-26.base     |
|     ☷│2029-10-27.base     |
|     ☷│2029-10-28.base     |
|     ☷│2029-10-29.base     |
|     ☷│2029-10-30.base     |
|     ☷│2029-10-31.base     |
|     ☷│2029-11-01.base     |
|     ☷│2029-11-02.base     |
|     ☷│2029-11-03.base     |
|     ☷│2029-11-04.base     |
|     ☷│2029-11-05.base     |
|     ☷│2029-11-06.base     |
|     ☷│2029-11-07.base     |
|     ☷│2029-11-08.base     |
|     ☷│2029-11-09.base     |
|     ☷│2029-11-10.base     |
|     ☷│2029-11-11.base     |
|     ☷│2029-11-12.base     |
|     ☷│2029-11-13.base     |
|     ☷│2029-11-14.base     |
|     ☷│2029-11-15.base     |
|     ☷│2029-11-16.base     |
|     ☷│2029-11-17.base     |
|     ☷│2029-11-18.base     |
|     ☷│2029-11-19.base     |
|     ☷│2029-11-20.base     |
|     ☷│2029-11-21.base     |
|     ☷│2029-11-22.base     |
|     ☷│2029-11-23.base     |
|     ☷│2029-11-24.base     |
|     ☷│2029-11-25.base     |
|     ☷│2029-11-26.base     |
|     ☷│2029-11-27.base     |
|     ☷│2029-11-28.base     |
|     ☷│2029-11-29.base     |
|     ☷│2029-11-30.base     |
|     ☷│2029-12-01.base     |
|     ☷│2029-12-02.base     |
|     ☷│2029-12-03.base     |
|     ☷│2029-12-04.base     |
|     ☷│2029-12-05.base     |
|     ☷│2029-12-06.base     |
|     ☷│2029-12-07.base     |
|     ☷│2029-12-08.base     |
|     ☷│2029-12-09.base     |
|     ☷│2029-12-10.base     |
|     ☷│2029-12-11.base     |
|     ☷│2029-12-12.base     |
|     ☷│2029-12-13.base     |
|     ☷│2029-12-14.base     |
|     ☷│2029-12-15.base     |
|     ☷│2029-12-16.base     |
|     ☷│2029-12-17.base     |
|     ☷│2029-12-18.base     |
|     ☷│2029-12-19.base     |
|     ☷│2029-12-20.base     |
|     ☷│2029-12-21.base     |
|     ☷│2029-12-22.base     |
|     ☷│2029-12-23.base     |
|     ☷│2029-12-24.base     |
|     ☷│2029-12-25.base     |
|     ☷│2029-12-26.base     |
|     ☷│2029-12-27.base     |
|     ☷│2029-12-28.base     |
|     ☷│2029-12-29.base     |
|     ☷│2029-12-30.base     |
|     ☷│2029-12-31.base     |
|     ☷│2030-01-01.base     |
|     ☷│2030-01-02.base     |
|     ☷│2030-01-03.base     |
|     ☷│2030-01-04.base     |
|     ☷│2030-01-05.base     |
|     ☷│2030-01-06.base     |
|     ☷│2030-01-07.base     |
|     ☷│2030-01-08.base     |
|     ☷│2030-01-09.base     |
|     ☷│2030-01-10.base     |
|     ☷│2030-01-11.base     |
|     ☷│2030-01-12.base     |
|     ☷│2030-01-13.base     |
|     ☷│2030-01-14.base     |
|     ☷│2030-01-15.base     |
|     ☷│2030-01-16.base     |
|     ☷│2030-01-17.base     |
|     ☷│2030-01-18.base     |
|     ☷│2030-01-19.base     |
|     ☷│2030-01-20.base     |
|     ☷│2030-01-21.base     |
|     ☷│2030-01-22.base     |
|     ☷│2030-01-23.base     |
|     ☷│2030-01-24.base     |
|     ☷│2030-01-25.base     |
|     ☷│2030-01-26.base     |
|     ☷│2030-01-27.base     |
|     ☷│2030-01-28.base     |
|     ☷│2030-01-29.base     |
|     ☷│2030-01-30.base     |
|     ☷│2030-01-31.base     |
|     ☷│2030-02-01.base     |
|     ☷│2030-02-02.base     |
|     ☷│2030-02-03.base     |
|     ☷│2030-02-04.base     |
|     ☷│2030-02-05.base     |
|     ☷│2030-02-06.base     |
|     ☷│2030-02-07.base     |
|     ☷│2030-02-08.base     |
|     ☷│2030-02-09.base     |
|     ☷│2030-02-10.base     |
|     ☷│2030-02-11.base     |
|     ☷│2030-02-12.base     |
|     ☷│2030-02-13.base     |
|     ☷│2030-02-14.base     |
|     ☷│2030-02-15.base     |
|     ☷│2030-02-16.base     |
|     ☷│2030-02-17.base     |
|     ☷│2030-02-18.base     |
|     ☷│2030-02-19.base     |
|     ☷│2030-02-20.base     |
|     ☷│2030-02-21.base     |
|     ☷│2030-02-22.base     |
|     ☷│2030-02-23.base     |
|     ☷│2030-02-24.base     |
|     ☷│2030-02-25.base     |
|     ☷│2030-02-26.base     |
|     ☷│2030-02-27.base     |
|     ☷│2030-02-28.base     |
|     ☷│2030-03-01.base     |
|     ☷│2030-03-02.base     |
|     ☷│2030-03-03.base     |
|     ☷│2030-03-04.base     |
|     ☷│2030-03-05.base     |
|     ☷│2030-03-06.base     |
|     ☷│2030-03-07.base     |
|     ☷│2030-03-08.base     |
|     ☷│2030-03-09.base     |
|     ☷│2030-03-10.base     |
|     ☷│2030-03-11.base     |
|     ☷│2030-03-12.base     |
|     ☷│2030-03-13.base     |
|     ☷│2030-03-14.base     |
|     ☷│2030-03-15.base     |
|     ☷│2030-03-16.base     |
|     ☷│2030-03-17.base     |
|     ☷│2030-03-18.base     |
|     ☷│2030-03-19.base     |
|     ☷│2030-03-20.base     |
|     ☷│2030-03-21.base     |
|     ☷│2030-03-22.base     |
|     ☷│2030-03-23.base     |
|     ☷│2030-03-24.base     |
|     ☷│2030-03-25.base     |
|     ☷│2030-03-26.base     |
|     ☷│2030-03-27.base     |
|     ☷│2030-03-28.base     |
|     ☷│2030-03-29.base     |
|     ☷│2030-03-30.base     |
|     ☷│2030-03-31.base     |
|     ☷│2030-04-01.base     |
|     ☷│2030-04-02.base     |
|     ☷│2030-04-03.base     |
|     ☷│2030-04-04.base     |
|     ☷│2030-04-05.base     |
|     ☷│2030-04-06.base     |
|     ☷│2030-04-07.base     |
|     ☷│2030-04-08.base     |
|     ☷│2030-04-09.base     |
|     ☷│2030-04-10.base     |
|     ☷│2030-04-11.base     |
|     ☷│2030-04-12.base     |
|     ☷│2030-04-13.base     |
|     ☷│2030-04-14.base     |
|     ☷│2030-04-15.base     |
|     ☷│2030-04-16.base     |
|     ☷│2030-04-17.base     |
|     ☷│2030-04-18.base     |
|     ☷│2030-04-19.base     |
|     ☷│2030-04-20.base     |
|     ☷│2030-04-21.base     |
|     ☷│2030-04-22.base     |
|     ☷│2030-04-23.base     |
|     ☷│2030-04-24.base     |
|     ☷│2030-04-25.base     |
|     ☷│2030-04-26.base     |
|     ☷│2030-04-27.base     |
|     ☷│2030-04-28.base     |
|     ☷│2030-04-29.base     |
|     ☷│2030-04-30.base     |
|     ☷│2030-05-01.base     |
|     ☷│2030-05-02.base     |
|     ☷│2030-05-03.base     |
|     ☷│2030-05-04.base     |
|     ☷│2030-05-05.base     |
|     ☷│2030-05-06.base     |
|     ☷│2030-05-07.base     |
|     ☷│2030-05-08.base     |
|     ☷│2030-05-09.base     |
|     ☷│2030-05-10.base     |
|     ☷│2030-05-11.base     |
|     ☷│2030-05-12.base     |
|     ☷│2030-05-13.base     |
|     ☷│2030-05-14.base     |
|     ☷│2030-05-15.base     |
|     ☷│2030-05-16.base     |
|     ☷│2030-05-17.base     |
|     ☷│2030-05-18.base     |
|     ☷│2030-05-19.base     |
|     ☷│2030-05-20.base     |
|     ☷│2030-05-21.base     |
|     ☷│2030-05-22.base     |
|     ☷│2030-05-23.base     |
|     ☷│2030-05-24.base     |
|     ☷│2030-05-25.base     |
|     ☷│2030-05-26.base     |
|     ☷│2030-05-27.base     |
|     ☷│2030-05-28.base     |
|     ☷│2030-05-29.base     |
|     ☷│2030-05-30.base     |
|     ☷│2030-05-31.base     |
|     ☷│2030-06-01.base     |
|     ☷│2030-06-02.base     |
|     ☷│2030-06-03.base     |
|     ☷│2030-06-04.base     |
|     ☷│2030-06-05.base     |
|     ☷│2030-06-06.base     |
|     ☷│2030-06-07.base     |
|     ☷│2030-06-08.base     |
|     ☷│2030-06-09.base     |
|     ☷│2030-06-10.base     |
|     ☷│2030-06-11.base     |
|     ☷│2030-06-12.base     |
|     ☷│2030-06-13.base     |
|     ☷│2030-06-14.base     |
|     ☷│2030-06-15.base     |
|     ☷│2030-06-16.base     |
|     ☷│2030-06-17.base     |
|     ☷│2030-06-18.base     |
|     ☷│2030-06-19.base     |
|     ☷│2030-06-20.base     |
|     ☷│2030-06-21.base     |
|     ☷│2030-06-22.base     |
|     ☷│2030-06-23.base     |
|     ☷│2030-06-24.base     |
|     ☷│2030-06-25.base     |
|     ☷│2030-06-26.base     |
|     ☷│2030-06-27.base     |
|     ☷│2030-06-28.base     |
|     ☷│2030-06-29.base     |
|     ☷│2030-06-30.base     |
|     ☷│2030-07-01.base     |
|     ☷│2030-07-02.base     |
|     ☷│2030-07-03.base     |
|     ☷│2030-07-04.base     |
|     ☷│2030-07-05.base     |
|     ☷│2030-07-06.base     |
|     ☷│2030-07-07.base     |
|     ☷│2030-07-08.base     |
|     ☷│2030-07-09.base     |
|     ☷│2030-07-10.base     |
|     ☷│2030-07-11.base     |
|     ☷│2030-07-12.base     |
|     ☷│2030-07-13.base     |
|     ☷│2030-07-14.base     |
|     ☷│2030-07-15.base     |
|     ☷│2030-07-16.base     |
|     ☷│2030-07-17.base     |
|     ☷│2030-07-18.base     |
|     ☷│2030-07-19.base     |
|     ☷│2030-07-20.base     |
|     ☷│2030-07-21.base     |
|     ☷│2030-07-22.base     |
|     ☷│2030-07-23.base     |
|     ☷│2030-07-24.base     |
|     ☷│2030-07-25.base     |
|     ☷│2030-07-26.base     |
|     ☷│2030-07-27.base     |
|     ☷│2030-07-28.base     |
|     ☷│2030-07-29.base     |
|     ☷│2030-07-30.base     |
|     ☷│2030-07-31.base     |
|     ☷│2030-08-01.base     |
|     ☷│2030-08-02.base     |
|     ☷│2030-08-03.base     |
|     ☷│2030-08-04.base     |
|     ☷│2030-08-05.base     |
|     ☷│2030-08-06.base     |
|     ☷│2030-08-07.base     |
|     ☷│2030-08-08.base     |
|     ☷│2030-08-09.base     |
|     ☷│2030-08-10.base     |
|     ☷│2030-08-11.base     |
|     ☷│2030-08-12.base     |
|     ☷│2030-08-13.base     |
|     ☷│2030-08-14.base     |
|     ☷│2030-08-15.base     |
|     ☷│2030-08-16.base     |
|     ☷│2030-08-17.base     |
|     ☷│2030-08-18.base     |
|     ☷│2030-08-19.base     |
|     ☷│2030-08-20.base     |
|     ☷│2030-08-21.base     |
|     ☷│2030-08-22.base     |
|     ☷│2030-08-23.base     |
|     ☷│2030-08-24.base     |
|     ☷│2030-08-25.base     |
|     ☷│2030-08-26.base     |
|     ☷│2030-08-27.base     |
|     ☷│2030-08-28.base     |
|     ☷│2030-08-29.base     |
|     ☷│2030-08-30.base     |
|     ☷│2030-08-31.base     |
|     ☷│2030-09-01.base     |
|     ☷│2030-09-02.base     |
|     ☷│2030-09-03.base     |
|     ☷│2030-09-04.base     |
|     ☷│2030-09-05.base     |
|     ☷│2030-09-06.base     |
|     ☷│2030-09-07.base     |
|     ☷│2030-09-08.base     |
|     ☷│2030-09-09.base     |
|     ☷│2030-09-10.base     |
|     ☷│2030-09-11.base     |
|     ☷│2030-09-12.base     |
|     ☷│2030-09-13.base     |
|     ☷│2030-09-14.base     |
|     ☷│2030-09-15.base     |
|     ☷│2030-09-16.base     |
|     ☷│2030-09-17.base     |
|     ☷│2030-09-18.base     |
|     ☷│2030-09-19.base     |
|     ☷│2030-09-20.base     |
|     ☷│2030-09-21.base     |
|     ☷│2030-09-22.base     |
|     ☷│2030-09-23.base     |
|     ☷│2030-09-24.base     |
|     ☷│2030-09-25.base     |
|     ☷│2030-09-26.base     |
|     ☷│2030-09-27.base     |
|     ☷│2030-09-28.base     |
|     ☷│2030-09-29.base     |
|     ☷│2030-09-30.base     |
|     ☷│2030-10-01.base     |
|     ☷│2030-10-02.base     |
|     ☷│2030-10-03.base     |
|     ☷│2030-10-04.base     |
|     ☷│2030-10-05.base     |
|     ☷│2030-10-06.base     |
|     ☷│2030-10-07.base     |
|     ☷│2030-10-08.base     |
|     ☷│2030-10-09.base     |
|     ☷│2030-10-10.base     |
|     ☷│2030-10-11.base     |
|     ☷│2030-10-12.base     |
|     ☷│2030-10-13.base     |
|     ☷│2030-10-14.base     |
|     ☷│2030-10-15.base     |
|     ☷│2030-10-16.base     |
|     ☷│2030-10-17.base     |
|     ☷│2030-10-18.base     |
|     ☷│2030-10-19.base     |
|     ☷│2030-10-20.base     |
|     ☷│2030-10-21.base     |
|     ☷│2030-10-22.base     |
|     ☷│2030-10-23.base     |
|     ☷│2030-10-24.base     |
|     ☷│2030-10-25.base     |
|     ☷│2030-10-26.base     |
|     ☷│2030-10-27.base     |
|     ☷│2030-10-28.base     |
|     ☷│2030-10-29.base     |
|     ☷│2030-10-30.base     |
|     ☷│2030-10-31.base     |
|     ☷│2030-11-01.base     |
|     ☷│2030-11-02.base     |
|     ☷│2030-11-03.base     |
|     ☷│2030-11-04.base     |
|     ☷│2030-11-05.base     |
|     ☷│2030-11-06.base     |
|     ☷│2030-11-07.base     |
|     ☷│2030-11-08.base     |
|     ☷│2030-11-09.base     |
|     ☷│2030-11-10.base     |
|     ☷│2030-11-11.base     |
|     ☷│2030-11-12.base     |
|     ☷│2030-11-13.base     |
|     ☷│2030-11-14.base     |
|     ☷│2030-11-15.base     |
|     ☷│2030-11-16.base     |
|     ☷│2030-11-17.base     |
|     ☷│2030-11-18.base     |
|     ☷│2030-11-19.base     |
|     ☷│2030-11-20.base     |
|     ☷│2030-11-21.base     |
|     ☷│2030-11-22.base     |
|     ☷│2030-11-23.base     |
|     ☷│2030-11-24.base     |
|     ☷│2030-11-25.base     |
|     ☷│2030-11-26.base     |
|     ☷│2030-11-27.base     |
|     ☷│2030-11-28.base     |
|     ☷│2030-11-29.base     |
|     ☷│2030-11-30.base     |
|     ☷│2030-12-01.base     |
|     ☷│2030-12-02.base     |
|     ☷│2030-12-03.base     |
|     ☷│2030-12-04.base     |
|     ☷│2030-12-05.base     |
|     ☷│2030-12-06.base     |
|     ☷│2030-12-07.base     |
|     ☷│2030-12-08.base     |
|     ☷│2030-12-09.base     |
|     ☷│2030-12-10.base     |
|     ☷│2030-12-11.base     |
|     ☷│2030-12-12.base     |
|     ☷│2030-12-13.base     |
|     ☷│2030-12-14.base     |
|     ☷│2030-12-15.base     |
|     ☷│2030-12-16.base     |
|     ☷│2030-12-17.base     |
|     ☷│2030-12-18.base     |
|     ☷│2030-12-19.base     |
|     ☷│2030-12-20.base     |
|     ☷│2030-12-21.base     |
|     ☷│2030-12-22.base     |
|     ☷│2030-12-23.base     |
|     ☷│2030-12-24.base     |
|     ☷│2030-12-25.base     |
|     ☷│2030-12-26.base     |
|     ☷│2030-12-27.base     |
|     ☷│2030-12-28.base     |
|     ☷│2030-12-29.base     |
|     ☷│2030-12-30.base     |
|     ☷│2030-12-31.base     |
|           🎵│音楽           |
|   🖲：［DFBイベント・日付生成］│🗓    |
|   🗓：「🍻貿易実務C級お疲れ様飲み会」    |
|   🗓：「いずのめTOKYO：榊原先生会」    |
|   🗓：「いづのめTokyo：榊原先生会」    |
|        🗓：「はつねで食事」        |
|        🗓：「はつねで食事」        |
| 🗓：「家族で外食・北海道ラーメン味源 小平店」  |
|   🗓：「家族で食事：高島屋・農家の台所」    |
|      🗓：「訓練校お疲れ様食事会」      |
|  🗓：「国立市シルバー人材センターサポート」   |
|     🗓：「少林寺拳法部・合宿１日目」     |
|     🗓：「少林寺拳法部・合宿２日目」     |
|     🗓：「少林寺拳法部・合宿３日目」     |
|  🗓：「少林寺拳法部・合宿４日目(最終日)」   |
|  🗓：「杉並浄霊センター・サマースクール会議」  |
| 🗓：「杉並浄霊センター・サマースクール準備初回」 |
|   🗓：「世界救世教・サマースクール１日目」   |
|      🗓：「世界救世教・聖地参拝」      |
|    🗓：「多摩浄霊センターにてご参拝」     |
|     🗓：「文化祭会議・マック国立店」     |
|     🗓：「放課後・友人とカラオケ」      |
|     🗓：「野中家に遊びに行く（？）」     |
|    🗓：「立川六中陸上部にOB顔出し」     |
|       🗓：「六中OB顔出し」        |
|        2016-05-02         |
|        2016-05-03         |
|        2016-05-15         |
|        2016-05-22         |
|        2016-05-29         |
|        2016-06-18         |
|        2016-06-26         |
|        2016-07-03         |
|        2016-07-07         |
|        2016-07-09         |
|        2016-07-14         |
|        2016-07-16         |
|        2016-07-17         |
|        2016-07-20         |
|        2016-07-22         |
|        2016-07-23         |
|        2016-07-24         |
|        2016-07-25         |
|        2016-07-31         |
|        2016−04−30         |
|        2025-12-09         |
|        2026-05-28         |
|        2027-01-01         |
|        2027-01-02         |
|        2027-01-03         |
|        2027-01-04         |
|        2027-01-05         |
|        2027-01-06         |
|        2027-01-07         |
|        2027-01-08         |
|        2027-01-09         |
|        2027-01-10         |
|        2027-01-11         |
|        2027-01-12         |
|        2027-01-13         |
|        2027-01-14         |
|        2027-01-15         |
|        2027-01-16         |
|        2027-01-17         |
|        2027-01-18         |
|        2027-01-19         |
|        2027-01-20         |
|        2027-01-21         |
|        2027-01-22         |
|        2027-01-23         |
|        2027-01-24         |
|        2027-01-25         |
|        2027-01-26         |
|        2027-01-27         |
|        2027-01-28         |
|        2027-01-29         |
|        2027-01-30         |
|        2027-01-31         |
|        2027-02-01         |
|        2027-02-02         |
|        2027-02-03         |
|        2027-02-04         |
|        2027-02-05         |
|        2027-02-06         |
|        2027-02-07         |
|        2027-02-08         |
|        2027-02-09         |
|        2027-02-10         |
|        2027-02-11         |
|        2027-02-12         |
|        2027-02-13         |
|        2027-02-14         |
|        2027-02-15         |
|        2027-02-16         |
|        2027-02-17         |
|        2027-02-18         |
|        2027-02-19         |
|        2027-02-20         |
|        2027-02-21         |
|        2027-02-22         |
|        2027-02-23         |
|        2027-02-24         |
|        2027-02-25         |
|        2027-02-26         |
|        2027-02-27         |
|        2027-02-28         |
|        2027-03-01         |
|        2027-03-02         |
|        2027-03-03         |
|        2027-03-04         |
|        2027-03-05         |
|        2027-03-06         |
|        2027-03-07         |
|        2027-03-08         |
|        2027-03-09         |
|        2027-03-10         |
|        2027-03-11         |
|        2027-03-12         |
|        2027-03-13         |
|        2027-03-14         |
|        2027-03-15         |
|        2027-03-16         |
|        2027-03-17         |
|        2027-03-18         |
|        2027-03-19         |
|        2027-03-20         |
|        2027-03-21         |
|        2027-03-22         |
|        2027-03-23         |
|        2027-03-24         |
|        2027-03-25         |
|        2027-03-26         |
|        2027-03-27         |
|        2027-03-28         |
|        2027-03-29         |
|        2027-03-30         |
|        2027-03-31         |
|        2027-04-01         |
|        2027-04-02         |
|        2027-04-03         |
|        2027-04-04         |
|        2027-04-05         |
|        2027-04-06         |
|        2027-04-07         |
|        2027-04-08         |
|        2027-04-09         |
|        2027-04-10         |
|        2027-04-11         |
|        2027-04-12         |
|        2027-04-13         |
|        2027-04-14         |
|        2027-04-15         |
|        2027-04-16         |
|        2027-04-17         |
|        2027-04-18         |
|        2027-04-19         |
|        2027-04-20         |
|        2027-04-21         |
|        2027-04-22         |
|        2027-04-23         |
|        2027-04-24         |
|        2027-04-25         |
|        2027-04-26         |
|        2027-04-27         |
|        2027-04-28         |
|        2027-04-29         |
|        2027-04-30         |
|        2027-05-01         |
|        2027-05-02         |
|        2027-05-03         |
|        2027-05-04         |
|        2027-05-05         |
|        2027-05-06         |
|        2027-05-07         |
|        2027-05-08         |
|        2027-05-09         |
|        2027-05-10         |
|        2027-05-11         |
|        2027-05-12         |
|        2027-05-13         |
|        2027-05-14         |
|        2027-05-15         |
|        2027-05-16         |
|        2027-05-17         |
|        2027-05-18         |
|        2027-05-19         |
|        2027-05-20         |
|        2027-05-21         |
|        2027-05-22         |
|        2027-05-23         |
|        2027-05-24         |
|        2027-05-25         |
|        2027-05-26         |
|        2027-05-27         |
|        2027-05-28         |
|        2027-05-29         |
|        2027-05-30         |
|        2027-05-31         |
|        2027-06-01         |
|        2027-06-02         |
|        2027-06-03         |
|        2027-06-04         |
|        2027-06-05         |
|        2027-06-06         |
|        2027-06-07         |
|        2027-06-08         |
|        2027-06-09         |
|        2027-06-10         |
|        2027-06-11         |
|        2027-06-12         |
|        2027-06-13         |
|        2027-06-14         |
|        2027-06-15         |
|        2027-06-16         |
|        2027-06-17         |
|        2027-06-18         |
|        2027-06-19         |
|        2027-06-20         |
|        2027-06-21         |
|        2027-06-22         |
|        2027-06-23         |
|        2027-06-24         |
|        2027-06-25         |
|        2027-06-26         |
|        2027-06-27         |
|        2027-06-28         |
|        2027-06-29         |
|        2027-06-30         |
|        2027-07-01         |
|        2027-07-02         |
|        2027-07-03         |
|        2027-07-04         |
|        2027-07-05         |
|        2027-07-06         |
|        2027-07-07         |
|        2027-07-08         |
|        2027-07-09         |
|        2027-07-10         |
|        2027-07-11         |
|        2027-07-12         |
|        2027-07-13         |
|        2027-07-14         |
|        2027-07-15         |
|        2027-07-16         |
|        2027-07-17         |
|        2027-07-18         |
|        2027-07-19         |
|        2027-07-20         |
|        2027-07-21         |
|        2027-07-22         |
|        2027-07-23         |
|        2027-07-24         |
|        2027-07-25         |
|        2027-07-26         |
|        2027-07-27         |
|        2027-07-28         |
|        2027-07-29         |
|        2027-07-30         |
|        2027-07-31         |
|        2027-08-01         |
|        2027-08-02         |
|        2027-08-03         |
|        2027-08-04         |
|        2027-08-05         |
|        2027-08-06         |
|        2027-08-07         |
|        2027-08-08         |
|        2027-08-09         |
|        2027-08-10         |
|        2027-08-11         |
|        2027-08-12         |
|        2027-08-13         |
|        2027-08-14         |
|        2027-08-15         |
|        2027-08-16         |
|        2027-08-17         |
|        2027-08-18         |
|        2027-08-19         |
|        2027-08-20         |
|        2027-08-21         |
|        2027-08-22         |
|        2027-08-23         |
|        2027-08-24         |
|        2027-08-25         |
|        2027-08-26         |
|        2027-08-27         |
|        2027-08-28         |
|        2027-08-29         |
|        2027-08-30         |
|        2027-08-31         |
|        2027-09-01         |
|        2027-09-02         |
|        2027-09-03         |
|        2027-09-04         |
|        2027-09-05         |
|        2027-09-06         |
|        2027-09-07         |
|        2027-09-08         |
|        2027-09-09         |
|        2027-09-10         |
|        2027-09-11         |
|        2027-09-12         |
|        2027-09-13         |
|        2027-09-14         |
|        2027-09-15         |
|        2027-09-16         |
|        2027-09-17         |
|        2027-09-18         |
|        2027-09-19         |
|        2027-09-20         |
|        2027-09-21         |
|        2027-09-22         |
|        2027-09-23         |
|        2027-09-24         |
|        2027-09-25         |
|        2027-09-26         |
|        2027-09-27         |
|        2027-09-28         |
|        2027-09-29         |
|        2027-09-30         |
|        2027-10-01         |
|        2027-10-02         |
|        2027-10-03         |
|        2027-10-04         |
|        2027-10-05         |
|        2027-10-06         |
|        2027-10-07         |
|        2027-10-08         |
|        2027-10-09         |
|        2027-10-10         |
|        2027-10-11         |
|        2027-10-12         |
|        2027-10-13         |
|        2027-10-14         |
|        2027-10-15         |
|        2027-10-16         |
|        2027-10-17         |
|        2027-10-18         |
|        2027-10-19         |
|        2027-10-20         |
|        2027-10-21         |
|        2027-10-22         |
|        2027-10-23         |
|        2027-10-24         |
|        2027-10-25         |
|        2027-10-26         |
|        2027-10-27         |
|        2027-10-28         |
|        2027-10-29         |
|        2027-10-30         |
|        2027-10-31         |
|        2027-11-01         |
|        2027-11-02         |
|        2027-11-03         |
|        2027-11-04         |
|        2027-11-05         |
|        2027-11-06         |
|        2027-11-07         |
|        2027-11-08         |
|        2027-11-09         |
|        2027-11-10         |
|        2027-11-11         |
|        2027-11-12         |
|        2027-11-13         |
|        2027-11-14         |
|        2027-11-15         |
|        2027-11-16         |
|        2027-11-17         |
|        2027-11-18         |
|        2027-11-19         |
|        2027-11-20         |
|        2027-11-21         |
|        2027-11-22         |
|        2027-11-23         |
|        2027-11-24         |
|        2027-11-25         |
|        2027-11-26         |
|        2027-11-27         |
|        2027-11-28         |
|        2027-11-29         |
|        2027-11-30         |
|        2027-12-01         |
|        2027-12-02         |
|        2027-12-03         |
|        2027-12-04         |
|        2027-12-05         |
|        2027-12-06         |
|        2027-12-07         |
|        2027-12-08         |
|        2027-12-09         |
|        2027-12-10         |
|        2027-12-11         |
|        2027-12-12         |
|        2027-12-13         |
|        2027-12-14         |
|        2027-12-15         |
|        2027-12-16         |
|        2027-12-17         |
|        2027-12-18         |
|        2027-12-19         |
|        2027-12-20         |
|        2027-12-21         |
|        2027-12-22         |
|        2027-12-23         |
|        2027-12-24         |
|        2027-12-25         |
|        2027-12-26         |
|        2027-12-27         |
|        2027-12-28         |
|        2027-12-29         |
|        2027-12-30         |
|        2027-12-31         |
|        2028-01-01         |
|        2028-01-02         |
|        2028-01-03         |
|        2028-01-04         |
|        2028-01-05         |
|        2028-01-06         |
|        2028-01-07         |
|        2028-01-08         |
|        2028-01-09         |
|        2028-01-10         |
|        2028-01-11         |
|        2028-01-12         |
|        2028-01-13         |
|        2028-01-14         |
|        2028-01-15         |
|        2028-01-16         |
|        2028-01-17         |
|        2028-01-18         |
|        2028-01-19         |
|        2028-01-20         |
|        2028-01-21         |
|        2028-01-22         |
|        2028-01-23         |
|        2028-01-24         |
|        2028-01-25         |
|        2028-01-26         |
|        2028-01-27         |
|        2028-01-28         |
|        2028-01-29         |
|        2028-01-30         |
|        2028-01-31         |
|        2028-02-01         |
|        2028-02-02         |
|        2028-02-03         |
|        2028-02-04         |
|        2028-02-05         |
|        2028-02-06         |
|        2028-02-07         |
|        2028-02-08         |
|        2028-02-09         |
|        2028-02-10         |
|        2028-02-11         |
|        2028-02-12         |
|        2028-02-13         |
|        2028-02-14         |
|        2028-02-15         |
|        2028-02-16         |
|        2028-02-17         |
|        2028-02-18         |
|        2028-02-19         |
|        2028-02-20         |
|        2028-02-21         |
|        2028-02-22         |
|        2028-02-23         |
|        2028-02-24         |
|        2028-02-25         |
|        2028-02-26         |
|        2028-02-27         |
|        2028-02-28         |
|        2028-02-29         |
|        2028-03-01         |
|        2028-03-02         |
|        2028-03-03         |
|        2028-03-04         |
|        2028-03-05         |
|        2028-03-06         |
|        2028-03-07         |
|        2028-03-08         |
|        2028-03-09         |
|        2028-03-10         |
|        2028-03-11         |
|        2028-03-12         |
|        2028-03-13         |
|        2028-03-14         |
|        2028-03-15         |
|        2028-03-16         |
|        2028-03-17         |
|        2028-03-18         |
|        2028-03-19         |
|        2028-03-20         |
|        2028-03-21         |
|        2028-03-22         |
|        2028-03-23         |
|        2028-03-24         |
|        2028-03-25         |
|        2028-03-26         |
|        2028-03-27         |
|        2028-03-28         |
|        2028-03-29         |
|        2028-03-30         |
|        2028-03-31         |
|        2028-04-01         |
|        2028-04-02         |
|        2028-04-03         |
|        2028-04-04         |
|        2028-04-05         |
|        2028-04-06         |
|        2028-04-07         |
|        2028-04-08         |
|        2028-04-09         |
|        2028-04-10         |
|        2028-04-11         |
|        2028-04-12         |
|        2028-04-13         |
|        2028-04-14         |
|        2028-04-15         |
|        2028-04-16         |
|        2028-04-17         |
|        2028-04-18         |
|        2028-04-19         |
|        2028-04-20         |
|        2028-04-21         |
|        2028-04-22         |
|        2028-04-23         |
|        2028-04-24         |
|        2028-04-25         |
|        2028-04-26         |
|        2028-04-27         |
|        2028-04-28         |
|        2028-04-29         |
|        2028-04-30         |
|        2028-05-01         |
|        2028-05-02         |
|        2028-05-03         |
|        2028-05-04         |
|        2028-05-05         |
|        2028-05-06         |
|        2028-05-07         |
|        2028-05-08         |
|        2028-05-09         |
|        2028-05-10         |
|        2028-05-11         |
|        2028-05-12         |
|        2028-05-13         |
|        2028-05-14         |
|        2028-05-15         |
|        2028-05-16         |
|        2028-05-17         |
|        2028-05-18         |
|        2028-05-19         |
|        2028-05-20         |
|        2028-05-21         |
|        2028-05-22         |
|        2028-05-23         |
|        2028-05-24         |
|        2028-05-25         |
|        2028-05-26         |
|        2028-05-27         |
|        2028-05-28         |
|        2028-05-29         |
|        2028-05-30         |
|        2028-05-31         |
|        2028-06-01         |
|        2028-06-02         |
|        2028-06-03         |
|        2028-06-04         |
|        2028-06-05         |
|        2028-06-06         |
|        2028-06-07         |
|        2028-06-08         |
|        2028-06-09         |
|        2028-06-10         |
|        2028-06-11         |
|        2028-06-12         |
|        2028-06-13         |
|        2028-06-14         |
|        2028-06-15         |
|        2028-06-16         |
|        2028-06-17         |
|        2028-06-18         |
|        2028-06-19         |
|        2028-06-20         |
|        2028-06-21         |
|        2028-06-22         |
|        2028-06-23         |
|        2028-06-24         |
|        2028-06-25         |
|        2028-06-26         |
|        2028-06-27         |
|        2028-06-28         |
|        2028-06-29         |
|        2028-06-30         |
|        2028-07-01         |
|        2028-07-02         |
|        2028-07-03         |
|        2028-07-04         |
|        2028-07-05         |
|        2028-07-06         |
|        2028-07-07         |
|        2028-07-08         |
|        2028-07-09         |
|        2028-07-10         |
|        2028-07-11         |
|        2028-07-12         |
|        2028-07-13         |
|        2028-07-14         |
|        2028-07-15         |
|        2028-07-16         |
|        2028-07-17         |
|        2028-07-18         |
|        2028-07-19         |
|        2028-07-20         |
|        2028-07-21         |
|        2028-07-22         |
|        2028-07-23         |
|        2028-07-24         |
|        2028-07-25         |
|        2028-07-26         |
|        2028-07-27         |
|        2028-07-28         |
|        2028-07-29         |
|        2028-07-30         |
|        2028-07-31         |
|        2028-08-01         |
|        2028-08-02         |
|        2028-08-03         |
|        2028-08-04         |
|        2028-08-05         |
|        2028-08-06         |
|        2028-08-07         |
|        2028-08-08         |
|        2028-08-09         |
|        2028-08-10         |
|        2028-08-11         |
|        2028-08-12         |
|        2028-08-13         |
|        2028-08-14         |
|        2028-08-15         |
|        2028-08-16         |
|        2028-08-17         |
|        2028-08-18         |
|        2028-08-19         |
|        2028-08-20         |
|        2028-08-21         |
|        2028-08-22         |
|        2028-08-23         |
|        2028-08-24         |
|        2028-08-25         |
|        2028-08-26         |
|        2028-08-27         |
|        2028-08-28         |
|        2028-08-29         |
|        2028-08-30         |
|        2028-08-31         |
|        2028-09-01         |
|        2028-09-02         |
|        2028-09-03         |
|        2028-09-04         |
|        2028-09-05         |
|        2028-09-06         |
|        2028-09-07         |
|        2028-09-08         |
|        2028-09-09         |
|        2028-09-10         |
|        2028-09-11         |
|        2028-09-12         |
|        2028-09-13         |
|        2028-09-14         |
|        2028-09-15         |
|        2028-09-16         |
|        2028-09-17         |
|        2028-09-18         |
|        2028-09-19         |
|        2028-09-20         |
|        2028-09-21         |
|        2028-09-22         |
|        2028-09-23         |
|        2028-09-24         |
|        2028-09-25         |
|        2028-09-26         |
|        2028-09-27         |
|        2028-09-28         |
|        2028-09-29         |
|        2028-09-30         |
|        2028-10-01         |
|        2028-10-02         |
|        2028-10-03         |
|        2028-10-04         |
|        2028-10-05         |
|        2028-10-06         |
|        2028-10-07         |
|        2028-10-08         |
|        2028-10-09         |
|        2028-10-10         |
|        2028-10-11         |
|        2028-10-12         |
|        2028-10-13         |
|        2028-10-14         |
|        2028-10-15         |
|        2028-10-16         |
|        2028-10-17         |
|        2028-10-18         |
|        2028-10-19         |
|        2028-10-20         |
|        2028-10-21         |
|        2028-10-22         |
|        2028-10-23         |
|        2028-10-24         |
|        2028-10-25         |
|        2028-10-26         |
|        2028-10-27         |
|        2028-10-28         |
|        2028-10-29         |
|        2028-10-30         |
|        2028-10-31         |
|        2028-11-01         |
|        2028-11-02         |
|        2028-11-03         |
|        2028-11-04         |
|        2028-11-05         |
|        2028-11-06         |
|        2028-11-07         |
|        2028-11-08         |
|        2028-11-09         |
|        2028-11-10         |
|        2028-11-11         |
|        2028-11-12         |
|        2028-11-13         |
|        2028-11-14         |
|        2028-11-15         |
|        2028-11-16         |
|        2028-11-17         |
|        2028-11-18         |
|        2028-11-19         |
|        2028-11-20         |
|        2028-11-21         |
|        2028-11-22         |
|        2028-11-23         |
|        2028-11-24         |
|        2028-11-25         |
|        2028-11-26         |
|        2028-11-27         |
|        2028-11-28         |
|        2028-11-29         |
|        2028-11-30         |
|        2028-12-01         |
|        2028-12-02         |
|        2028-12-03         |
|        2028-12-04         |
|        2028-12-05         |
|        2028-12-06         |
|        2028-12-07         |
|        2028-12-08         |
|        2028-12-09         |
|        2028-12-10         |
|        2028-12-11         |
|        2028-12-12         |
|        2028-12-13         |
|        2028-12-14         |
|        2028-12-15         |
|        2028-12-16         |
|        2028-12-17         |
|        2028-12-18         |
|        2028-12-19         |
|        2028-12-20         |
|        2028-12-21         |
|        2028-12-22         |
|        2028-12-23         |
|        2028-12-24         |
|        2028-12-25         |
|        2028-12-26         |
|        2028-12-27         |
|        2028-12-28         |
|        2028-12-29         |
|        2028-12-30         |
|        2028-12-31         |
|        2029-01-01         |
|        2029-01-02         |
|        2029-01-03         |
|        2029-01-04         |
|        2029-01-05         |
|        2029-01-06         |
|        2029-01-07         |
|        2029-01-08         |
|        2029-01-09         |
|        2029-01-10         |
|        2029-01-11         |
|        2029-01-12         |
|        2029-01-13         |
|        2029-01-14         |
|        2029-01-15         |
|        2029-01-16         |
|        2029-01-17         |
|        2029-01-18         |
|        2029-01-19         |
|        2029-01-20         |
|        2029-01-21         |
|        2029-01-22         |
|        2029-01-23         |
|        2029-01-24         |
|        2029-01-25         |
|        2029-01-26         |
|        2029-01-27         |
|        2029-01-28         |
|        2029-01-29         |
|        2029-01-30         |
|        2029-01-31         |
|        2029-02-01         |
|        2029-02-02         |
|        2029-02-03         |
|        2029-02-04         |
|        2029-02-05         |
|        2029-02-06         |
|        2029-02-07         |
|        2029-02-08         |
|        2029-02-09         |
|        2029-02-10         |
|        2029-02-11         |
|        2029-02-12         |
|        2029-02-13         |
|        2029-02-14         |
|        2029-02-15         |
|        2029-02-16         |
|        2029-02-17         |
|        2029-02-18         |
|        2029-02-19         |
|        2029-02-20         |
|        2029-02-21         |
|        2029-02-22         |
|        2029-02-23         |
|        2029-02-24         |
|        2029-02-25         |
|        2029-02-26         |
|        2029-02-27         |
|        2029-02-28         |
|        2029-03-01         |
|        2029-03-02         |
|        2029-03-03         |
|        2029-03-04         |
|        2029-03-05         |
|        2029-03-06         |
|        2029-03-07         |
|        2029-03-08         |
|        2029-03-09         |
|        2029-03-10         |
|        2029-03-11         |
|        2029-03-12         |
|        2029-03-13         |
|        2029-03-14         |
|        2029-03-15         |
|        2029-03-16         |
|        2029-03-17         |
|        2029-03-18         |
|        2029-03-19         |
|        2029-03-20         |
|        2029-03-21         |
|        2029-03-22         |
|        2029-03-23         |
|        2029-03-24         |
|        2029-03-25         |
|        2029-03-26         |
|        2029-03-27         |
|        2029-03-28         |
|        2029-03-29         |
|        2029-03-30         |
|        2029-03-31         |
|        2029-04-01         |
|        2029-04-02         |
|        2029-04-03         |
|        2029-04-04         |
|        2029-04-05         |
|        2029-04-06         |
|        2029-04-07         |
|        2029-04-08         |
|        2029-04-09         |
|        2029-04-10         |
|        2029-04-11         |
|        2029-04-12         |
|        2029-04-13         |
|        2029-04-14         |
|        2029-04-15         |
|        2029-04-16         |
|        2029-04-17         |
|        2029-04-18         |
|        2029-04-19         |
|        2029-04-20         |
|        2029-04-21         |
|        2029-04-22         |
|        2029-04-23         |
|        2029-04-24         |
|        2029-04-25         |
|        2029-04-26         |
|        2029-04-27         |
|        2029-04-28         |
|        2029-04-29         |
|        2029-04-30         |
|        2029-05-01         |
|        2029-05-02         |
|        2029-05-03         |
|        2029-05-04         |
|        2029-05-05         |
|        2029-05-06         |
|        2029-05-07         |
|        2029-05-08         |
|        2029-05-09         |
|        2029-05-10         |
|        2029-05-11         |
|        2029-05-12         |
|        2029-05-13         |
|        2029-05-14         |
|        2029-05-15         |
|        2029-05-16         |
|        2029-05-17         |
|        2029-05-18         |
|        2029-05-19         |
|        2029-05-20         |
|        2029-05-21         |
|        2029-05-22         |
|        2029-05-23         |
|        2029-05-24         |
|        2029-05-25         |
|        2029-05-26         |
|        2029-05-27         |
|        2029-05-28         |
|        2029-05-29         |
|        2029-05-30         |
|        2029-05-31         |
|        2029-06-01         |
|        2029-06-02         |
|        2029-06-03         |
|        2029-06-04         |
|        2029-06-05         |
|        2029-06-06         |
|        2029-06-07         |
|        2029-06-08         |
|        2029-06-09         |
|        2029-06-10         |
|        2029-06-11         |
|        2029-06-12         |
|        2029-06-13         |
|        2029-06-14         |
|        2029-06-15         |
|        2029-06-16         |
|        2029-06-17         |
|        2029-06-18         |
|        2029-06-19         |
|        2029-06-20         |
|        2029-06-21         |
|        2029-06-22         |
|        2029-06-23         |
|        2029-06-24         |
|        2029-06-25         |
|        2029-06-26         |
|        2029-06-27         |
|        2029-06-28         |
|        2029-06-29         |
|        2029-06-30         |
|        2029-07-01         |
|        2029-07-02         |
|        2029-07-03         |
|        2029-07-04         |
|        2029-07-05         |
|        2029-07-06         |
|        2029-07-07         |
|        2029-07-08         |
|        2029-07-09         |
|        2029-07-10         |
|        2029-07-11         |
|        2029-07-12         |
|        2029-07-13         |
|        2029-07-14         |
|        2029-07-15         |
|        2029-07-16         |
|        2029-07-17         |
|        2029-07-18         |
|        2029-07-19         |
|        2029-07-20         |
|        2029-07-21         |
|        2029-07-22         |
|        2029-07-23         |
|        2029-07-24         |
|        2029-07-25         |
|        2029-07-26         |
|        2029-07-27         |
|        2029-07-28         |
|        2029-07-29         |
|        2029-07-30         |
|        2029-07-31         |
|        2029-08-01         |
|        2029-08-02         |
|        2029-08-03         |
|        2029-08-04         |
|        2029-08-05         |
|        2029-08-06         |
|        2029-08-07         |
|        2029-08-08         |
|        2029-08-09         |
|        2029-08-10         |
|        2029-08-11         |
|        2029-08-12         |
|        2029-08-13         |
|        2029-08-14         |
|        2029-08-15         |
|        2029-08-16         |
|        2029-08-17         |
|        2029-08-18         |
|        2029-08-19         |
|        2029-08-20         |
|        2029-08-21         |
|        2029-08-22         |
|        2029-08-23         |
|        2029-08-24         |
|        2029-08-25         |
|        2029-08-26         |
|        2029-08-27         |
|        2029-08-28         |
|        2029-08-29         |
|        2029-08-30         |
|        2029-08-31         |
|        2029-09-01         |
|        2029-09-02         |
|        2029-09-03         |
|        2029-09-04         |
|        2029-09-05         |
|        2029-09-06         |
|        2029-09-07         |
|        2029-09-08         |
|        2029-09-09         |
|        2029-09-10         |
|        2029-09-11         |
|        2029-09-12         |
|        2029-09-13         |
|        2029-09-14         |
|        2029-09-15         |
|        2029-09-16         |
|        2029-09-17         |
|        2029-09-18         |
|        2029-09-19         |
|        2029-09-20         |
|        2029-09-21         |
|        2029-09-22         |
|        2029-09-23         |
|        2029-09-24         |
|        2029-09-25         |
|        2029-09-26         |
|        2029-09-27         |
|        2029-09-28         |
|        2029-09-29         |
|        2029-09-30         |
|        2029-10-01         |
|        2029-10-02         |
|        2029-10-03         |
|        2029-10-04         |
|        2029-10-05         |
|        2029-10-06         |
|        2029-10-07         |
|        2029-10-08         |
|        2029-10-09         |
|        2029-10-10         |
|        2029-10-11         |
|        2029-10-12         |
|        2029-10-13         |
|        2029-10-14         |
|        2029-10-15         |
|        2029-10-16         |
|        2029-10-17         |
|        2029-10-18         |
|        2029-10-19         |
|        2029-10-20         |
|        2029-10-21         |
|        2029-10-22         |
|        2029-10-23         |
|        2029-10-24         |
|        2029-10-25         |
|        2029-10-26         |
|        2029-10-27         |
|        2029-10-28         |
|        2029-10-29         |
|        2029-10-30         |
|        2029-10-31         |
|        2029-11-01         |
|        2029-11-02         |
|        2029-11-03         |
|        2029-11-04         |
|        2029-11-05         |
|        2029-11-06         |
|        2029-11-07         |
|        2029-11-08         |
|        2029-11-09         |
|        2029-11-10         |
|        2029-11-11         |
|        2029-11-12         |
|        2029-11-13         |
|        2029-11-14         |
|        2029-11-15         |
|        2029-11-16         |
|        2029-11-17         |
|        2029-11-18         |
|        2029-11-19         |
|        2029-11-20         |
|        2029-11-21         |
|        2029-11-22         |
|        2029-11-23         |
|        2029-11-24         |
|        2029-11-25         |
|        2029-11-26         |
|        2029-11-27         |
|        2029-11-28         |
|        2029-11-29         |
|        2029-11-30         |
|        2029-12-01         |
|        2029-12-02         |
|        2029-12-03         |
|        2029-12-04         |
|        2029-12-05         |
|        2029-12-06         |
|        2029-12-07         |
|        2029-12-08         |
|        2029-12-09         |
|        2029-12-10         |
|        2029-12-11         |
|        2029-12-12         |
|        2029-12-13         |
|        2029-12-14         |
|        2029-12-15         |
|        2029-12-16         |
|        2029-12-17         |
|        2029-12-18         |
|        2029-12-19         |
|        2029-12-20         |
|        2029-12-21         |
|        2029-12-22         |
|        2029-12-23         |
|        2029-12-24         |
|        2029-12-25         |
|        2029-12-26         |
|        2029-12-27         |
|        2029-12-28         |
|        2029-12-29         |
|        2029-12-30         |
|        2029-12-31         |
|        2030-01-01         |
|        2030-01-02         |
|        2030-01-03         |
|        2030-01-04         |
|        2030-01-05         |
|        2030-01-06         |
|        2030-01-07         |
|        2030-01-08         |
|        2030-01-09         |
|        2030-01-10         |
|        2030-01-11         |
|        2030-01-12         |
|        2030-01-13         |
|        2030-01-14         |
|        2030-01-15         |
|        2030-01-16         |
|        2030-01-17         |
|        2030-01-18         |
|        2030-01-19         |
|        2030-01-20         |
|        2030-01-21         |
|        2030-01-22         |
|        2030-01-23         |
|        2030-01-24         |
|        2030-01-25         |
|        2030-01-26         |
|        2030-01-27         |
|        2030-01-28         |
|        2030-01-29         |
|        2030-01-30         |
|        2030-01-31         |
|        2030-02-01         |
|        2030-02-02         |
|        2030-02-03         |
|        2030-02-04         |
|        2030-02-05         |
|        2030-02-06         |
|        2030-02-07         |
|        2030-02-08         |
|        2030-02-09         |
|        2030-02-10         |
|        2030-02-11         |
|        2030-02-12         |
|        2030-02-13         |
|        2030-02-14         |
|        2030-02-15         |
|        2030-02-16         |
|        2030-02-17         |
|        2030-02-18         |
|        2030-02-19         |
|        2030-02-20         |
|        2030-02-21         |
|        2030-02-22         |
|        2030-02-23         |
|        2030-02-24         |
|        2030-02-25         |
|        2030-02-26         |
|        2030-02-27         |
|        2030-02-28         |
|        2030-03-01         |
|        2030-03-02         |
|        2030-03-03         |
|        2030-03-04         |
|        2030-03-05         |
|        2030-03-06         |
|        2030-03-07         |
|        2030-03-08         |
|        2030-03-09         |
|        2030-03-10         |
|        2030-03-11         |
|        2030-03-12         |
|        2030-03-13         |
|        2030-03-14         |
|        2030-03-15         |
|        2030-03-16         |
|        2030-03-17         |
|        2030-03-18         |
|        2030-03-19         |
|        2030-03-20         |
|        2030-03-21         |
|        2030-03-22         |
|        2030-03-23         |
|        2030-03-24         |
|        2030-03-25         |
|        2030-03-26         |
|        2030-03-27         |
|        2030-03-28         |
|        2030-03-29         |
|        2030-03-30         |
|        2030-03-31         |
|        2030-04-01         |
|        2030-04-02         |
|        2030-04-03         |
|        2030-04-04         |
|        2030-04-05         |
|        2030-04-06         |
|        2030-04-07         |
|        2030-04-08         |
|        2030-04-09         |
|        2030-04-10         |
|        2030-04-11         |
|        2030-04-12         |
|        2030-04-13         |
|        2030-04-14         |
|        2030-04-15         |
|        2030-04-16         |
|        2030-04-17         |
|        2030-04-18         |
|        2030-04-19         |
|        2030-04-20         |
|        2030-04-21         |
|        2030-04-22         |
|        2030-04-23         |
|        2030-04-24         |
|        2030-04-25         |
|        2030-04-26         |
|        2030-04-27         |
|        2030-04-28         |
|        2030-04-29         |
|        2030-04-30         |
|        2030-05-01         |
|        2030-05-02         |
|        2030-05-03         |
|        2030-05-04         |
|        2030-05-05         |
|        2030-05-06         |
|        2030-05-07         |
|        2030-05-08         |
|        2030-05-09         |
|        2030-05-10         |
|        2030-05-11         |
|        2030-05-12         |
|        2030-05-13         |
|        2030-05-14         |
|        2030-05-15         |
|        2030-05-16         |
|        2030-05-17         |
|        2030-05-18         |
|        2030-05-19         |
|        2030-05-20         |
|        2030-05-21         |
|        2030-05-22         |
|        2030-05-23         |
|        2030-05-24         |
|        2030-05-25         |
|        2030-05-26         |
|        2030-05-27         |
|        2030-05-28         |
|        2030-05-29         |
|        2030-05-30         |
|        2030-05-31         |
|        2030-06-01         |
|        2030-06-02         |
|        2030-06-03         |
|        2030-06-04         |
|        2030-06-05         |
|        2030-06-06         |
|        2030-06-07         |
|        2030-06-08         |
|        2030-06-09         |
|        2030-06-10         |
|        2030-06-11         |
|        2030-06-12         |
|        2030-06-13         |
|        2030-06-14         |
|        2030-06-15         |
|        2030-06-16         |
|        2030-06-17         |
|        2030-06-18         |
|        2030-06-19         |
|        2030-06-20         |
|        2030-06-21         |
|        2030-06-22         |
|        2030-06-23         |
|        2030-06-24         |
|        2030-06-25         |
|        2030-06-26         |
|        2030-06-27         |
|        2030-06-28         |
|        2030-06-29         |
|        2030-06-30         |
|        2030-07-01         |
|        2030-07-02         |
|        2030-07-03         |
|        2030-07-04         |
|        2030-07-05         |
|        2030-07-06         |
|        2030-07-07         |
|        2030-07-08         |
|        2030-07-09         |
|        2030-07-10         |
|        2030-07-11         |
|        2030-07-12         |
|        2030-07-13         |
|        2030-07-14         |
|        2030-07-15         |
|        2030-07-16         |
|        2030-07-17         |
|        2030-07-18         |
|        2030-07-19         |
|        2030-07-20         |
|        2030-07-21         |
|        2030-07-22         |
|        2030-07-23         |
|        2030-07-24         |
|        2030-07-25         |
|        2030-07-26         |
|        2030-07-27         |
|        2030-07-28         |
|        2030-07-29         |
|        2030-07-30         |
|        2030-07-31         |
|        2030-08-01         |
|        2030-08-02         |
|        2030-08-03         |
|        2030-08-04         |
|        2030-08-05         |
|        2030-08-06         |
|        2030-08-07         |
|        2030-08-08         |
|        2030-08-09         |
|        2030-08-10         |
|        2030-08-11         |
|        2030-08-12         |
|        2030-08-13         |
|        2030-08-14         |
|        2030-08-15         |
|        2030-08-16         |
|        2030-08-17         |
|        2030-08-18         |
|        2030-08-19         |
|        2030-08-20         |
|        2030-08-21         |
|        2030-08-22         |
|        2030-08-23         |
|        2030-08-24         |
|        2030-08-25         |
|        2030-08-26         |
|        2030-08-27         |
|        2030-08-28         |
|        2030-08-29         |
|        2030-08-30         |
|        2030-08-31         |
|        2030-09-01         |
|        2030-09-02         |
|        2030-09-03         |
|        2030-09-04         |
|        2030-09-05         |
|        2030-09-06         |
|        2030-09-07         |
|        2030-09-08         |
|        2030-09-09         |
|        2030-09-10         |
|        2030-09-11         |
|        2030-09-12         |
|        2030-09-13         |
|        2030-09-14         |
|        2030-09-15         |
|        2030-09-16         |
|        2030-09-17         |
|        2030-09-18         |
|        2030-09-19         |
|        2030-09-20         |
|        2030-09-21         |
|        2030-09-22         |
|        2030-09-23         |
|        2030-09-24         |
|        2030-09-25         |
|        2030-09-26         |
|        2030-09-27         |
|        2030-09-28         |
|        2030-09-29         |
|        2030-09-30         |
|        2030-10-01         |
|        2030-10-02         |
|        2030-10-03         |
|        2030-10-04         |
|        2030-10-05         |
|        2030-10-06         |
|        2030-10-07         |
|        2030-10-08         |
|        2030-10-09         |
|        2030-10-10         |
|        2030-10-11         |
|        2030-10-12         |
|        2030-10-13         |
|        2030-10-14         |
|        2030-10-15         |
|        2030-10-16         |
|        2030-10-17         |
|        2030-10-18         |
|        2030-10-19         |
|        2030-10-20         |
|        2030-10-21         |
|        2030-10-22         |
|        2030-10-23         |
|        2030-10-24         |
|        2030-10-25         |
|        2030-10-26         |
|        2030-10-27         |
|        2030-10-28         |
|        2030-10-29         |
|        2030-10-30         |
|        2030-10-31         |
|        2030-11-01         |
|        2030-11-02         |
|        2030-11-03         |
|        2030-11-04         |
|        2030-11-05         |
|        2030-11-06         |
|        2030-11-07         |
|        2030-11-08         |
|        2030-11-09         |
|        2030-11-10         |
|        2030-11-11         |
|        2030-11-12         |
|        2030-11-13         |
|        2030-11-14         |
|        2030-11-15         |
|        2030-11-16         |
|        2030-11-17         |
|        2030-11-18         |
|        2030-11-19         |
|        2030-11-20         |
|        2030-11-21         |
|        2030-11-22         |
|        2030-11-23         |
|        2030-11-24         |
|        2030-11-25         |
|        2030-11-26         |
|        2030-11-27         |
|        2030-11-28         |
|        2030-11-29         |
|        2030-11-30         |
|        2030-12-01         |
|        2030-12-02         |
|        2030-12-03         |
|        2030-12-04         |
|        2030-12-05         |
|        2030-12-06         |
|        2030-12-07         |
|        2030-12-08         |
|        2030-12-09         |
|        2030-12-10         |
|        2030-12-11         |
|        2030-12-12         |
|        2030-12-13         |
|        2030-12-14         |
|        2030-12-15         |
|        2030-12-16         |
|        2030-12-17         |
|        2030-12-18         |
|        2030-12-19         |
|        2030-12-20         |
|        2030-12-21         |
|        2030-12-22         |
|        2030-12-23         |
|        2030-12-24         |
|        2030-12-25         |
|        2030-12-26         |
|        2030-12-27         |
|        2030-12-28         |
|        2030-12-29         |
|        2030-12-30         |
|        2030-12-31         |
|       🄶：DFBファイル量産        |
|        🄶：DFB西暦整理         |
|       Past：山口晃央の過去        |
|          ToolBox          |


---

# 📄 2026-07-01





![](☷│2026-07-01.BASE)

---

# 📄 2026-07-02



### ────────■
#### 【ファイルLog】
![](☷│2026-07-02.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-03



### ────────■
#### 【ファイルLog】
![](☷│2026-07-03.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-04



### ────────■
#### 【ファイルLog】
![](☷│2026-07-04.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-05



### ────────■
#### 【ファイルLog】
![](☷│2026-07-05.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-06



### ────────■
#### 【ファイルLog】
![](☷│2026-07-06.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-07



### ────────■
#### 【ファイルLog】
![](☷│2026-07-07.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-08



---

# 📄 2026-07-09



### ────────■
#### 【ファイルLog】
![](☷│2026-07-09.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-10



### ────────■
#### 【ファイルLog】
![](☷│2026-07-10.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-11



### ────────■
#### 【ファイルLog】
![](☷│2026-07-11.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-12



### ────────■
#### 【ファイルLog】
![](☷│2026-07-12.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-13



### ────────■
#### 【ファイルLog】
![](☷│2026-07-13.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-14



### ────────■
#### 【ファイルLog】
![](☷│2026-07-14.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-15



### ────────■
#### 【ファイルLog】
![](☷│2026-07-15.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-16



### ────────■
#### 【ファイルLog】
![](☷│2026-07-16.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-17



### ────────■
#### 【ファイルLog】
![](☷│2026-07-17.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-18



### ────────■
#### 【ファイルLog】
![](☷│2026-07-18.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-19



### ────────■
#### 【ファイルLog】
![](☷│2026-07-19.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-20



### ────────■
#### 【ファイルLog】
![](☷│2026-07-20.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-21



### ────────■
#### 【ファイルLog】
![](☷│2026-07-21.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-22



### ────────■
#### 【ファイルLog】
![](☷│2026-07-22.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-23



### ────────■
#### 【ファイルLog】
![](☷│2026-07-23.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-24



### ────────■
#### 【ファイルLog】
![](☷│2026-07-24.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-25



### ────────■
#### 【ファイルLog】
![](☷│2026-07-25.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-26



### ────────■
#### 【ファイルLog】
![](☷│2026-07-26.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-27



### ────────■
#### 【ファイルLog】
![](☷│2026-07-27.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-28



### ────────■
#### 【ファイルLog】
![](☷│2026-07-28.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-29



### ────────■
#### 【ファイルLog】
![](☷│2026-07-29.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-30



### ────────■
#### 【ファイルLog】
![](☷│2026-07-30.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-07-31



### ────────■
#### 【ファイルLog】
![](☷│2026-07-31.base)
#### 【DailyData】
%% Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-01



### ────────■
#### 【ファイルLog】
![](☷│2026-08-01.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-01.base|☷│2026-08-01]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-02



### ────────■
#### 【ファイルLog】
![](☷│2026-08-02.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-02.base|☷│2026-08-02]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-03



### ────────■
#### 【ファイルLog】
![](☷│2026-08-03.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-03.base|☷│2026-08-03]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-04



### ────────■
#### 【ファイルLog】
![](☷│2026-08-04.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-04.base|☷│2026-08-04]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-05



### ────────■
#### 【ファイルLog】
![](☷│2026-08-05.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-05.base|☷│2026-08-05]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-06



### ────────■
#### 【ファイルLog】
![](☷│2026-08-06.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-06.base|☷│2026-08-06]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-07



### ────────■
#### 【ファイルLog】
![](☷│2026-08-07.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-07.base|☷│2026-08-07]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-08



### ────────■
#### 【ファイルLog】
![](☷│2026-08-08.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-08.base|☷│2026-08-08]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-09



### ────────■
#### 【ファイルLog】
![](☷│2026-08-09.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-09.base|☷│2026-08-09]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-10



### ────────■
#### 【ファイルLog】
![](☷│2026-08-10.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-10.base|☷│2026-08-10]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-11



### ────────■
#### 【ファイルLog】
![](☷│2026-08-11.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-11.base|☷│2026-08-11]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-12



### ────────■
#### 【ファイルLog】
![](☷│2026-08-12.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-12.base|☷│2026-08-12]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-13



### ────────■
#### 【ファイルLog】
![](☷│2026-08-13.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-13.base|☷│2026-08-13]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-14



### ────────■
#### 【ファイルLog】
![](☷│2026-08-14.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-14.base|☷│2026-08-14]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-15



### ────────■
#### 【ファイルLog】
![](☷│2026-08-15.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-15.base|☷│2026-08-15]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-16



### ────────■
#### 【ファイルLog】
![](☷│2026-08-16.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-16.base|☷│2026-08-16]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-17



### ────────■
#### 【ファイルLog】
![](☷│2026-08-17.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-17.base|☷│2026-08-17]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-18



### ────────■
#### 【ファイルLog】
![](☷│2026-08-18.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-18.base|☷│2026-08-18]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-19



### ────────■
#### 【ファイルLog】
![](☷│2026-08-19.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-19.base|☷│2026-08-19]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-20



### ────────■
#### 【ファイルLog】
![](☷│2026-08-20.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-20.base|☷│2026-08-20]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-21



### ────────■
#### 【ファイルLog】
![](☷│2026-08-21.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-21.base|☷│2026-08-21]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-22



### ────────■
#### 【ファイルLog】
![](☷│2026-08-22.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-22.base|☷│2026-08-22]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-23



### ────────■
#### 【ファイルLog】
![](☷│2026-08-23.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-23.base|☷│2026-08-23]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-24



### ────────■
#### 【ファイルLog】
![](☷│2026-08-24.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-24.base|☷│2026-08-24]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-25



### ────────■
#### 【ファイルLog】
![](☷│2026-08-25.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-25.base|☷│2026-08-25]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-26



### ────────■
#### 【ファイルLog】
![](☷│2026-08-26.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-26.base|☷│2026-08-26]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-27



### ────────■
#### 【ファイルLog】
![](☷│2026-08-27.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-27.base|☷│2026-08-27]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-28



### ────────■
#### 【ファイルLog】
![](☷│2026-08-28.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-28.base|☷│2026-08-28]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-29



### ────────■
#### 【ファイルLog】
![](☷│2026-08-29.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-29.base|☷│2026-08-29]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-30



### ────────■
#### 【ファイルLog】
![](☷│2026-08-30.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-30.base|☷│2026-08-30]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-08-31



### ────────■
#### 【ファイルLog】
![](☷│2026-08-31.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-08-31.base|☷│2026-08-31]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-01



### ────────■
#### 【ファイルLog】
![](☷│2026-09-01.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-01.base|☷│2026-09-01]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-02



### ────────■
#### 【ファイルLog】
![](☷│2026-09-02.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-02.base|☷│2026-09-02]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-03



### ────────■
#### 【ファイルLog】
![](☷│2026-09-03.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-03.base|☷│2026-09-03]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-04



### ────────■
#### 【ファイルLog】
![](☷│2026-09-04.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-04.base|☷│2026-09-04]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-05



### ────────■
#### 【ファイルLog】
![](☷│2026-09-05.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-05.base|☷│2026-09-05]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-06



### ────────■
#### 【ファイルLog】
![](☷│2026-09-06.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-06.base|☷│2026-09-06]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-07



### ────────■
#### 【ファイルLog】
![](☷│2026-09-07.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-07.base|☷│2026-09-07]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-08



### ────────■
#### 【ファイルLog】
![](☷│2026-09-08.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-08.base|☷│2026-09-08]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-09



### ────────■
#### 【ファイルLog】
![](☷│2026-09-09.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-09.base|☷│2026-09-09]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-10



### ────────■
#### 【ファイルLog】
![](☷│2026-09-10.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-10.base|☷│2026-09-10]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-11



### ────────■
#### 【ファイルLog】
![](☷│2026-09-11.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-11.base|☷│2026-09-11]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-12



### ────────■
#### 【ファイルLog】
![](☷│2026-09-12.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-12.base|☷│2026-09-12]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-13



### ────────■
#### 【ファイルLog】
![](☷│2026-09-13.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-13.base|☷│2026-09-13]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-14



### ────────■
#### 【ファイルLog】
![](☷│2026-09-14.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-14.base|☷│2026-09-14]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-15



### ────────■
#### 【ファイルLog】
![](☷│2026-09-15.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-15.base|☷│2026-09-15]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-16



### ────────■
#### 【ファイルLog】
![](☷│2026-09-16.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-16.base|☷│2026-09-16]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-17



### ────────■
#### 【ファイルLog】
![](☷│2026-09-17.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-17.base|☷│2026-09-17]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-18



### ────────■
#### 【ファイルLog】
![](☷│2026-09-18.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-18.base|☷│2026-09-18]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-19



### ────────■
#### 【ファイルLog】
![](☷│2026-09-19.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-19.base|☷│2026-09-19]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-20



### ────────■
#### 【ファイルLog】
![](☷│2026-09-20.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-20.base|☷│2026-09-20]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-21



### ────────■
#### 【ファイルLog】
![](☷│2026-09-21.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-21.base|☷│2026-09-21]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-22



### ────────■
#### 【ファイルLog】
![](☷│2026-09-22.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-22.base|☷│2026-09-22]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-23



### ────────■
#### 【ファイルLog】
![](☷│2026-09-23.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-23.base|☷│2026-09-23]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-24



### ────────■
#### 【ファイルLog】
![](☷│2026-09-24.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-24.base|☷│2026-09-24]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-25



### ────────■
#### 【ファイルLog】
![](☷│2026-09-25.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-25.base|☷│2026-09-25]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-26



### ────────■
#### 【ファイルLog】
![](☷│2026-09-26.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-26.base|☷│2026-09-26]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-27



### ────────■
#### 【ファイルLog】
![](☷│2026-09-27.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-27.base|☷│2026-09-27]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-28



### ────────■
#### 【ファイルLog】
![](☷│2026-09-28.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-28.base|☷│2026-09-28]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-29



### ────────■
#### 【ファイルLog】
![](☷│2026-09-29.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-29.base|☷│2026-09-29]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-09-30



### ────────■
#### 【ファイルLog】
![](☷│2026-09-30.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-09-30.base|☷│2026-09-30]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-01



### ────────■
#### 【ファイルLog】
![](☷│2026-10-01.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-01.base|☷│2026-10-01]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-02



### ────────■
#### 【ファイルLog】
![](☷│2026-10-02.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-02.base|☷│2026-10-02]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-03



### ────────■
#### 【ファイルLog】
![](☷│2026-10-03.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-03.base|☷│2026-10-03]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-04



### ────────■
#### 【ファイルLog】
![](☷│2026-10-04.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-04.base|☷│2026-10-04]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-05



### ────────■
#### 【ファイルLog】
![](☷│2026-10-05.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-05.base|☷│2026-10-05]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-06



### ────────■
#### 【ファイルLog】
![](☷│2026-10-06.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-06.base|☷│2026-10-06]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-07



### ────────■
#### 【ファイルLog】
![](☷│2026-10-07.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-07.base|☷│2026-10-07]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-08



### ────────■
#### 【ファイルLog】
![](☷│2026-10-08.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-08.base|☷│2026-10-08]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-09



### ────────■
#### 【ファイルLog】
![](☷│2026-10-09.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-09.base|☷│2026-10-09]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-10



### ────────■
#### 【ファイルLog】
![](☷│2026-10-10.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-10.base|☷│2026-10-10]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-11



### ────────■
#### 【ファイルLog】
![](☷│2026-10-11.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-11.base|☷│2026-10-11]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-12



### ────────■
#### 【ファイルLog】
![](☷│2026-10-12.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-12.base|☷│2026-10-12]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-13



### ────────■
#### 【ファイルLog】
![](☷│2026-10-13.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-13.base|☷│2026-10-13]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-14



### ────────■
#### 【ファイルLog】
![](☷│2026-10-14.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-14.base|☷│2026-10-14]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-15



### ────────■
#### 【ファイルLog】
![](☷│2026-10-15.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-15.base|☷│2026-10-15]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-16



### ────────■
#### 【ファイルLog】
![](☷│2026-10-16.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-16.base|☷│2026-10-16]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-17



### ────────■
#### 【ファイルLog】
![](☷│2026-10-17.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-17.base|☷│2026-10-17]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-18



### ────────■
#### 【ファイルLog】
![](☷│2026-10-18.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-18.base|☷│2026-10-18]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-19



### ────────■
#### 【ファイルLog】
![](☷│2026-10-19.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-19.base|☷│2026-10-19]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-20



### ────────■
#### 【ファイルLog】
![](☷│2026-10-20.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-20.base|☷│2026-10-20]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-21



### ────────■
#### 【ファイルLog】
![](☷│2026-10-21.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-21.base|☷│2026-10-21]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-22



### ────────■
#### 【ファイルLog】
![](☷│2026-10-22.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-22.base|☷│2026-10-22]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-23



### ────────■
#### 【ファイルLog】
![](☷│2026-10-23.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-23.base|☷│2026-10-23]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-24



### ────────■
#### 【ファイルLog】
![](☷│2026-10-24.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-24.base|☷│2026-10-24]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-25



### ────────■
#### 【ファイルLog】
![](☷│2026-10-25.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-25.base|☷│2026-10-25]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-26



### ────────■
#### 【ファイルLog】
![](☷│2026-10-26.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-26.base|☷│2026-10-26]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-27



### ────────■
#### 【ファイルLog】
![](☷│2026-10-27.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-27.base|☷│2026-10-27]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-28



### ────────■
#### 【ファイルLog】
![](☷│2026-10-28.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-28.base|☷│2026-10-28]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-29



### ────────■
#### 【ファイルLog】
![](☷│2026-10-29.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-29.base|☷│2026-10-29]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-30



### ────────■
#### 【ファイルLog】
![](☷│2026-10-30.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-30.base|☷│2026-10-30]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-10-31



### ────────■
#### 【ファイルLog】
![](☷│2026-10-31.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-10-31.base|☷│2026-10-31]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-01



### ────────■
#### 【ファイルLog】
![](☷│2026-11-01.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-01.base|☷│2026-11-01]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-02



### ────────■
#### 【ファイルLog】
![](☷│2026-11-02.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-02.base|☷│2026-11-02]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-03



### ────────■
#### 【ファイルLog】
![](☷│2026-11-03.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-03.base|☷│2026-11-03]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-04



### ────────■
#### 【ファイルLog】
![](☷│2026-11-04.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-04.base|☷│2026-11-04]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-05



### ────────■
#### 【ファイルLog】
![](☷│2026-11-05.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-05.base|☷│2026-11-05]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-06



### ────────■
#### 【ファイルLog】
![](☷│2026-11-06.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-06.base|☷│2026-11-06]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-07



### ────────■
#### 【ファイルLog】
![](☷│2026-11-07.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-07.base|☷│2026-11-07]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-08



### ────────■
#### 【ファイルLog】
![](☷│2026-11-08.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-08.base|☷│2026-11-08]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-09



### ────────■
#### 【ファイルLog】
![](☷│2026-11-09.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-09.base|☷│2026-11-09]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-10



### ────────■
#### 【ファイルLog】
![](☷│2026-11-10.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-10.base|☷│2026-11-10]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-11



### ────────■
#### 【ファイルLog】
![](☷│2026-11-11.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-11.base|☷│2026-11-11]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-12



### ────────■
#### 【ファイルLog】
![](☷│2026-11-12.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-12.base|☷│2026-11-12]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-13



### ────────■
#### 【ファイルLog】
![](☷│2026-11-13.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-13.base|☷│2026-11-13]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-14



### ────────■
#### 【ファイルLog】
![](☷│2026-11-14.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-14.base|☷│2026-11-14]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-15



### ────────■
#### 【ファイルLog】
![](☷│2026-11-15.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-15.base|☷│2026-11-15]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-16



### ────────■
#### 【ファイルLog】
![](☷│2026-11-16.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-16.base|☷│2026-11-16]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-17



### ────────■
#### 【ファイルLog】
![](☷│2026-11-17.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-17.base|☷│2026-11-17]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-18



### ────────■
#### 【ファイルLog】
![](☷│2026-11-18.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-18.base|☷│2026-11-18]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-19



### ────────■
#### 【ファイルLog】
![](☷│2026-11-19.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-19.base|☷│2026-11-19]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-20



### ────────■
#### 【ファイルLog】
![](☷│2026-11-20.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-20.base|☷│2026-11-20]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-21



### ────────■
#### 【ファイルLog】
![](☷│2026-11-21.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-21.base|☷│2026-11-21]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-22



### ────────■
#### 【ファイルLog】
![](☷│2026-11-22.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-22.base|☷│2026-11-22]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-23



### ────────■
#### 【ファイルLog】
![](☷│2026-11-23.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-23.base|☷│2026-11-23]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-24



### ────────■
#### 【ファイルLog】
![](☷│2026-11-24.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-24.base|☷│2026-11-24]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-25



### ────────■
#### 【ファイルLog】
![](☷│2026-11-25.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-25.base|☷│2026-11-25]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-26



### ────────■
#### 【ファイルLog】
![](☷│2026-11-26.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-26.base|☷│2026-11-26]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-27



### ────────■
#### 【ファイルLog】
![](☷│2026-11-27.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-27.base|☷│2026-11-27]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-28



### ────────■
#### 【ファイルLog】
![](☷│2026-11-28.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-28.base|☷│2026-11-28]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-29



### ────────■
#### 【ファイルLog】
![](☷│2026-11-29.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-29.base|☷│2026-11-29]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-11-30



### ────────■
#### 【ファイルLog】
![](☷│2026-11-30.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-11-30.base|☷│2026-11-30]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-01



### ────────■
#### 【ファイルLog】
![](☷│2026-12-01.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-01.base|☷│2026-12-01]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-02



### ────────■
#### 【ファイルLog】
![](☷│2026-12-02.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-02.base|☷│2026-12-02]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-03



### ────────■
#### 【ファイルLog】
![](☷│2026-12-03.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-03.base|☷│2026-12-03]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-04



### ────────■
#### 【ファイルLog】
![](☷│2026-12-04.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-04.base|☷│2026-12-04]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-05



### ────────■
#### 【ファイルLog】
![](☷│2026-12-05.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-05.base|☷│2026-12-05]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-06



### ────────■
#### 【ファイルLog】
![](☷│2026-12-06.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-06.base|☷│2026-12-06]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-07



### ────────■
#### 【ファイルLog】
![](☷│2026-12-07.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-07.base|☷│2026-12-07]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-08



### ────────■
#### 【ファイルLog】
![](☷│2026-12-08.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-08.base|☷│2026-12-08]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-09



### ────────■
#### 【ファイルLog】
![](☷│2026-12-09.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-09.base|☷│2026-12-09]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-10



### ────────■
#### 【ファイルLog】
![](☷│2026-12-10.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-10.base|☷│2026-12-10]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-11



### ────────■
#### 【ファイルLog】
![](☷│2026-12-11.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-11.base|☷│2026-12-11]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-12



### ────────■
#### 【ファイルLog】
![](☷│2026-12-12.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-12.base|☷│2026-12-12]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-13



### ────────■
#### 【ファイルLog】
![](☷│2026-12-13.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-13.base|☷│2026-12-13]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-14



### ────────■
#### 【ファイルLog】
![](☷│2026-12-14.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-14.base|☷│2026-12-14]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-15



### ────────■
#### 【ファイルLog】
![](☷│2026-12-15.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-15.base|☷│2026-12-15]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-16



### ────────■
#### 【ファイルLog】
![](☷│2026-12-16.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-16.base|☷│2026-12-16]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-17



### ────────■
#### 【ファイルLog】
![](☷│2026-12-17.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-17.base|☷│2026-12-17]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-18



### ────────■
#### 【ファイルLog】
![](☷│2026-12-18.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-18.base|☷│2026-12-18]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-19



### ────────■
#### 【ファイルLog】
![](☷│2026-12-19.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-19.base|☷│2026-12-19]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-20



### ────────■
#### 【ファイルLog】
![](☷│2026-12-20.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-20.base|☷│2026-12-20]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-21



### ────────■
#### 【ファイルLog】
![](☷│2026-12-21.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-21.base|☷│2026-12-21]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-22



### ────────■
#### 【ファイルLog】
![](☷│2026-12-22.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-22.base|☷│2026-12-22]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-23



### ────────■
#### 【ファイルLog】
![](☷│2026-12-23.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-23.base|☷│2026-12-23]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-24



### ────────■
#### 【ファイルLog】
![](☷│2026-12-24.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-24.base|☷│2026-12-24]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-25



### ────────■
#### 【ファイルLog】
![](☷│2026-12-25.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-25.base|☷│2026-12-25]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-26



### ────────■
#### 【ファイルLog】
![](☷│2026-12-26.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-26.base|☷│2026-12-26]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-27



### ────────■
#### 【ファイルLog】
![](☷│2026-12-27.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-27.base|☷│2026-12-27]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-28



### ────────■
#### 【ファイルLog】
![](☷│2026-12-28.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-28.base|☷│2026-12-28]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-29



### ────────■
#### 【ファイルLog】
![](☷│2026-12-29.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-29.base|☷│2026-12-29]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-30



### ────────■
#### 【ファイルLog】
![](☷│2026-12-30.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-30.base|☷│2026-12-30]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

# 📄 2026-12-31



### ────────■
#### 【ファイルLog】
![](☷│2026-12-31.base)
#### 【DailyData】
%% Begin Waypoint %%
- [[☷│2026-12-31.base|☷│2026-12-31]]

%% End Waypoint %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル

---

