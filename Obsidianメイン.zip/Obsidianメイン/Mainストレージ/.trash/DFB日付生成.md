<%*
const startYear = 2000;
const endYear = 2025;
const basePath = "山口晃央/Past：山口晃央の過去/DFB";
const fileContent = "%% Waypoint %%";

// 階層を安全に自動生成する関数
async function ensureFolder(path) {
    const parts = path.split("/");
    let currentPath = "";
    for (const part of parts) {
        currentPath = currentPath ? `${currentPath}/${part}` : part;
        if (!app.vault.getAbstractFileByPath(currentPath)) {
            await app.vault.createFolder(currentPath);
        }
    }
}

// メイン処理（2000年〜2025年のループ）
for (let year = startYear; year <= endYear; year++) {
    const yearLabel = `〔${year}年〕`;
    const yearDir = `${basePath}/${yearLabel}`;
    
    // 年フォルダの確保
    await ensureFolder(yearDir);
    
    // 年ファイルの生成
    const yearFilePath = `${yearDir}/${yearLabel}.md`;
    if (!app.vault.getAbstractFileByPath(yearFilePath)) {
        await app.vault.create(yearFilePath, fileContent);
    }
    
    // 1月〜12月のループ
    for (let month = 1; month <= 12; month++) {
        const monthLabel = `〔${month}月〕`;
        const monthDir = `${yearDir}/${monthLabel}`;
        
        // 月フォルダの確保
        if (!app.vault.getAbstractFileByPath(monthDir)) {
            await app.vault.createFolder(monthDir);
        }
        
        // 月ファイルの生成
        const monthFilePath = `${monthDir}/${monthLabel}.md`;
        if (!app.vault.getAbstractFileByPath(monthFilePath)) {
            await app.vault.create(monthFilePath, fileContent);
        }
    }
}
-%>
秩序の再構築が完了しました（2000年〜2025年分のフォルダ・Waypointファイルの生成完了）。秩序の再構築が完了しました（2000年〜2025年分のフォルダ・Waypointファイルの生成完了）。