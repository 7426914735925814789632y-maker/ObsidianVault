<div style="margin: -20px; overflow: hidden;">
  <img src="https://i.pinimg.com/736x/c9/bf/4f/c9bf4f890157aedc3a3f378b6215f5dd.jpg" style="width: 100%; display: block;">
</div>