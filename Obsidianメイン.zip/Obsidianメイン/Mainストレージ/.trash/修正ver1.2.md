<%*
// ==============================================================================
// 1. 設定領域（期間とルートパス）
// ==============================================================================
const startDate = new Date(2026, 0, 1);
const endDate = new Date(2026, 11, 31);
const baseRoot = "山口晃央/Past：山口晃央の過去/DFB";

// ==============================================================================
// 2. 強制生成・上書きロジック
// ==============================================================================
let current = new Date(startDate);
let count = 0;

new Notice("BASEファイルの強制生成とクエリ最適化を開始します...");

while (current <= endDate) {
    const year = current.getFullYear();
    const month = current.getMonth() + 1;
    
    const yyyy = year;
    const mm = String(month).padStart(2, '0');
    const dd = String(current.getDate()).padStart(2, '0');
    const dateStr = `${yyyy}-${mm}-${dd}`; // 例: 2026-05-28

    const yearFolder = `〔${year}年〕`;
    const monthFolder = `〔${month}月〕`;
    
    const dirPath = `${baseRoot}/${yearFolder}/${monthFolder}/${dateStr}`;
    const newBasePath = `${dirPath}/☷│${dateStr}.base`;

    // フィルター条件に直接日付を埋め込んだクエリ
    const baseContent = `views:
  - type: table
    name: 表
    filters:
      or:
        - |
          file.ctime.date() == "${dateStr}"
        - and:
            - '!file.inFolder("${baseRoot}")'
            - file.hasLink("${baseRoot}/${yearFolder}/${monthFolder}/${dateStr}/${dateStr}")`;

    // フォルダがなければ作り、ファイルは有無に関わらず「強制上書き」
    await app.vault.adapter.mkdir(dirPath);
    await app.vault.adapter.write(newBasePath, baseContent);
    count++;

    current.setDate(current.getDate() + 1);
}

new Notice(`完了しました！\n合計 ${count} 個の「☷│形式」ファイルを強制生成・上書きしました。`);
-%>
