https://www.notion.so/Display-23b7f236974b80a796cbfb4a6f43b79d?source=copy_link
腕重量バンド