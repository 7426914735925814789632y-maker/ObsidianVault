※【動的ロケーション】には活動場所（例：自宅、立川駅前カフェ、移動中など）を文脈から判定して挿入。

※【動的活動要約】にはその時間帯の活動内容のシャープな要約を動的に自動生成する。

【見本】

Markdown

```
### 【【動的ロケーション】：【動的活動要約】】〔開始時間~終了時間〕
- 出来事の箇条書き（要約）
    - 『音声から一語一句そのまま抽出した主観・感想・学びの引用』
- すでに体裁が整ったメモがある場合は下記のように格納：
>[!info] ユーザーMemo✎
>・ユーザーのメモを一切改変せずそのまま格納

### <span style="color: dimgray;">──────────────────────</span>

### 【【動的ロケーション】：【動的活動要約】】〔開始時間~終了時間〕
- 出来事の箇条書き

### ────────■
#### 【ファイルLog】
![](YYYY-MM-DD.base)
#### 【DailyData】
%% Error: Cannot create a waypoint in a note that's not the folder note. For more information, check the instructions [here](https://github.com/IdreesInc/Waypoint) %%

#### 【出力用追加テキスト】
##### ○本日出力ファイル
```
